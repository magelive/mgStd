#ifndef _NAC_PARSE_REQUEST_H_
#define _NAC_PARSE_REQUEST_H_
#include "nac_server.h"

#define  DATA_HEAD     20
#define  DATA_MUT      1024
#define  RECOMMEN_NUM			20480
#define  CHALLENGE_LENGTH   16

#define POLICYPATH "/var/lib/nac/policy/"

void full_response_data(conn *c,unsigned char *proto);
void get_auth_fail_data(conn *c,char *reason,int sec);
void get_auth_success_data(conn *c,char *reason,int sec, int keepalive_msc, int keepalive_times);
int  get_handshark_data(char *buffer,char *data, int data_length,char *proto);
int process_request_app(conn *c);
void parse_request_conn(conn *c);
int Ctr_online_ngump_by_socket(char *cmd, char *ip, char *mac, char *agent);


#endif

#ifndef _NAC_SERVER_H_
#define _NAC_SERVER_H_

#include <nac/nac_std.h>
#include <sys/epoll.h>
#include <event.h>


//#include "PAM_check_user.h"
//#include "nac_server_ldap.h"
//#include "nac_keep_alive.h"

#define IS_UDP(x) (x == udp_transport || x == udp_keepalive_transport)
#define IS_KEEPALIVE(x) (x == tcp_keepalive_transport || x == udp_keepalive_transport)
#define ITEMS_PER_ALLOC 64
#define UDP_READ_BUFFER_SIZE 65536
#define DATA_BUFFER_SIZE 1500
#define READ_BUFFER_HIGHWAT 8192
#define READ_BUFFER_MAX  32767
#define MAX_SENDBUF_SIZE (256 * 1024 * 1024)
#define IOV_LIST_INITIAL 120

#define PAM_MODEL_NAME  "nacweb"

#define __NAC_VERSION__     "V1.0"

//const char *__NAC_SERVER_VERSION__ = "nac_server version :" __NAC_VERSION__ ", built on " __DATE__ "at " __TIME__;

typedef enum bool
{
	false,
	true
}bool;


enum try_read_result 
{
    READ_DATA_RECEIVED,
    READ_NO_DATA_RECEIVED,
    READ_ERROR,            
    READ_MEMORY_ERROR   
};

enum agent_states
{
	agent_auth_start,  				/**<第一次认证请求.*/
	agent_auth_challenge,   	/**<处于挑战状态.*/
	agent_auth_fail,  				/**<认证失败.*/
	agent_auth_access,        /**<健康检查成功.*/
	agent_auth_isolate,       /**<健康检查成功.*/ 
	agent_health_start, 			/**<健康检查开始.*/
	agent_health_process, 		/**<健康检查进行中.*/
 	agent_health_end,  				/**<健康检查结束.*/
	agent_addr_start,  				/**<终端IP管理开始.*/
	agent_addr_process,				/**<终端IP管理进行中.*/
	agent_addr_end,						/**<终端IP管理结束.*/
	agent_recomm_start,				/**<健康检查结果开始发送.*/
	agent_recomm_process,			
	agent_recomm_end				
};

enum conn_states 
{
    conn_listening,  /**< sock监听状态 */
    conn_start,      /**<发送握手信息.*/
    conn_waiting,    /**< 等待读事件发生 */
    conn_read,       /**< 读取数据 */
    conn_write,      /**< 回复确认消息 */
    conn_parse,	     /**< 解析数据 */
    conn_closing,    /**< 关闭连接 */
    conn_max_state   /**< 最大状态 */
};

enum network_transport 
{
    local_transport, 
    tcp_transport,
    udp_transport,
    tcp_keepalive_transport,
    udp_keepalive_transport
};

struct stats {
    unsigned int  curr_conns;                   //当前conn
    unsigned int  total_conns;                  //conn总数
    unsigned int  conn_structs;                 //处理连接数
    unsigned int  max_conn_structs;             //同时处理最大连接数
    unsigned int  max_node;                     //最大节点
    int 		  run_level;                    //运行级别
    int 		  tcp_port;                     //tcp端口
    int 		  udp_port;                     //udp端口
    int           keepalive_tcp_port;          //保活tcp端口
    int           keepalive_udp_port;          //保活udp端口
    int           thread_num;                   //处理线程数
    time_t        started;                      //
    bool          accepting_conns;              //
    unsigned int      listen_disabled_num;      //
};


typedef struct conn_queue_item CQ_ITEM;

struct conn_queue_item 
{
    int               sfd;                  //标识符
    enum conn_states  init_state;           //初始状态
    int               event_flags;          //evnent标志
    int               read_buffer_size;     //读取缓冲大小
    enum network_transport     transport;   //传输状态
    CQ_ITEM          *next;
};

typedef struct conn_queue CQ;
struct conn_queue 
{
    CQ_ITEM *head;
    CQ_ITEM *tail;
    pthread_mutex_t lock;
    pthread_cond_t  cond;
};

typedef struct 
{
    pthread_t thread_id;                         /**<线程ID号*/

    unsigned long long ptimes;

    struct event_base *base;    				 /**<线程监听的事件*/
    struct event notify_event;                   /**<通知事件*/
    int notify_receive_fd;                       /**<通知管道*/
    int notify_send_fd;                          /**<发送管道*/
    struct conn_queue *new_conn_queue;           /**<连接列表*/
} LIBEVENT_THREAD;                          //事件线程???

typedef struct 
{
    pthread_t thread_id;        /**<线程ID号*/
    struct event_base *base;    /**<事件句柄*/
} LIBEVENT_DISPATCHER_THREAD;


typedef struct _struct_transfer
{
	unsigned char proto[4];
	unsigned char flag;
	unsigned char type;
	unsigned short data_length;
	unsigned int  parameter;
}struct_transfer;

typedef struct _struct_apply
{
	unsigned char type;
	unsigned char phase;
	unsigned char zoro[2];
	unsigned int data_length;
}struct_apply;

typedef struct _user_conf
{
    char *username;
    char *pwd;

}user_conf;

typedef struct conn conn;				/**<连接信息*/
struct conn 
{
    int    sfd;                       /**<连接描述符.*/
    enum agent_states ag_state;		      /**<当前连接状态.*/	
    enum conn_states  state;          /**<当前连接所处的状态.*/
    enum conn_states  go_state;       /**<连接下一个期望状态.*/ 
    
    struct event event;               /**<连接监听事件.*/
    short  ev_flags;                  /**<事件类型.*/
    short  which;   

    /*udp 参数*/
    int    request_id;                 /**<udp发送ID号.*/ 
    struct sockaddr request_addr;      /**<客户端地址.*/
    socklen_t request_addr_size;       /**<地址长度.*/
    
    char switch_host[16];              /**<交换机地址.*/
    int  port_id;                      /**<端口信息.*/
    char *mac;                         /**<终端MAC地址.*/
    char *ip;               
    char *username;
    char *agentID;
    char *passwd;
    char communicationkey[32];
	user_conf   user_info;             /**<用户信息.*/
    enum network_transport transport;  /**<网络传输类型.*/
    
    char *rbuf;                 		   /**<读缓冲.*/
    char *rcurr;                       /**<缓冲当前位置.*/
    char *rparse;                      /**<当前解析位置.*/
    int rsize;                         /**<缓冲大小.*/  
    int rcursize;                      /**<缓冲使用大小.*/
    
    struct_transfer  *p_tf;            /**<协议传输层头部.*/
    struct_apply     *p_ap;            /**<协议应用层头部.*/  
    
    struct_transfer   s_tf;            /**<协议传输层头部.*/
    struct_apply      s_ap;            /**<协议应用层头部.*/  
    
    char wbuf[1500];                   /**<返回缓冲状态数据.*/
    int wsize;                        /**<返回数据大小.*/
    char *pret;                         /**<指向返回数据.*/
    
    tnc_measure_data  measure;          /*<策略.*/
    
    conn   *next;
    LIBEVENT_THREAD *thread;           /**<处理该连接的线程.*/
};


static CQ_ITEM *cq_pop(CQ *cq);
static void cq_init(CQ *cq);
static CQ_ITEM *cq_pop(CQ *cq);
static void cqi_free(CQ_ITEM *item);
conn *conn_new(const int sfd, enum conn_states init_state,
                const int event_flags,
                const int read_buffer_size, enum network_transport transport,
                struct event_base *base);
void dispatch_conn_new(int sfd, enum conn_states init_state, int event_flags,
                       int read_buffer_size, enum network_transport transport);
void event_handler(const int fd, const short which, void *arg);                        
bool conn_add_to_freelist(conn *c);
void do_accept_new_conns(const bool do_accept);
static void conn_close(conn *c);
#endif

 #include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <time.h>

#include <ngtawstd/zytypes.h>
#include <nac/nac_topzmq.h>
#include "nac_load_conf.h"
#include "nac_keep_alive.h"
#include "nac_server.h"
#include "parse_request.h"
#include "nac_server_log.h"
#include <comm4proc.h>

extern nac_server_conf nac_conf;

#ifndef CHALLENGE_LENGTH
#define  CHALLENGE_LENGTH   16
#endif

#define FREE_POINT(x) do{if(x!=NULL){ free(x); x=NULL;}}while(0)
#define POINT_CHECK(x) do{if (x==NULL) return NULL;}while(0)
KTL *ktl_head = NULL;
KTL **free_ktl = NULL;
size_t ktl_cur = 0;
size_t ktl_total = 0;
int keepalive_stop = 0;
pthread_mutex_t keepalive_table_lock = PTHREAD_MUTEX_INITIALIZER;

void KTL_init()
{
    LOG(NAC_LOG_DEBUG, "in KTL_init!");
    ktl_total = 200;
    ktl_cur = 0;
    free_ktl = calloc(ktl_total, sizeof(KTL *));
    if (free_ktl == NULL)
    {
        ktl_total = 0;
    }
}

#define BZERO(x, size) memset(x, 0, size)
static int bzero_ktl(KTL *ktl)
{
    BZERO(ktl->ip, 64);
    BZERO(ktl->mac, 32);
    BZERO(ktl->agentID, 64);
    BZERO(ktl->challeng, 32);
    BZERO(ktl->communicationkey, 64);
}

static int ktl_add_to_freektl(KTL *ktl)
{
    if (ktl_cur < ktl_total)
    {
       bzero_ktl(ktl);
       free_ktl[ktl_cur++] = ktl;     
    }
    else
    {
        size_t new_size = (ktl_total==0)?(100):(ktl_total+50);
        KTL **newfreektl = realloc(free_ktl, new_size*sizeof(KTL *));
        if (newfreektl == NULL)
        {
            //printf("memory error!\n");
            LOG(NAC_LOG_ERR, "malloc new freektl error!\n");
            KTL_del(ktl);
            return 0;
        }
        ktl_total = new_size;
        free_ktl = newfreektl;
        bzero_ktl(ktl);
        free_ktl[ktl_cur++] = ktl;
    }
    return 1;
}

static KTL *KTL_new(char *ip, char *mac, char *agentID, char *challeng, char *communicationkey)
{
    KTL * ktl = (KTL* )malloc(sizeof(KTL));
    POINT_CHECK(ktl); 
    ktl->ip = (char *)malloc(64);
    POINT_CHECK(ktl->ip);
    ktl->mac = (char *)malloc(32);
    POINT_CHECK(ktl->mac);
    ktl->agentID = (char *)malloc(64);
    POINT_CHECK(ktl->agentID);
    ktl->challeng = (char *)malloc(32);
    POINT_CHECK(ktl->challeng);
    ktl->communicationkey= (char *)malloc(64);
    POINT_CHECK(ktl->communicationkey);
    memset(ktl->ip, 0, 64);
    memcpy(ktl->ip, ip, strlen(ip));
    
    memset(ktl->mac, 0, 32);
    memcpy(ktl->mac, mac, strlen(mac));
    
    memset(ktl->agentID, 0, 64);
    memcpy(ktl->agentID, agentID, strlen(agentID));
    
    memset(ktl->challeng, 0, 32);
    memcpy(ktl->challeng, challeng, CHALLENGE_LENGTH);
    
    memset(ktl->communicationkey, 0, 64);
    memcpy(ktl->communicationkey, communicationkey, 32);

    ktl->count_f = 0;
    ktl->count_s = 0;
    ktl->cmp_flag = 0;
    ktl->next = NULL;
    ktl->prev = NULL;
    return ktl;
}

void KTL_del(KTL *ktl)
{
    if (ktl != NULL)
    {
        FREE_POINT(ktl->ip);
        FREE_POINT(ktl->mac);
        FREE_POINT(ktl->agentID);
        FREE_POINT(ktl->challeng);
        FREE_POINT(ktl->communicationkey);
        ktl->next = NULL;
        ktl->prev = NULL;
        FREE_POINT(ktl);
    }
}

int keepalive_update_by_agentID(char *agentID, char *ip, char *mac, char *challenge, char *communicationkey)
{
    if (agentID == NULL)
    {
        return 0;
    }
    KTL *tmp = ktl_head;
    do   
    {
        if (strncmp(tmp->agentID, agentID, strlen(agentID)) == 0)
        {
            memcpy(tmp->ip, ip, strlen(ip));
            (tmp->ip)[strlen(ip)] = '\0';
            memcpy(tmp->mac, mac, strlen(mac));
            (tmp->mac)[strlen(mac)] = '\0';
            //memcpy(tmp->agentID, agentID, strlen(agentID));
            //(tmp->agentID)[strlen(agentID)] = '\0';
            memcpy(tmp->challeng, challenge, CHALLENGE_LENGTH);
            (tmp->challeng)[CHALLENGE_LENGTH] = '\0';
            memcpy(tmp->communicationkey, communicationkey, 32);
            (tmp->communicationkey)[32] = '\0';
            return 1; 
        }
        tmp = tmp->next;
    }
    while(tmp != ktl_head && tmp != NULL);
    return 0;
}

void keepalive_table_add(char *ip, char *mac, char *agentID, char *challenge, char *communicationkey)
{
    KTL *ktl = NULL;
    pthread_mutex_lock(&keepalive_table_lock); 
    
    if (ktl_cur > 0 && ktl_total > ktl_cur)
    {
        ktl = free_ktl[--ktl_cur];
        memcpy(ktl->ip, ip, strlen(ip));
        (ktl->ip)[strlen(ip)] = '\0';
        memcpy(ktl->mac, mac, strlen(mac));
        (ktl->mac)[strlen(mac)] = '\0';
        memcpy(ktl->agentID, agentID, strlen(agentID));
        (ktl->agentID)[strlen(agentID)] = '\0';
        memcpy(ktl->challeng, challenge, CHALLENGE_LENGTH);
        (ktl->challeng)[CHALLENGE_LENGTH] = '\0';
        memcpy(ktl->communicationkey, communicationkey, 32);
        (ktl->communicationkey)[32] = '\0';
        ktl->count_s = 0;
        ktl->count_f = 0;
    }
    else
    {
        ktl = KTL_new(ip,mac,agentID,challenge,communicationkey);
    }
    
    if (ktl == NULL)
    {
        pthread_mutex_unlock(&keepalive_table_lock);
        return;       
    }
    if (ktl_head == NULL)
    {
        ktl_head = ktl;
        ktl_head->prev = ktl_head;
        ktl_head->next = ktl_head;
        //printf("ktl_head->agentID = %s\n", ktl_head->agentID);
        LOG(NAC_LOG_DEBUG, "ktl_head->agentID = %s", ktl_head->agentID);
    }
    else
    {
        ktl->prev = ktl_head;
        ktl->next = ktl_head->next;
        ktl_head->next->prev = ktl;
        ktl_head->next = ktl;
        
    }
    pthread_mutex_unlock(&keepalive_table_lock);
}

KTL* keepalive_table_del(KTL *ktl)
{
    //printf("Agent:%s disconnect, time out!\n",ktl->agentID);
    LOG(NAC_LOG_MSG, "ip = %s, Agent:%s disconnect, time out!\n",ktl->ip,ktl->agentID);
    KTL *tmp = NULL;
    if (ktl == NULL || ktl_head == NULL)
        return NULL;
    pthread_mutex_lock(&keepalive_table_lock);    
    if (ktl == ktl->next)
    {
        
        ktl_add_to_freektl(ktl);        
        ktl_head->next = NULL;
        ktl_head->prev = NULL;
        ktl_head = NULL;
        pthread_mutex_unlock(&keepalive_table_lock);
        return ktl_head;
    }
    if (ktl == ktl_head)
    {
        ktl_head = ktl->prev;
    }
    tmp = ktl->next;
    ktl->prev->next = ktl->next;
    ktl->next->prev = ktl->prev;    
    ktl->prev = NULL;
    ktl->next = NULL;
    ktl_add_to_freektl(ktl);    
    pthread_mutex_unlock(&keepalive_table_lock);
    return tmp;
}
char *get_data_by_agentID(char *agentID, int agentID_len, int type)
{

    if (agentID == NULL || agentID_len <= 0 || ktl_head == NULL || type > 4 || type < 0)
        return NULL;
    KTL *tmp = ktl_head;
    do   
    {
        if (strncmp(tmp->agentID, agentID, agentID_len) == 0)
        {
            switch(type)
            {
                case 0:
                    return tmp->ip;
                    break;
                case 1:
                    return tmp->mac;
                    break;
                case 2:
                    return tmp->agentID;
                    break;
                case 3:
                    return tmp->challeng;
                    break;
                case 4:
                    return tmp->communicationkey;
                    break;
            }
        }
        tmp = tmp->next;
    }
    while(tmp != ktl_head && tmp != NULL);
    return NULL;
}

char *get_communicationkey_by_agentID(char *agentID, int agentID_len)
{
    if (agentID == NULL || agentID_len <= 0 || ktl_head == NULL)
        return NULL;
    KTL *tmp = ktl_head;
    do   
    {
        if (strncmp(tmp->agentID, agentID, agentID_len) == 0)
        {
            return tmp->communicationkey;
        }
        tmp = tmp->next;
    }
    while(tmp != ktl_head && tmp != NULL);
    return NULL;
}
int check_KTL_in_table(char *buf, int buflen, int flag)
{
    if (buf== NULL || ktl_head == NULL || buflen <= 0)
        return 0;
    KTL *tmp = ktl_head;
    if (ktl_head == NULL)
        return 0;
    int i = 0;
    switch(flag)
    {
        case IP_FLAG:
            break;
        case MAC_FLAG:
            break;
        case AGENTID_FLAG:        
            while(1)
            {
                if (strncmp(tmp->agentID, buf, buflen)== 0)
                {
                    pthread_mutex_lock(&keepalive_table_lock);
                    tmp->count_f = 0;
                    //tmp->count_s ++;
                    pthread_mutex_unlock(&keepalive_table_lock);
                    return 1;
                }
                tmp = tmp->next;
                if (tmp == ktl_head || tmp == NULL)
                    break;
            }
            break;
        case CHALLENGE_LENGTH:
            break;
    }
    
    return 0;
}
static void KTL_count_add()
{
    KTL *tmp = ktl_head;
    if (ktl_head == NULL)
        return;
    while(1)
    {
        pthread_mutex_lock(&keepalive_table_lock);
        tmp->count_f++;
        tmp->count_s++;
        pthread_mutex_unlock(&keepalive_table_lock);        
        //在5分钟内发送3次的keepalive给ngunp
        //if (tmp->count_s >= ((5*60*1000) / (3*nac_conf.server.keepalive_msec)))
        //{
        //    tmp->count_s = 0;
        //    Ctr_online_ngump_by_socket("keepalive",tmp->ip, tmp->mac, tmp->agentID);
        //}
        if (tmp->count_f >= nac_conf.server.keepalive_times)
        {
            //printf("offline ip = %s\n", tmp->ip);
            LOG(NAC_LOG_MSG, "offline ip = %s\n", tmp->ip);
            tmp->count_f = 0;
            Ctr_online_ngump_by_socket("offline",tmp->ip, tmp->mac, tmp->agentID);
            tmp = keepalive_table_del(tmp);
        }
        else
        {
            tmp = tmp->next;
        }
        if (tmp == ktl_head || tmp == NULL)
           break;
    }
}

static void check_keepalive_table()
{
    //KTL *ktl = ktl_head;
    while(!keepalive_stop)
    {
        usleep(nac_conf.server.keepalive_msec * 1000);
        KTL_count_add();
    }
}

static void nac_ngump_user_check()
{
    KTL *ktl = ktl_head;
    comm4proc_t *cpt = NULL;
    ZYMap *sendmap = zymap();
    ZYList *list = NULL;
    ZYList *list_ktl = NULL;
    ZYElem *list_pos = NULL;
    ZYMap *list_map = NULL;
    char *psend = NULL;

    int len = 0; 
    int nret = -1;
    comm4proc_data_node *node = NULL;
    sleep(60);
    while(!keepalive_stop)
    {
        usleep(nac_conf.server.check_time*1000*1000);
        /*
        time_t tm;time(&tm); struct tm *tf = localtime( &tm );
        char time[32];
        snprintf( time, 32, "%04d-%02d-%02d %02d:%02d:%02d",
                1900+tf->tm_year, 1+tf->tm_mon, tf->tm_mday,
                tf->tm_hour, tf->tm_min, tf->tm_sec );
                */
        char cur_time[32];
        get_cur_time(cur_time, 32);
        //printf("get ngump user time : %s\n", cur_time);
        LOG(NAC_LOG_DEBUG, "get ngump user time : %s\n", cur_time);
        cpt = comm4proc_init( COMM4PROC_TYPE_UNIX, COMM4PROC_MODEL_CLIENT, "/dev/comm4proc", 0 );
        if (cpt == NULL)
        {
            //printf("Can't read ngunp data!\n");
            LOG(NAC_LOG_WARN, "Can't read ngunp data!\n");
            goto free_position;
        }        
        zymap_put_str( sendmap, _K("s_cmd"), "online_query");
        zymap_put_str( sendmap, _K("s_need_reply"), "yes");
        zymap_put_int32( sendmap, _K("i_type"), 1 );
        psend = zydump_zymap_ptr( sendmap, &len, 0);
        nret = comm4proc_write_msg( cpt, psend, len );
        if (psend)
        {
            taw_free(psend);
            psend = NULL;
        }
        if ( nret == 0 )
        {
            LOG(NAC_LOG_DEBUG, "SEND succ, cmd = %s len:%d\r\n","online_query", len);
            //printf( "SEND succ, cmd = %s len:%d\r\n","online_query", len);
        }
        else
        {
            LOG(NAC_LOG_DEBUG, "SEND fail, cmd = %s len:%d\r\n","online_query", len);
            //printf( "SEND fail, cmd = %s len:%d\r\n","online_query", len);
            goto free_position;
        }
        node = comm4proc_read_msg( cpt );
        if ( node )
        {
            LOG(NAC_LOG_DEBUG, "read msg has data, node->len = %d\n", node->len);
            //printf("read msg has data, node->len = %d\n", node->len);
            if (node->len <= 0)
                goto free_position;
                //continue;
            if ( node->len > 0 )
            {
                list = zyload_zylist_ptr( node->data, node->len);
                LOG(NAC_LOG_DEBUG, "ngunp -------ip list\n");
                //printf("ngunp -------ip list\n");
                list_pos = NULL;
                if (list)
                {
                    ZYLIST_FOR_EACH(list, list_pos)
                    {
                        if (list && list_pos->map)
                        {
                            list_map = list_pos->map;
                            const char *ip = zymap_get_str( list_map, _K("s_key"));
                            LOG(NAC_LOG_DEBUG, "  %s\n", ip);
                            //printf("  %s\n", ip);
                        }
                    }
                }
                LOG(NAC_LOG_DEBUG, "--------------------\n");
                //printf("--------------------\n");
            }
            free_data_node(node);
            node = NULL;
        }
        /*
            分四种情况比较：
                1、nac和ngump中的数据都为空
                2、nac数据为空，ngump中有数据，则将ngump中的数据清空
                3、nac有数据，ngump中无数据，则将nac中的数据添加至ngump中
                4、nac和ngump均有数据，此种情况3种情况
                    a、nac和ngump中的数据一样
                    b、nac中的数据比ngump中的多，则将nac中多余的数据添加至ngump中
                    c、nac中的数据比ngump中的少，则将ngump中多余的数据清除

                两个链表比较方法说明：
                    A、B两链表均有比较标记F，F初始值为0，A中元素循环与B进行比较，当A与B当中有相当元素时
                    将两者的F均设为1，其循环次数为:A元素个数xB元素个数
                    然后再循环遍历A和B链表，判断F标记就可知道A与B中不同元素
        */
        pthread_mutex_lock(&keepalive_table_lock);
        ktl = ktl_head; 
        if (ktl == NULL)
        {
            if (list == NULL)
            {
                goto free_position;
            }
            list_pos = NULL;
            ZYLIST_FOR_EACH(list,list_pos)
            {
                if ( list_pos && list_pos->map )
                {
                    list_map = list_pos->map;
                    const char *s_key = zymap_get_str( list_map, _K("s_key") );
                    int is_nac = zymap_get_int32( list_map, _K("i_nac"));
                    if (!is_nac)
                        continue;
                    zymap_put_str( sendmap, _K("s_key"), s_key);
                    zymap_put_str( sendmap, _K("s_cmd"), "offline");
                    zymap_put_str( sendmap, _K("s_need_reply"), "no");
                    zymap_put_int32( sendmap, _K("i_type"), 1 );                    
                    len = 0;
                    psend = zydump_zymap_ptr( sendmap, &len, 0);
                    nret = comm4proc_write_msg( cpt, psend, len );
                    if (psend)
                    {
                        taw_free(psend);
                        psend = NULL;
                    }
                    if (nret != 0 )
                    {
                        DEBUG_LOG("nac = NULL, ngunp != NULL, send %s offline fail\n", s_key);
                        //printf("nac = NULL, ngunp != NULL, send %s offline fail\n", s_key);
                    }
                    else
                    {
                        MSG_LOG("nac = NULL, ngunp != NULL, send %s offline sucess\n", s_key);
                    }
                 }
            }
        }
        else
        {
            while(ktl != NULL)
            {
                if (list == NULL)
                {
                    char *ip = ktl->ip;
                    char *mac = ktl->mac;
                    char *agentID = ktl->agentID;
                    zymap_put_str( sendmap, _K("s_key"), ip);
                    zymap_put_str( sendmap, _K("s_ip"), ip);
                    zymap_put_str( sendmap, _K("s_mac"), mac);
                    zymap_put_str( sendmap, _K("s_agentid"), agentID);
                    zymap_put_str( sendmap, _K("s_cmd"), "online");
                    zymap_put_str( sendmap, _K("s_need_reply"), "no");
                    zymap_put_int32( sendmap, _K("i_type"), 1 );                    
                    zymap_put_int32( sendmap, _K("i_nac"), 1 );
                    len = 0;
                    psend = zydump_zymap_ptr( sendmap, &len, 0);
                    nret = comm4proc_write_msg( cpt, psend, len );
                    if (psend)
                    {
                        taw_free(psend);
                        psend = NULL;
                    }
                    if (nret != 0 )
                    {
                        DEBUG_LOG("write %s online msg error !\n", ip);
                    }
                    else
                    {
                        //printf("write %s online msg true\n", ip);
                        MSG_LOG("write %s online msg true\n", ip);
                    }
                }
                else
                {
                    //仅仅只是比较，不做处理
                    list_pos = NULL;
                    ZYLIST_FOR_EACH(list, list_pos)
                    {
                        if (list_pos && list_pos->map)
                        {
                            list_map = list_pos->map;
                            const char *s_key = (char *) zymap_get_str( list_map, _K("s_key") );
                            if (s_key && (strcmp(s_key, ktl->ip) == 0))
                            {
                                ktl->cmp_flag = 1;
                                zylist_remove_zymap(list, list_map);
                                break;
                                //zymap_put_int32(list_map, _K("del_flag"), 1);
                            }
                        }
                    }
                }
                ktl = ktl->next;
                if (ktl == ktl_head || ktl == NULL)
                {
                    break;
                }
            }
            //将前面比较的结果进行计算
            while( ktl!=NULL )
            {
                if (ktl->cmp_flag == 0)
                {
                    //上线
                    char *ip = ktl->ip;
                    char *mac = ktl->mac;
                    char *agentID = ktl->agentID;
                    zymap_put_str( sendmap, _K("s_key"), ip);
                    zymap_put_str( sendmap, _K("s_ip"), ip);
                    zymap_put_str( sendmap, _K("s_mac"), mac);
                    zymap_put_str( sendmap, _K("s_agentid"), agentID);
                    zymap_put_str( sendmap, _K("s_cmd"), "online");
                    zymap_put_str( sendmap, _K("s_need_reply"), "no");
                    zymap_put_int32( sendmap, _K("i_type"), 1 );                   
                    zymap_put_int32( sendmap, _K("i_nac"), 1 );
                    len = 0;
                    psend = zydump_zymap_ptr( sendmap, &len, 0);
                    nret = comm4proc_write_msg( cpt, psend, len );
                    if (psend)
                    {
                        taw_free(psend);
                        psend = NULL;
                    }                    
                    if (nret != 0 )
                    {
                        DEBUG_LOG("=write %s online msg error !\n", ip);
                    }
                    else
                    {
                        MSG_LOG("=write %s online msg sucess !\n", ip);
                    }
                }
                ktl->cmp_flag = 0;
                ktl = ktl->next;
                if (ktl == ktl_head || ktl == NULL)
                {
                    break;
                }
            }
            if (list != NULL)
            {
            ZYLIST_FOR_EACH(list, list_pos)
            {
                //下线
                if ( list_pos && list_pos->map )
                {
                    list_map = list_pos->map;
                    const char *s_key = (char *)zymap_get_str( list_map, _K("s_key") );
                    const char *s_ip = (char *)zymap_get_str( list_map, _K("s_ip") );
                    const char *s_mac = (char *)zymap_get_str( list_map, _K("s_mac") );
                    const char *s_agentID = (char *)zymap_get_str( list_map, _K("s_agentid") );
                    int is_nac = zymap_get_int32( list_map, _K("i_nac"));
                    if (!is_nac)
                        continue;
                    zymap_put_str( sendmap, _K("s_key"), s_key);
                    zymap_put_str( sendmap, _K("s_cmd"), "offline");
                    zymap_put_str( sendmap, _K("s_need_reply"), "no");
                    zymap_put_int32( sendmap, _K("i_type"), 1 );                     
                    len = 0;
                    psend = zydump_zymap_ptr( sendmap, &len, 0);
                    nret = comm4proc_write_msg( cpt, psend, len );
                    if (psend)
                    {
                        taw_free(psend);
                        psend = NULL;
                    }
                    if (nret != 0 )
                    {
                        ERR_LOG("==-= %s offline error\n", s_ip);
                        continue;
                    }
                    else
                    {
                        MSG_LOG("==-= %s offline sucess \n", s_ip);
                    }
                 }
            }
            }
        }

free_position:
        pthread_mutex_unlock(&keepalive_table_lock);
        if (cpt)
        {
            comm4proc_fini(cpt);
            cpt = NULL;
        }
        if (list)
        {
            zylist_free(list);
            list = NULL;
        }
        //if (node)
        //{
        //    free_data_node(node);
        //    node = NULL;
        //}
        if (psend)
        {
            taw_free(psend);
            psend = NULL;
        }

    }
    if (sendmap)
    {
        zymap_free(sendmap);
        sendmap = NULL;
    }
}

void keep_alive_table_work()
{
    pthread_t		keepalive_thread, cmp_thread;
    pthread_attr_t	keepalive_attr, cmp_attr;
    int				ret;

    pthread_attr_init(&keepalive_attr);
    pthread_attr_init(&cmp_attr);

    if ((ret = pthread_create(&keepalive_thread, &keepalive_attr, (void *)&check_keepalive_table, NULL)) != 0)
    {
        ERR_LOG("Can't create keepalive thread: %s\n", strerror(ret));
        //fprintf(stderr,	"Can't create keepalive thread: %s\n",
        //        strerror(ret));
        exit(1);
    }

    if ((ret = pthread_create(&cmp_thread, &cmp_attr, (void *)&nac_ngump_user_check, NULL)) != 0)
    {
        ERR_LOG("Can't create user check thread : %s\n",
                strerror(ret));
        exit(1);
    }
}






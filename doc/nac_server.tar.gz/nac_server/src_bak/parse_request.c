﻿#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <time.h>

#include <ngtawstd/zytypes.h>
#include <nac/nac_topzmq.h>
#include <nac/nac_policy.h>

#include "nac_parse_xml.h"
#include "nac_server.h"
#include "PAM_check_user.h"
#include "parse_request.h"
#include "nac_keep_alive.h"
#include "nac_load_conf.h"
#include "md5.h"
#include "nac_server_log.h"
#include <comm4proc.h>
#include <readline/readline.h>
#include <shorm/shorm.h>

extern nac_server_conf  nac_conf;
extern nac_zmq_context zmq_context;

struct tm *time_strtotm(char *time)
{
	char *p = time;
	if (time == NULL)
		return NULL;
	struct tm *return_tm = (struct tm *)malloc(sizeof(struct tm));
	if (return_tm == NULL)
		return NULL;
	char *p_start = NULL;
	char *p_end = NULL;
	p_start = p_end = p;
	int p_len = 0;
	int p_type = 0;
	char year[5] = "";
	char mouth[3] = "";
	char day[3] = "";
	char hour[3] = "";
	char miniter[3] = "";
	char second[3] = "";
	while(*p_end != '\0')
	{
		if (*p_end == '-' || *p_end == ' ' || *p_end == ':')
	    {
			switch(p_type)
			{      
				case 0:
					strncpy(year, p_start, p_len);
					break;
				case 1:
				    strncpy(mouth, p_start, p_len);
				    break;
				case 2:
				    strncpy(day, p_start, p_len);
				    break;                  
				case 3:                     
					strncpy(hour, p_start, p_len);
					break;                  
			    case 4:                     
			        strncpy(miniter, p_start, p_len);
			        break;                  
				case 5:                     
				    strncpy(second, p_start, p_len);
                    break;                  
       		}      
			p_len = 0;
			p_start = p_end+1;
			p_type ++;
		}
		else
		{
			p_len ++;
		}
		p_end ++;
	}
	strncpy(second, p_start, p_len);
	
	return_tm->tm_sec = atoi(second);
	return_tm->tm_min = atoi(miniter);
	return_tm->tm_hour = atoi(hour);
	return_tm->tm_mday = atoi(day);
	return_tm->tm_mon = atoi(mouth) - 1;    //mktime在生成的时候月份从0开始
	return_tm->tm_year = atoi(year) - 1900;//mktime中生成的秒数是从1900年~今的
	return return_tm;
}
shorm_conf *def_conf = NULL;
void offline_user_init()
{
    shorm_files my_shorm; 
    //shorm_conf *my_conf = def_conf;
    shorm_files_set_default_file(&my_shorm);
    def_conf = shorm_init(&my_shorm);
}

void offline_user_finsh()
{
    shorm_free(def_conf);
}
int is_offline_user_timeout(char *ip, char *mac)
{
    shorm_conf *my_conf = def_conf;
    if (my_conf == NULL)
    {
        //printf("offline table wasn't open!\n");
        MSG_LOG("offline table wasn't open!\n");
        return 0;
    }
    ZYList *list = NULL;
    ZYMap *map = NULL;

    char pattern[128] = "";
    int result = 0;//返回结果，0为不在offline中，1为在其中
    
    const char *svalue = 0;

    long lofftime = 0;
    long nowtime = 0;
    long lduration = 0;
    struct tm *offtime_tm;

    snprintf(pattern, 128, "e.ip = '%s'", ip);
    list = shorm_list_data_get(my_conf, "offlineuser",pattern, NULL);
    if (list == NULL)
    {
        DEBUG_LOG("list = NULL\n");
        return 0;
    }
    if (_ZLLen(list) > 0)
    {
        map = (ZYMap *)zylist_get_zymap(list, 0);
        if (svalue = zymap_get_str(map, _K("offtime")))
        {
            offtime_tm = time_strtotm((char *)svalue);
            if (offtime_tm != NULL)
            {
                lofftime = (long)mktime(offtime_tm);
                free(offtime_tm);
            }
        }
        if (svalue = zymap_get_str(map, _K("duration")))
        {
            lduration = atol(svalue);
        }
        nowtime = (long)time(0);

        if (nowtime - lofftime > lduration)
        {
            result = 0;
        }
        else
        {
            result = 1;
        } 
    }
    else
    {
        result = 0;
    }
    zymap_free(map);
    zylist_free(list);
    return result;
}

/*
    上线、下线、在线用户查询等

    返回值说明：
        当cmd不识别时返回-1
        当cmd == online || cmd == offline || cmd == keepalive
        其返回0
        当cmd == online_num时
        其返回在线数
        当cmd == blackwhite_check时
        其为白名单返回1，黑名单返回2，其他返回0或3
        当cmd == online_query时
        其ip处于在线列表时，其返回1，否则返回0

 */
ZYList *online_list = NULL;

int Ctr_online_ngump_by_socket(char *cmd, char *ip, char *mac, char *agentID)
{
	u_int32_t count = 0;    //当要获取在线数时，返回此值
    int result_check = 0;   //当判断黑白名单时，返回此值
    int is_online = 0;
    char need_reply[4];
    char s_ip[32];
    if (ip == NULL && mac == NULL)
    {
        return -1;
    }
	if (!(strncmp(cmd, "online", 6) == 0 || strncmp(cmd, "offline", 7) == 0 || strncmp(cmd, "online_num", 10) == 0 || strncmp(cmd, "keepalive",9) == 0 || strncmp(cmd, "blackwhite_check", 16) == 0 || strncmp(cmd, "online_query", 12) == 0))
	{
		//printf("commd error!\n");
        ERR_LOG("send ngunp commd error!\n");
		return -1;
	}
    memset(need_reply, 0, 4);
    if (strncmp(cmd, "online_num", 10) == 0 || strncmp(cmd, "blackwhite_check", 16) == 0 || strncmp(cmd, "online_query", 12) == 0)
    {
        strncpy(need_reply, "yes", 3);
    }
    else
    {
        strncpy(need_reply, "no", 2);
    }
    comm4proc_t *cpt = comm4proc_init( COMM4PROC_TYPE_UNIX, COMM4PROC_MODEL_CLIENT, "/dev/comm4proc", 0 );
    if (cpt == NULL)
    {
        ERR_LOG("ERROR:comm4proc init fail!\n");
        return -1;
    }
    ZYMap* map = zymap();
	zymap_put_str( map, _K("s_key"), ip );
	zymap_put_str( map, _K("s_ip"), ip);
    zymap_put_str( map, _K("s_agentid"), agentID);
	zymap_put_str( map, _K("s_cmd"), cmd); // cmd: online 上线，offline 下载.
	zymap_put_str( map, _K("s_mac"), mac);
    zymap_put_str( map, _K("s_need_reply"),need_reply);
	zymap_put_int32( map, _K("i_type"), 1 );
    zymap_put_int32( map, _K("i_nac"), 1 );    //是否由nac_server认证上线

    if (strncmp(cmd, "blackwhite_check", 16) == 0)
    {
        zymap_put_int32( map, _K("i_ipversion"), 4);
    }

	int len = 0;
	char *psend = zydump_zymap_ptr(map, &len, 0); 
    
    time_t tm;
    time(&tm);
    struct tm *tf = localtime( &tm );
    char time[32];
    snprintf( time, 32, "%04d-%02d-%02d %02d:%02d:%02d",
            1900+tf->tm_year, 1+tf->tm_mon, tf->tm_mday,
            tf->tm_hour, tf->tm_min, tf->tm_sec );

	int nret = comm4proc_write_msg( cpt, psend, len );
	if ( nret == 0 )
	{
        DEBUG_LOG("SEND succ,ip = %s cmd = %s len:%d time : %s\r\n",ip, cmd, len, time);
	}
	else
    {
        DEBUG_LOG("SEND fail,ip = %s cmd = %s len:%d time : %s\r\n",ip, cmd, len, time);
        
        if (map != NULL)
            zymap_free(map);

        if (psend != NULL)
            taw_free(psend);
        
        comm4proc_fini(cpt);
        return -1;
    }

	if (map != NULL)
		zymap_free(map);

	if (psend != NULL)
		taw_free(psend);

    /* -----------需要返回结果的操作---------------------*/
        //在线用户查询
        if (strcasecmp(cmd,"online_num") == 0)
        {
            comm4proc_data_node *node = comm4proc_read_msg( cpt );
            if ( node )
            {   
                if ( node->len > 0 ) 
                {   
                    ZYMap* map = zyload_zymap_ptr( node->data, node->len);
                    if ( map )
                    {   
                        const char * s_query_time = zymap_get_str( map, _K("s_query_time") );                    
                        int flag = 0;
                        count = zymap_get_int32( map, _K("i_online_num"), &flag );
                        DEBUG_LOG("s_query_time:%s, num:%d\r\n", s_query_time, count);

                        zymap_free(map);
                    }   
                } 
            free_data_node( node );
            comm4proc_fini(cpt);
            return count;
          }
      }
      //黑白名单查询：白名单为1，黑名单为2
      if (strcasecmp(cmd, "blackwhite_check") == 0)
      {
          comm4proc_data_node *bnode = comm4proc_read_msg( cpt );
          if (bnode)
          {
              if (bnode->len > 0)
              {
                  ZYMap *bmap = zyload_zymap_ptr( bnode->data, bnode->len);
                  if ( bmap )
                  {
                      const char * s_result = zymap_get_str( bmap, _K("s_result"));
                      int flag = 0;
                      result_check = zymap_get_int32( bmap, _K("i_check_result"), &flag);
                      zymap_free( bmap );
                  }
              }
              free_data_node( bnode );
              comm4proc_fini( cpt );
              return result_check;
          }
      }
      //判断是否为在线用户
      if (strcasecmp(cmd, "online_query") == 0)
      {
          is_online = 0;
          comm4proc_data_node *bnode = comm4proc_read_msg( cpt );
          if (bnode)
          {
              if (bnode->len > 0)
              {
                  ZYList *list = zyload_zylist_ptr( bnode->data, bnode->len);
                  if ( list )
                  {
                      ZYElem* pos=NULL;
                      ZYLIST_FOR_EACH(list,pos)
                      {
                          if ( pos && pos->map )
                          {
                              ZYMap *tm = pos->map;
                              const char *s_key = zymap_get_str( tm, _K("s_key") );
                              if ( s_key && strcmp(ip, s_key ) == 0 )
                              {
                                  is_online = 1;
                                  break;
                              }
                          }
                      }
                      zylist_free( list );
                  }
              }
              free_data_node( bnode );
              comm4proc_fini( cpt );
              return is_online;
          }
      }
    comm4proc_fini(cpt);
    return 0;
}

void send_nac_auth_log(conn *c,char *reason)
{
}

void send_nac_health_log(conn *c,char *status)
{
}
/*
    分析登陆用户信息
*/
void parse_auth_start_data(conn *c)
{
    char * p_value=NULL;
    xmlDocPtr doc=NULL;
    xmlNodePtr root=NULL;
    //printf("c->measure.tnccs_data+sizeof(struct_apply) : \n%s\n", c->measure.tnccs_data+sizeof(struct_apply));
    doc = parse_xml_doc(c->measure.tnccs_data+sizeof(struct_apply),&root,c->measure.data_size-sizeof(struct_apply), 0);
    if (doc == NULL)
    {
        printf("Xml file error!\n");
        get_auth_fail_data(c,"Xml解析错误！",-20);
        ERR_LOG("Xml parse error! result = %d\n", -20);
        //send_nac_auth_log(c,"xml解析错误！");
        c->ag_state=agent_auth_fail;
        goto end;
    }
    p_value = get_path_node_value(root, "message.head.type");
    if (p_value != NULL)
    {
        if (strncmp(p_value, "Logon", 5) == 0)  //登陆信息
        {
        
            if (p_value=get_path_node_value(root,"message.body.Request.AgentInfo.Identity")){
                c->measure.identity=p_value;
            }else{
                if(nac_conf.is_auth){ //是否配置了认证
                    printf("have not receive  user or mac\n");
                    get_auth_fail_data(c,"缺乏有效的用户名或密码",-1);
                    MSG_LOG("have not recive user name or passwd! result = %d\n", -1);
                    c->ag_state=agent_auth_fail;
                    goto end;
                }
            }
            if (p_value=get_path_node_value(root,"message.body.Request.AgentInfo.Identity")){
                c->username=p_value;
            }else{
                if(nac_conf.is_auth){ //是否配置了认证
                    printf("have not receive  user or mac\n");
                    get_auth_fail_data(c,"缺乏有效的用户名或密码",-1);
                    MSG_LOG("have not recive user name or passwd! result = %d\n", -1);
                    c->ag_state=agent_auth_fail;
                    goto end;
                }
            }
            if (p_value=get_path_node_value(root,"message.body.Request.AgentInfo.NetConfig.IP")){
                c->ip=p_value;
            }else{ //mac地址必须要
                printf("have not receive  user or mac\n");
                get_auth_fail_data(c,"缺乏有效的用户IP",-2);
                MSG_LOG("have not receive user ip! result = -2\n");
                c->ag_state=agent_auth_fail;
                goto end;
            }
            if (p_value=get_path_node_value(root,"message.body.Request.AgentInfo.NetConfig.Mac")){
                c->mac=p_value;
            }else{ //mac地址必须要
                printf("have not receive  user or mac\n");
                get_auth_fail_data(c,"缺乏有效的用户MAC",-3);
                MSG_LOG("ip %s have not receive user mac! result = -3\n", c->ip);
                c->ag_state=agent_auth_fail;
                goto end;
            }
            if (p_value=get_path_node_value(root,"message.body.Request.AgentID")){
                c->agentID=p_value;
            }else{ //mac地址必须要
                //printf("have not receive  user or mac\n");
                get_auth_fail_data(c,"缺乏有效的用户AgentID",-4);
                MSG_LOG("ip %s have not receive user agentID! result = -4\n", c->ip);
                c->ag_state=agent_auth_fail;
                goto end;
            }
            if(c->measure.buffer_size<CHALLENGE_LENGTH+sizeof(struct_apply)+4){
                c->measure.tnccs_data=realloc(c->measure.tnccs_data,CHALLENGE_LENGTH+sizeof(struct_apply)+4+1);
                c->measure.buffer_size=CHALLENGE_LENGTH+sizeof(struct_apply)+4;
            }
            memcpy(c->measure.tnccs_data+sizeof(struct_apply),"_5DM",4);
            //get_rand_str(c->measure.tnccs_data+sizeof(struct_apply)+4,CHALLENGE_LENGTH);
            memset(c->measure.tnccs_data+sizeof(struct_apply)+4, '1', CHALLENGE_LENGTH);
            c->measure.data_size=CHALLENGE_LENGTH+sizeof(struct_apply)+4;
            c->measure.send_size=0;
            if(c->measure.challenge){
                free(c->measure.challenge);
                c->measure.challenge=NULL;
            }
            c->measure.challenge=calloc(CHALLENGE_LENGTH+1,1);
            memcpy(c->measure.challenge,c->measure.tnccs_data+sizeof(struct_apply)+4,CHALLENGE_LENGTH);

            c->s_ap.type='B';
            c->s_ap.phase='A';
            c->s_ap.data_length=CHALLENGE_LENGTH+4;
            memcpy(c->measure.tnccs_data, &(c->s_ap),sizeof(struct_apply));
        }
    }
    else
    {
        get_auth_fail_data(c,"Xml头部缺少type",-5);
        MSG_LOG("ip %s Xml header lost type! result = -5\n", c->ip);
        c->ag_state=agent_auth_fail;
        goto end;
    }
end:
    destroy_xml_doc(doc);			
}

void creat_policy_request_data(conn *c)
{
    int fd=0;
    struct stat sb; 
    int tmp_length=0;
    char msg_dir[128]="";
    snprintf(msg_dir,128,"%s/%s",POLICYPATH,c->measure.cur_policy->req_msg);
    printf("msg_dir : %s\n", msg_dir);
    if((fd = open(msg_dir, O_RDWR | O_CREAT, S_IRUSR | S_IWUSR))==-1){
        printf("open file:%s erron\n",msg_dir);
        c->go_state=conn_closing;
        return;
    }
    if (fstat(fd, &sb) == -1){
        printf("stat file:%s erron\n",msg_dir);
        close(fd);
        c->go_state=conn_closing;
        return;
    }
    tmp_length = sb.st_size;
    if(c->measure.buffer_size<tmp_length+sizeof(struct_apply)+2){
        c->measure.tnccs_data=realloc(c->measure.tnccs_data,tmp_length+sizeof(struct_apply)+2);
        c->measure.buffer_size=tmp_length+sizeof(struct_apply)+1;
    }
    read(fd,c->measure.tnccs_data+sizeof(struct_apply),tmp_length);
    c->measure.data_size=tmp_length+sizeof(struct_apply)+1;  //需要结尾加一个0
    c->measure.send_size=0;
    close(fd);
    c->s_ap.phase='C';
    c->s_ap.type='X';
    c->s_ap.data_length=tmp_length+1;
    memcpy(c->measure.tnccs_data, &(c->s_ap),sizeof(struct_apply));
    c->measure.tnccs_data[tmp_length+sizeof(struct_apply)]='\0';
}

void creat_agent_addr_data(conn *c)
{
    int tmp_length=strlen(c->measure.addrmsg);
    if(c->measure.buffer_size<tmp_length+sizeof(struct_apply)){
        c->measure.tnccs_data=realloc(c->measure.tnccs_data,tmp_length+sizeof(struct_apply)+1);
        c->measure.buffer_size=tmp_length+sizeof(struct_apply);
    }
    memcpy(c->measure.tnccs_data+sizeof(struct_apply),c->measure.addrmsg,tmp_length);
    c->measure.data_size=tmp_length+sizeof(struct_apply)+1;
    c->measure.send_size=0;
    c->s_ap.phase='R';
    c->s_ap.type='X';
    c->s_ap.data_length=tmp_length;
    memcpy(c->measure.tnccs_data,&(c->s_ap),sizeof(struct_apply));
}

void creat_recommand_data(conn *c)
{
    if(c->measure.buffer_size<RECOMMEN_NUM){
        c->measure.tnccs_data=realloc(c->measure.tnccs_data,RECOMMEN_NUM+1);
        c->measure.buffer_size=RECOMMEN_NUM;
    }
    c->measure.status = get_recommend_msg(&(c->measure),c->measure.tnccs_data+sizeof(struct_apply),RECOMMEN_NUM);
    c->measure.data_size=strlen(c->measure.tnccs_data+sizeof(struct_apply))+sizeof(struct_apply)+1;
    c->measure.send_size=0;
    c->s_ap.phase='R';
    c->s_ap.type='X';
    c->s_ap.data_length=c->measure.data_size-sizeof(struct_apply);
    memcpy(c->measure.tnccs_data, &(c->s_ap),sizeof(struct_apply)); 
}
/*
    回复ASK数据
*/
void full_ack_data(conn *c,int  parameter, char *proto)
{
    //strncpy(c->s_tf.proto,proto, strlen(proto));
    memset(c->s_tf.proto, 0, 4);
    memcpy(c->s_tf.proto, proto, 4);
    c->s_tf.flag='L';
    c->s_tf.type='A';			
    c->s_tf.data_length=0;
    c->s_tf.parameter=parameter;

    memcpy(c->wbuf,&(c->s_tf),sizeof(struct_transfer));
    c->wsize=sizeof(struct_transfer);
    c->wbuf[c->wsize]='\0';

}

/*
    响应策略数据填充
*/

void full_response_data(conn *c,unsigned char *proto)
{
    if((c->measure.data_size-c->measure.send_size) >DATA_MUT){
        strcpy(c->s_tf.proto,proto);
        c->s_tf.flag=c->measure.send_size>0?'C':'L';
        c->s_tf.type='P';
        c->s_tf.data_length=DATA_MUT;
        c->s_tf.parameter=(c->measure.send_size>0)?c->measure.send_size:c->measure.data_size;
        memcpy(c->wbuf,&(c->s_tf),sizeof(struct_transfer));
        memcpy(c->wbuf+sizeof(struct_transfer),
                c->measure.tnccs_data+c->measure.send_size,DATA_MUT);
        c->measure.send_size+=	DATA_MUT;
        c->wsize=sizeof(struct_transfer)+DATA_MUT;
    }else{
        strcpy(c->s_tf.proto,proto);
        c->s_tf.flag=c->measure.send_size>0?'E':'L';
        c->s_tf.type='P';
        c->s_tf.data_length=c->measure.data_size-c->measure.send_size;
        c->s_tf.parameter=(c->measure.send_size>0)?c->measure.send_size:c->measure.data_size;
        memcpy(c->wbuf,&(c->s_tf),sizeof(struct_transfer));
        memcpy(c->wbuf+sizeof(struct_transfer),
                c->measure.tnccs_data+c->measure.send_size,
                c->measure.data_size-c->measure.send_size);
        c->wsize=sizeof(struct_transfer)+c->measure.data_size-c->measure.send_size;
        c->measure.send_size=c->measure.data_size=0;
    }

}

char *CreateCommunicationKey(conn *c)
{
    get_rand_str(c->communicationkey, 32);
    return c->communicationkey;
}

void get_auth_fail_data(conn *c,char *reason,int sec)
{
    int size=0;
    time_t newTime=time(NULL);
    char timefix[128]="";
    char buffer[1024]="";
    struct tm *localTime =  gmtime(&newTime);
    strftime(timefix,128,"%Y\\%m\\%d\\ %H:%M:%S",localTime);

    snprintf(buffer,1024,
            "<?xml version=\"1.0\" encoding=\"utf-8\"?>"
            "<message>"
            "<header>"
            "<id/><from>tdsvc.entry</from><to>tdsvr.agent</to>"
            "<type>LogonResult</type>"
            "<gentime>%s</gentime>"
            "</header>"
            "<body><Respond>"
            "<Result code=\"%d\">%s</Result>"
            "</Respond></body>"
            "</message>\0"
            ,timefix,sec,reason);

    size=strlen(buffer)+1;
    if(c->measure.buffer_size<size+sizeof(struct_apply)){
        c->measure.tnccs_data=realloc(c->measure.tnccs_data,size+sizeof(struct_apply)+1);
        c->measure.buffer_size=size+sizeof(struct_apply)+1;
    }

    c->s_ap.type='X';
    c->s_ap.phase='R';  
    c->s_ap.data_length=size;

    memcpy(c->measure.tnccs_data+sizeof(struct_apply),buffer,size);
    memcpy(c->measure.tnccs_data,&(c->s_ap),sizeof(struct_apply));
    c->measure.data_size=size+sizeof(struct_apply);
    c->measure.send_size=0;
}

void get_auth_success_data(conn *c,char *reason,int sec, int keepalive_msec, int keepalive_times)
{
    int size=0;
    time_t newTime=time(NULL);
    char timefix[128]="";
    char buffer[1024]="";
    struct tm *localTime =  gmtime(&newTime);
    strftime(timefix,128,"%Y\\%m\\%d\\ %H:%M:%S",localTime);
    char *base_64;// = (char *)malloc(512);
    int ret = nac_encode_base64(c->communicationkey, 32, &base_64);
    snprintf(buffer,1024,
            "<?xml version=\"1.0\" encoding=\"utf-8\"?>"
            "<message>"
            "<header>"
            "<id/><from>tdsvc.entry</from><to>tdsvr.agent</to>"
            "<type>LogonResult</type>"
            "<gentime>%s</gentime>"
            "</header>"
            "<body><Respond>"
            "<Result code=\"%d\">%s</Result>"
            "<CommunicationKey>%s</CommunicationKey>"
            "<StateSyncCyc invalidtimes=\"%d\">%d</StateSyncCyc>"
            "</Respond></body>"
            "</message>\0"
            ,timefix,sec,reason, base_64,keepalive_times, keepalive_msec);

    size=strlen(buffer)+1;
    if(c->measure.buffer_size<size+sizeof(struct_apply)){
        c->measure.tnccs_data=realloc(c->measure.tnccs_data,size+sizeof(struct_apply)+1);
        c->measure.buffer_size=size+sizeof(struct_apply)+1;
    }

    c->s_ap.type='X';
    c->s_ap.phase='R';  
    c->s_ap.data_length=size;

    memcpy(c->measure.tnccs_data+sizeof(struct_apply),buffer,size);
    memcpy(c->measure.tnccs_data,&(c->s_ap),sizeof(struct_apply));
    c->measure.data_size=size+sizeof(struct_apply);
    c->measure.send_size=0;
    if (base_64)
        free(base_64);
}


/****************************************************************
* 
* get_handshake_data()
*将握手信息数据封装到buffer中
*
****************************************************************/
int  get_handshark_data(char *buffer,char *data,int data_length,char *proto)
{
    int size=0;
    struct_transfer  s_tf;      //传输层头部
    struct_apply  s_ap;         //应用层头部

    memset(&s_tf, 0,sizeof(struct_transfer));
    memset(&s_ap, 0,sizeof(struct_apply));

    if(proto){
        memcpy(s_tf.proto,proto,4);
    }
    s_tf.flag='L';
    s_tf.type='H';
    s_tf.parameter=data_length;
    s_tf.data_length=data_length;



    memcpy(buffer,&(s_tf),sizeof(struct_transfer));
    memcpy(buffer+sizeof(struct_transfer),data,data_length);

    size=sizeof(struct_transfer)+data_length;
    buffer[size]='\0';
    return size;
}


/*
快速连接分析与处理
*/
int parse_fastconnect(conn *c)
{
    char *ragentID = c->rbuf+sizeof(struct_transfer)+11+1;
    char *rtmp = ragentID;
    char *ruser;
    char *rcommkey_md5;
    char commkey_md5[128];
    int ragentID_len = 0;
    int ruser_len = 0;
    while(*rtmp != '>')
    {
        ragentID_len++;
        rtmp++;
    }
    rtmp += 2;
    ruser = rtmp;
    while(*rtmp != '>')
    {
        ruser_len++;
        rtmp++;
    }
    rtmp += 2 ;
    rcommkey_md5 = rtmp;
    
    int ret = check_KTL_in_table(ragentID, ragentID_len, AGENTID_FLAG);
    if (ret == 1)
    {
        char *commkey = get_communicationkey_by_agentID(ragentID, ragentID_len);
        md5_decode((unsigned char *)commkey_md5, (unsigned char *)commkey, strlen(commkey));
        if (memcpy(commkey_md5, rcommkey_md5, 16) == 0)
        {
            return 1;
        }
    }
    return 0;
    /*--------------cache------------*/
    /*
    char *commkey = keepalive_get_commkey(ragentID, ragentID_len);
    if (commkey != NULL)
    {
        md5_decode((unsigned char *)commkey_md5, (unsigned char *)commkey, strlen(commkey));
        if (memcpy(commkey_md5, rcommkey_md5, 16) == 0)
        {
            return 1;
        }
    }
    return 0;
    */
}

/*
    处理应用层的数据
*/

int  process_request_app(conn *c)
{
    int i=0;
    char * p_value=NULL;
    xmlDocPtr doc=NULL;
    xmlNodePtr root=NULL;
    int onlie_num=0;
    int tmp_length=0;
    char msg_dir[128]="";


    if(c->measure.data_size<=0){
        c->go_state=conn_closing;
        return 1;
    }
    c->p_ap=(struct_apply *)c->measure.tnccs_data;
    switch(c->p_ap->phase)
    {
        case 'H':
        case 'A':
                {
                    switch(c->p_ap->type)
                    {
                        case 'B':
                               {
                                    int blackwhite_check = Ctr_online_ngump_by_socket("blackwhite_check",c->ip, c->mac, c->agentID);
                                     if((blackwhite_check !=2 ) &&   /*blackwhite_check = 2为黑名单*/
                                        ((blackwhite_check == 1) ||   /*blackwhite_check = 1为白名单*/
                                         ((is_offline_user_timeout(c->ip, c->mac) == 0) && /*根据offline表中字段判断是否超时*/
                                          ((nac_conf.is_auth==0)||       /*是否需要认证*/
                                           ((nac_conf.is_auth==1) && nac_verify_chellage(c))))))
                                     { 
									 	//判断用户在线数目
                                        if (Ctr_online_ngump_by_socket("online_num", c->ip, c->mac, c->agentID) > get_lic_onlinenum())
					                    {
					                        get_auth_fail_data(c,"在线用户数已超最大限制,请联系管理员",-10);
                                            printf("The online number get out of range, please contact administrator!\n");
                                            MSG_LOG("The online number get out of range!\n");
                                            c->ag_state=agent_auth_fail;
                                            c->s_ap.phase=conn_write;
                                            break;
					                    }

									 	//保活设置                                         
									 	int check_ret = check_KTL_in_table(c->agentID, strlen(c->agentID),AGENTID_FLAG);
									 	CreateCommunicationKey(c);
										if (check_ret == 0)//不在保活表中
										{											
											keepalive_table_add(c->ip, c->mac, c->agentID, c->measure.challenge, c->communicationkey);                                            
                                            Ctr_online_ngump_by_socket("online", c->ip, c->mac, c->agentID);//上线
                                            MSG_LOG("== online ip: %s, AgentID = %s\n", c->ip, c->agentID);
										}
										else
										{
										    if (!keepalive_update_by_agentID(c->agentID,c->ip,c->mac,c->measure.challenge,c->communicationkey))
										    {
										        memcpy(c->communicationkey,get_communicationkey_by_agentID(c->agentID, strlen(c->agentID)), 32);
										    }										        
										}
                                        
                                        /*--cache--*/
                                        //keepalive_update(c->agentID,c->ip,c->mac, c->communicationkey);
                                        
                                         if (get_user_policy(&(c->measure))){
                                             c->measure.cur_policy=c->measure.user_policy->policy;
                                             c->measure.field_num = c->measure.user_policy->field_num;
                                             c->measure.result = (measure_result *)calloc(sizeof(measure_result),c->measure.field_num);
                                         }
                                         if(c->measure.cur_policy==NULL){
                                             if((c->measure.itype!=ip_none)&&(c->measure.isaddr==0)){
                                                 c->measure.isaddr=1;
                                                 if(get_addr_msg(&(c->measure))==0){
                                                     creat_agent_addr_data(c);
                                                         c->ag_state=agent_addr_start;
                                                     c->go_state=conn_write;
                                                     break;
                                                 }
                                             }else{
                                                 creat_recommand_data(c);
                                                 c->ag_state=agent_recomm_start;
                                                 c->go_state=conn_write;
                                                 break;
                                             }
                                         }else{
                                             creat_policy_request_data(c);
                                             c->go_state=conn_write;
                                         }
                                     }
                                     else{
                                         get_auth_fail_data(c,"用户密码错误",-1);
                                         //printf("user name or password was error!\n");
                                         MSG_LOG("ip %s user name or password was error!\n", c->ip);
                                         c->ag_state=agent_auth_fail;
                                         c->s_ap.phase=conn_write;
                                     }
                                     break;
                                }
                        case 'X':
                                {
                                     parse_auth_start_data(c);
                                     c->go_state=conn_write;
                                     break;
                                }
                        case 'Z':
                                 break;
                        default:
                                 c->go_state=conn_closing;
                                 break;
                    }				
                    break;
                }
        case 'C':
                {
                     switch(c->p_ap->type){
                         case 'B':
                             break;
                         case 'X':
                             if(c->measure.cur_policy ){	
                                 //pthread_mutex_lock(&glob_lua_call_lock);
                                 c->measure.result[c->measure.cur_index].result=call_Lua_func(nac_conf.lua_context,
                                         c->measure.cur_policy->func,
                                         c->measure.tnccs_data+sizeof(struct_apply), 
                                         c->measure.cur_policy->args,
                                         &(c->measure.result[c->measure.cur_index].retmsg));
                                 //pthread_mutex_unlock(&glob_lua_call_lock);
                                 c->measure.cur_policy = c->measure.cur_policy->next;
                                 c->measure.cur_index++;
                             }	
                             if(c->measure.cur_policy==NULL){ //策略已经下发完了，下发结果消息吧
                                 printf("all policy has process\n");
                                 if((c->measure.itype!=ip_none)&&(c->measure.isaddr==0)){
                                     c->measure.isaddr=1;
                                     if(get_addr_msg(&(c->measure))==0){
                                         creat_agent_addr_data(c);
                                         c->go_state=conn_write;
                                         c->ag_state=agent_addr_start;
                                         break;
                                     }
                                 }
                                 creat_recommand_data(c);
                                 c->ag_state=agent_recomm_start;
                                 c->go_state=conn_write;
                                 break;
                             }else{			
                                 if(c->measure.cur_policy->req_msg){	
                                     creat_policy_request_data(c);
                                     c->go_state=conn_write;
                                 }else{
                                     printf("get empty msg_dir :%s\n",msg_dir);
                                     creat_recommand_data(c);
                                     c->ag_state=agent_recomm_start;
                                     c->go_state=conn_write;
                                 }	
                             }
                             break;
                         case 'Z':
                             break;	
                     }
                     break;
                }
        case 'R':
                {
                     switch(c->p_ap->type)
                     {
                         case 'B':
                             break;
                         case 'X':
                             break;
                         case 'Z':
                             break;	
                     }
                     break;
                 }
        default:
                {
                    c->go_state=conn_closing;
                    break;
                }
    }
    return 0;
}


void parse_request_conn(conn *c)
{
    struct _nac_if_conf  if_conf = {0,"",""};

    if(c&&c->rbuf)
    {
        if(c->rsize<12)
        {
            c->go_state=conn_closing;
            //printf("recevie ip %s  request too little: %s\n",c->ip, c->rbuf);
            ERR_LOG("recevie ip %s  request too little: %s\n",c->ip, c->rbuf);
            return;
        }
        c->p_tf=(struct_transfer *)c->rbuf;
        if (IS_KEEPALIVE(c->transport))
        {
            if (strncmp(c->p_tf->proto, "SYNC", 4) == 0)  //保活包
            {
                char *ragentID = c->rbuf+4+2+8+1;
                char *t = ragentID;
                char *commkey = NULL;
                int angentLen = 0;
                char num_str[9];
                memset(num_str, 0, sizeof(num_str));
                memcpy(num_str, c->rbuf+4+1, 8);
                num_str[8] = 0; 
                while(*t != '}')
                {
                    angentLen++;
                    t++;
                }
                
                int check_ret = check_KTL_in_table(ragentID, angentLen, AGENTID_FLAG);
                char *online_ip = get_data_by_agentID(ragentID, angentLen, 0);
                char *online_mac = get_data_by_agentID(ragentID, angentLen, 1);
                //int is_online = Ctr_online_ngump_by_socket("online_query", online_ip, online_mac, ragentID);
                int is_online = is_offline_user_timeout(online_ip, online_mac);
                if (check_ret == 0 || is_online == 1)//不在保活表中
                {
                    c->go_state=conn_closing;
                    return;                    
                }                                
                commkey = get_communicationkey_by_agentID(ragentID, angentLen);
                if (commkey == NULL)
                {
                    c->go_state=conn_closing;
                    return; 
                }
                
                /*---------cache--------
                commkey = keepalive_get_commkey(ragentID, ragentID);
                if (commkey == NULL)
                {
                    c->go_state = conn_closing;
                    return;
                }
                ---------------------*/
                int seqnum = strtol(num_str, NULL, 16);
                unsigned char out[128];
                //md5_decode(md5_str, base64_str, 16);
                FR_MD5_CTX ct;
                fr_MD5Init(&ct);
                fr_MD5Update(&ct, (char *)&seqnum, 4);
                fr_MD5Update(&ct, commkey, 32);
                fr_MD5Final(out, &ct);

                int i;
                for(i = 0; i < 16; i ++)
                {
                    sprintf(c->wbuf+i*2, "%02x", (unsigned char)out[i]);
                }
                for (i = 0; i < 32; i++)
                {
                    if (islower(c->wbuf[i]))
                        c->wbuf[i] = toupper(c->wbuf[i]);
                }
                c->wbuf[32] = '\0';
                c->wsize = 33;
                //printf("c->wbuf = %s\n",c->wbuf);
                //memcpy(c->wbuf,c->rbuf,c->rcursize);
                c->go_state=conn_write;
                //return;
            }
            return;
        }
        switch(c->p_tf->flag)
        {
            case 'L':
                    {//第一个包 长度标记，通常表示这是第一个分组，Parameter为总长度，如果Parameter等于DataLength时，说明分组已经包含了完整的报文。
                        if(c->p_tf->type=='A')/*应答ack，继续发包*/
                        {
                            if(c->measure.data_size>c->measure.send_size)
                            {//还有数据,继续发
                                full_response_data(c,"NALP");
                                c->go_state=conn_write;
                                break;
                            }
                            else if(c->ag_state==agent_addr_start)
                            {//发完了终端管理信息,开始发送结果
                                creat_recommand_data(c);
                                c->ag_state=agent_recomm_start;
                                full_response_data(c,"NALP");
                                c->go_state=conn_write;
                                break;
                            }
                            else if(c->ag_state==agent_recomm_start)
                            { //发送完最后的结果,通知上线结果
                                if(!is_agent_ioslated(&(c->measure)))
                                {   //健康检查成功后
                                    get_auth_success_data(c,"认证成功",0, nac_conf.server.keepalive_msec, nac_conf.server.keepalive_times);		
                                    //send_nac_health_log(c,"allowed");
                                    MSG_LOG("===ip :%s auth sucess === \n", c->ip);
                                    full_response_data(c,"NALP");								
                                    c->ag_state=agent_auth_access;
                                    c->go_state=conn_write;
                                    break;
                                }
                                else
                                {
                                    get_auth_fail_data(c,"健康检查失败",-120);
                                    MSG_LOG("health check fiald, ip:\n", c->ip);
                                    //send_nac_health_log(c,"isolate");
                                    c->ag_state=agent_auth_isolate;
                                    full_response_data(c,"NALP");
                                    c->go_state=conn_write;
                                    break;
                                }
                            }
                            else if(c->ag_state==agent_auth_access)
                            { //虽然不大可能到这里
                                /*
                                if(get_if_conf(&(if_conf),c->mac)==0)
                                {//查找交换机和端口
                                    process_set_vlan(&(if_conf),c->user_info.vlan?atoi(c->user_info.vlan):nac_conf.access_vlan);//设置VLAN
                                }
                                */
                                c->go_state=conn_closing;
                                break;
                            }
                            else
                            {
                                //错误.直接关闭
                                c->go_state=conn_closing;
                                break;
                            }
                            break;
                        }
                         
                         /*
                            将接收的数据存储到c->measure.tnccs_data中
                         */
                        if(c->measure.buffer_size<c->p_tf->parameter)
                        {
                            c->measure.tnccs_data=realloc(c->measure.tnccs_data,c->p_tf->parameter+1);
                            c->measure.buffer_size=c->p_tf->parameter;
                        }
                        memcpy(c->measure.tnccs_data,c->rbuf+sizeof(struct_transfer),c->p_tf->data_length);
                        c->measure.data_size=c->p_tf->data_length;
                        if (c->p_tf->parameter==c->p_tf->data_length)
                        {
                            if(c->p_tf->type=='H')//握手阶段，若是Client传来"Hello\0"表示数据正确
                            {
                                if (strncmp(c->rbuf+sizeof(struct_transfer), "HELLO\0", 6) == 0)
                                {
                                   c->wsize=get_handshark_data(c->wbuf,"FINISH\0",7,c->p_tf->proto);
                                   c->go_state=conn_write;
                                }
                                else if (strncmp(c->rbuf+sizeof(struct_transfer), "FASTCONNECT", 11) == 0)//快速连接报文处理
                                {
                                    if (nac_conf.is_fastconnect && parse_fastconnect(c))
                                    {
                                            //允许其上线                                        
                                            //且发送准入成功报文
                                        get_auth_success_data(c,"认证成功",0, nac_conf.server.keepalive_msec, nac_conf.server.keepalive_times);		
                                        //send_nac_health_log(c,"allowed");
                                        MSG_LOG("--- auth sucess ip : %s---\n", c->ip);
                                        full_response_data(c,"NALP");								
                                        c->ag_state=agent_auth_access;
                                        c->go_state=conn_write;
                                    }
                                    else
                                    {
                                        c->wsize = get_handshark_data(c->wbuf,"START PLAIN\0",12,NULL);
                                        c->go_state = conn_write;
                                    }
                                }
                                else
                                {
                                   c->go_state= conn_closing;
                                }
                                break;
                            }
                            process_request_app(c);        //数据报文处理，也就是说type == 'P'
                            if(c->go_state==conn_closing)
                            {
                                break;
                            }
                            if(c->measure.data_size>c->measure.send_size)
                            {
                                full_response_data(c,"NALP");
                                c->go_state=conn_write;
                            }else
                            {
                                c->go_state=conn_closing;
                                break;
                            }
                        }
                        else
                        {
                            full_ack_data(c,c->p_tf->data_length, "NALP");
                            c->go_state=conn_write;
                        }
                        break;
                    }
            case 'C':
                    {//后续包
                         if(c->measure.buffer_size<(c->measure.data_size+c->p_tf->data_length))
                         {
                             c->measure.tnccs_data=realloc(c->measure.tnccs_data,
                                     c->measure.data_size+c->p_tf->data_length+sizeof(struct_apply)+1);
                             c->measure.buffer_size = (c->measure.data_size+c->p_tf->data_length)+1;
                         }
                         memcpy(c->measure.tnccs_data+c->measure.data_size,c->rbuf+sizeof(struct_transfer),c->p_tf->data_length);
                         c->measure.data_size+=c->p_tf->data_length;
                         if(c->measure.tnccs_data)
                         {
                             full_ack_data(c,c->p_tf->data_length+c->p_tf->parameter, "NALP");
                             c->go_state=conn_write;
                         }
                         break;
                     }
            case 'E':
                    {//最后一个包
                         if(c->measure.buffer_size<(c->measure.data_size+c->p_tf->data_length))
                         {
                             c->measure.tnccs_data=realloc(c->measure.tnccs_data,
                                     c->measure.data_size+c->p_tf->data_length+1);
                             c->measure.buffer_size = (c->measure.data_size+c->p_tf->data_length)+1;
                         }
                         memcpy(c->measure.tnccs_data+c->measure.data_size,c->rbuf+sizeof(struct_transfer),c->p_tf->data_length);
                         c->measure.data_size+=c->p_tf->data_length;
                         process_request_app(c);
                         if(c->go_state==conn_closing)
                         {
                             break;
                         }
                         if(c->measure.data_size>c->measure.send_size)
                         {
                             full_response_data(c,"NALP");
                             c->go_state=conn_write;
                         }else
                         {
                             c->go_state=conn_closing;
                             break;
                         }
                         break;
                     }
            default:
                    {
                        c->go_state=conn_closing;
                        //printf("recevie ip %s unknow type: %c\n",c->rbuf[4]);
                        ERR_LOG("recevie ip %s unknow type: %c\n",c->ip, c->rbuf[4]);
                        break;
                    }
        } 
    }
}


#include "PAM_check_user.h"
#include "nac_server_log.h"
#define PAM_RET_CHECK(ret) do{ if(PAM_SUCCESS != ret) {return ret;}}while(0)

static int login_conv(int num_msg, const struct pam_message **msg, struct pam_response **response, void *appdata_ptr);
static void free_login(pam_handle_t *pamh, void *pbuf, int error_status);
static void free_data(pam_handle_t *pamh, int error_number);

int PAM_auth(char *model_name, char *user, char *passwd)
{
    //printf("PAM user = %s\npasswd = %s\n", user, passwd);
	if (NULL == model_name || NULL == user)
	{
		PAM_RET_CHECK(PAM_SYSTEM_ERR);
	}
	int ret_auth = -1;
	int ret_end = -1;
	pam_handle_t *pamh=NULL;
	struct pam_conv pam_conv = {login_conv, passwd};
    ret_auth = pam_start(model_name, user, &pam_conv , &pamh);

    if (ret_auth == PAM_SUCCESS)
        ret_auth = pam_authenticate(pamh, 0);

    if (ret_auth == PAM_SUCCESS)
        ret_auth = pam_acct_mgmt(pamh, 0); 
	else
		free_data(pamh, ret_auth);
		
	if (ret_auth != PAM_SUCCESS)
		free_data(pamh, ret_auth);

    if ((ret_end = pam_end(pamh, ret_end)) != PAM_SUCCESS)
	{ 
        pamh = NULL;
        fprintf(stderr, "check_user: failed to release authenticator\n");
        ERR_LOG("check_user: failed to release authenticator\n");
		PAM_RET_CHECK(ret_end);
    }

    PAM_RET_CHECK(ret_auth);
}

static int login_conv(int num_msg, const struct pam_message **msg, struct pam_response **response, void *appdata_ptr)
{
    struct pam_message  *m = (struct pam_message *)*msg;
    struct pam_response *r ;
    while (num_msg--)
    {
        switch (m->msg_style)
        {
            case PAM_PROMPT_ECHO_OFF:
                r  = (struct pam_response *)malloc(sizeof(struct pam_response));
                r->resp  = (char *)malloc(strlen((char*)appdata_ptr));
                r->resp_retcode = 0;
                strcpy(r->resp,(char*)appdata_ptr);
                *response = r;
                break;
            case PAM_PROMPT_ECHO_ON:
                (void) fputs(m->msg, stdout);
                r->resp = (char*)malloc(PAM_MAX_RESP_SIZE);
                fgets(r->resp, PAM_MAX_RESP_SIZE, stdin);
                /* add code here to remove \n from fputs */
                break;
            case PAM_ERROR_MSG:
                (void) fputs(m->msg, stderr);
                break;
            case PAM_TEXT_INFO:
                (void) fputs(m->msg, stdout);
                break;
        }
    }
    return (PAM_SUCCESS);
}

void free_data(pam_handle_t *pamh, int error_number)
{
	int *pret = (int *)malloc(sizeof(int));
	*pret = error_number;
	pam_set_data(pamh, "", (void *)pret, free_login);
	free(pret);
}

static void free_login(pam_handle_t *pamh, void *pbuf, int error_status)
{
	free(pbuf);
}

#ifndef __NAC_SERVER_LOG__
#define __NAC_SERVER_LOG__
#include "nac_server.h"

#define LOG         nac_server_log
#define MSG_LOG     nac_server_log_msg
#define DEBUG_LOG   nac_server_log_debug
#define WARN_LOG    nac_server_log_warn
#define ERR_LOG     nac_server_log_err

#define NAC_LOG_DEBUG   0
#define NAC_LOG_MSG     1 
#define NAC_LOG_WARN    2
#define NAC_LOG_ERR     3

void log_init();
void log_fini();

void nac_server_log(int level, const char *fmt, ...);
void nac_server_log_debug(const char *fmt, ...);
void nac_server_log_msg(const char *fmt, ...);
void nac_server_log_warn(const char *fmt, ...);
void nac_server_log_err(const char *fmt, ...);

void set_libevent_log(int, const char *);

#endif

#ifndef _NAC_KEEP_ALIVE_H_
#define _NAC_KEEP_ALIVE_H_


#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <event.h>
#include <netdb.h>
#include <pthread.h>
#include <unistd.h>
#include <signal.h>
#include <fcntl.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <errno.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <limits.h>
#include <sysexits.h>
#include <stddef.h>
#include <getopt.h>
#include <unistd.h>

#include <nac/nac_std.h>
#include <sys/epoll.h>
#include <event.h>

#define KEEPALIVE_TIMES     (10)

enum keepalive_table_main_flag
{
    IP_FLAG,
    MAC_FLAG,
    AGENTID_FLAG,            
    CHALLENG_FLAG,
};

typedef struct keepalive_table_list
{
    int count_f;              //����ʧ�ܼ���
    int count_s;              //����ɹ�����
    char *ip;
    char *mac;
    char *agentID;
    char *challeng;
    char *communicationkey;
    char cmp_flag;
    struct keepalive_table_list *next;
    struct keepalive_table_list *prev;
}KTL;

void KTL_init();
void keepalive_table_add(char *i, char *m, char *a, char *c, char *ck);
KTL* keepalive_table_del(KTL *ktl);
int check_KTL_Times(KTL * ktl);
int check_KTL_in_table(char *buff, int buflen, int flag);
char *get_data_by_agentID(char *agentID, int agentID_len, int type);
char *get_communicationkey_by_agentID(char *a, int l);
int keepalive_update_by_agentID(char *agentID, char *ip, char *mac, char *challenge, char *communicationkey);

static KTL *KTL_new(char *i, char *m, char *a, char *c, char *ck);
static void KTL_del();

//int keep_tabel_init();
static void check_keepalive_table();
void keep_alive_table_work();

/*----------------------------------------------------------*/
typedef struct keepalive_struct
{
    char ip[16];
    char mac[32];
    char commkey[33];
    char agentID[33];
}KEEPALIVE;

void keepalive_init();
int keepalive_put(char *agentID, char *ip, char *mac, char *commkey);
int keepalive_update(char *agentID, char *ip, char *mac, char *commkey);
char *keepalive_get_commkey(char *agentID, int agentID_len);


#endif

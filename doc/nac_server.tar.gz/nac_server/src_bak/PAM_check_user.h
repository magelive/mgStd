#ifndef ___PAM__CHECK__USER__INCLUDE____
#define ___PAM__CHECK__USER__INCLUDE____

#include <security/pam_appl.h>
#include <security/pam_misc.h>
#include <stdio.h>

int PAM_auth(char *model_name, char *user, char *passwd);

#endif


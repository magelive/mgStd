#ifndef _NAC_CONN_SQLITE3_H_
#define _NAC_CONN_SQLITE3_H_

#include <sqlite3.h>

/*nac_sql_callback sqlite3_exec 回调函数
* @void*  sqlite3_exec 传递过来的参数
* @int 结果集列数
* @char** 列的值
* @char** 列的名字
*/
typedef int (*nac_sql_callback)(void *,int,char **,char **);
int nac_policy_open_db(sqlite3 **pdb, char *dbpath);
int nac_policy_reopen_db(sqlite3 **pdb,char *dbpath);
void nac_policy_uninit_db(sqlite3 *pdb);
int nac_exec_sql(sqlite3 **pdb,char *sql,nac_sql_callback callback,void *argv, char *dbpath);
int nac_get_table(sqlite3 **pdb,char *sql,char ***result,char *dbpath);
int nac_free_table(char **result);

#endif

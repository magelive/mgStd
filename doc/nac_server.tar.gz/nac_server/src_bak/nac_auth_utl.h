#ifndef  _NAC_AUTH_UTL_H_
#define  _NAC_AUTH_UTL_H_

#include "nac_server.h"

#define MAX_STRING_LEN		254	/* RFC2138: string 0-253 octets */

void md5_decode(unsigned char *output, unsigned char * input, int len);
void get_rand_str(char s[],int number);
int nac_verify_chellage(struct conn *c);
int nac_check_user(char *u, char *p);

#endif

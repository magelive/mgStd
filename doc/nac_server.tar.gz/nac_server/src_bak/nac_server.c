#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <event.h>
#include <netdb.h>
#include <pthread.h>
#include <unistd.h>
#include <signal.h>
#include <fcntl.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <errno.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <limits.h>
#include <sysexits.h>
#include <stddef.h>
#include <getopt.h>
#include <unistd.h>
#include <ngtawstd/zytypes/zymap.h>
#include <tawlicense.h>
#include <nac/nac_topzmq.h>
#include <nac/nac_policy.h>
#include <sys/resource.h>

#include "nac_server.h"
#include "parse_request.h"
#include "nac_auth_utl.h"
#include "nac_load_conf.h"
#include "PAM_check_user.h"
#include "nac_keep_alive.h"
#include "nac_server_log.h"
const char *__NAC_SERVER_VERSION__ = "nac_server version :" __NAC_VERSION__ ", built on " __DATE__ "at " __TIME__;

static pthread_mutex_t cqi_freelist_lock;
static LIBEVENT_DISPATCHER_THREAD dispatcher_thread;        //调度线程?

static LIBEVENT_THREAD *threads;        //事件线程?

static int init_count =	0;              //
static pthread_mutex_t init_lock;
static pthread_cond_t init_cond;

static conn	**freeconns;                //空闲的connect
static int free_conn_total = 0;              //     
static int free_conn_curr = 0;              //

static pthread_mutex_t conn_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_mutex_t accept_conn_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_mutex_t keepalive_conn_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_mutex_t ldap_lock = PTHREAD_MUTEX_INITIALIZER;

static conn	*listen_conn = NULL;            //监听连接循环链表
static conn *accept_conn = NULL;            //接受连接循环链表
static conn *keepalive_conn = NULL;         //保活连接循环链表
static int last_thread = -1;                //
static CQ_ITEM *cqi_freelist;               //空闲CQ_ITEM list
static pthread_mutex_t cqi_freelist_lock;
struct stats stats;                         //
static pthread_mutex_t stats_lock;
static struct event_base *main_base;        //

static struct event maxconnsevent;
nac_zmq_context zmq_context={NULL,NULL};    //?


nac_server_conf  nac_conf;



void STATS_LOCK()
{
    pthread_mutex_lock(&stats_lock);
}

void STATS_UNLOCK()
{
    pthread_mutex_unlock(&stats_lock);
}


void stats_init(void) 
{
    stats.curr_conns = stats.total_conns = stats.conn_structs = 0;
    stats.accepting_conns= true;
    stats.listen_disabled_num = 0;
    stats.started= time(0) - 2;
    stats.tcp_port=nac_conf.server.tcp_port;
    stats.udp_port=nac_conf.server.udp_port;
    stats.keepalive_tcp_port = nac_conf.server.keepalive_tcp_port;
    stats.keepalive_udp_port = nac_conf.server.keepalive_udp_port;
    stats.max_conn_structs=nac_conf.server.max_conn_struct;
    stats.thread_num=nac_conf.server.thread_num;
    stats.max_node=nac_conf.server.max_node;


}

static int process_request(conn	*c)
{
    if(stats.run_level==1)
    {	
        printf("process_request:%s\n",c->rbuf);
    }

    return 1;
}

void accept_new_conns(const     bool do_accept)
{
    int lock_ret = -1;
    lock_ret = pthread_mutex_trylock(&conn_lock);
    if (lock_ret != 0)
        return;
    do_accept_new_conns(do_accept);
    if (lock_ret == 0)
        pthread_mutex_unlock(&conn_lock);
}

static void maxconns_handler(const int fd, const short which, void *arg)
{
    struct timeval t =
    {
        .tv_sec = 0,
        .tv_usec = 10000
    };

    if (fd == -42 )
    {
        /* reschedule in 10ms if we need to keep polling */
        evtimer_set(&maxconnsevent, maxconns_handler, 0);
        event_base_set(main_base, &maxconnsevent);
        evtimer_add(&maxconnsevent, &t);
    }
    else
    {
        evtimer_del(&maxconnsevent);
        accept_new_conns(true);
    }
}

/*

*/
static bool	update_event(conn *c, const	int	new_flags)
{
    assert(c !=	NULL);

    struct event_base *base	= c->event.ev_base;
    if (c->ev_flags	== new_flags)
        return true;
    if (event_del(&c->event) ==	-1)	return false;
    event_set(&c->event, c->sfd, new_flags,	event_handler, (void *)c);
    event_base_set(base, &c->event);
    c->ev_flags	= new_flags;
    if (event_add(&c->event, 0)	== -1) return false;
    return true;
}

void do_accept_new_conns(const bool	do_accept)
{
    conn *next;

    for	(next =	listen_conn; next; next	= next->next)
    {
        if (do_accept)
        {
            update_event(next, EV_READ | EV_PERSIST);
            if (listen(next->sfd, 1024)	!= 0)
            {
                perror("listen");
                ERR_LOG("listen error!\n");
            }
        }
        else
        {
            update_event(next, 0);
            if (listen(next->sfd, 0) !=	0)
            {
                perror("listen");
                ERR_LOG("listen error!\n");
            }
        }
    }

    if (do_accept)
    {
        STATS_LOCK();
        stats.accepting_conns =	true;
        STATS_UNLOCK();
    }
    else
    {
        STATS_LOCK();
        stats.accepting_conns =	false;
        stats.listen_disabled_num++;
        STATS_UNLOCK();
        maxconns_handler(-42,0,0); 
    }
}

void conn_free(conn	*c)
{
    if (c)
    {
        if(c->rbuf)
        {
            free(c->rbuf);
            c->rbuf=NULL;
        }
        free(c);
        c=NULL;
    }
}


/*

    conn_add_to_freelist()
*/

bool conn_add_to_freelist(conn *c)
{
    bool ret = true;
    pthread_mutex_lock(&conn_lock);
    if (free_conn_curr < free_conn_total)   //当前队列未满时，直接将c放入到freelist中
    {
        freeconns[free_conn_curr++] =	c;
        ret	= false;
    }
    else                                    //当队列数据已经满时，重新分配2倍大的空间，并将其c放入到freelist中
    {
        /* try to enlarge free connections array */
        size_t newsize = free_conn_total * 50;
        conn **new_freeconns = realloc(freeconns, sizeof(conn *) * newsize);
        if (new_freeconns)
        {
            free_conn_total =	newsize;
            freeconns =	new_freeconns;
            freeconns[free_conn_curr++] =	c;
            ret	= false;
        }
    }
    pthread_mutex_unlock(&conn_lock);
    return ret;
}



static void	conn_init(void)
{
    free_conn_total =	200;
    free_conn_curr = 0;
    if ((freeconns = calloc(free_conn_total, sizeof(conn *)))	== NULL)
    {
        fprintf(stderr,	"Failed	to allocate	connection structures\n");
        ERR_LOG( "Failed to allocate connection structures\n");
    }
    return;
}


/*
    事件处理

*/
static void	thread_libevent_process(int	fd,	short which, void *arg)
{
    LIBEVENT_THREAD	*me	= arg;
    CQ_ITEM	*item;
    char buf[1];

    if (read(fd, buf, 1) !=	1)
    {
        fprintf(stderr,	"Can't read	from libevent pipe\n");
        ERR_LOG("Can't read from libevent pipe\n");
    }

    item = cq_pop(me->new_conn_queue);

    if (NULL !=	item)
    {
        conn *c	= conn_new(item->sfd, item->init_state,	item->event_flags,item->read_buffer_size, item->transport, me->base);
        if (c == NULL)
        {
            if (IS_UDP(item->transport))
            {
                fprintf(stderr,	"Can't listen for events on	UDP	socket\n");
                ERR_LOG("Can't listen for events on UDP socket\n");
                exit(1);
            }
            else
            {
                fprintf(stderr,	"Can't listen for events on	fd %d\n",item->sfd);
                ERR_LOG("Can't listen for events on fd %d\n",item->sfd);
                close(item->sfd);
            }
        }
        else
        {
            c->thread =	me;
            if(!IS_UDP(item->transport))
            {
                pthread_mutex_lock(&accept_conn_lock);
                c->next = accept_conn;
                accept_conn = c;
                pthread_mutex_unlock(&accept_conn_lock);
            }
        }
        cqi_free(item);
    }
}

/*
 * Set up a	thread's information.
 */
static void	setup_thread(LIBEVENT_THREAD *me)
{
    me->base = event_init();
    if (! me->base)
    {
        fprintf(stderr,	"Can't allocate	event base\n");
        ERR_LOG("Can't allocate event base\n");
        exit(1);
    }

    /* Listen for notifications	from other threads */
    event_set(&me->notify_event, me->notify_receive_fd,
            EV_READ	| EV_PERSIST, thread_libevent_process, me);
    event_base_set(me->base, &me->notify_event);

    if (event_add(&me->notify_event, 0)	== -1)
    {
        fprintf(stderr,	"Can't monitor libevent	notify pipe\n");
        ERR_LOG("Can't monitor libevent notify pipe\n");
        exit(1);
    }

    me->new_conn_queue = malloc(sizeof(struct conn_queue));
    if (me->new_conn_queue == NULL)
    {
        perror("Failed to allocate memory for connection queue");
        ERR_LOG("Failed to allocate memory for connection queue");
        exit(EXIT_FAILURE);
    }
    cq_init(me->new_conn_queue);

}


/*
 * Worker thread: main event loop
 */
static void	*worker_libevent(void *arg)
{
    LIBEVENT_THREAD	*me	= arg;

    pthread_mutex_lock(&init_lock);
    init_count++;
    pthread_cond_signal(&init_cond);
    pthread_mutex_unlock(&init_lock);

    event_base_loop(me->base, 0);
    return NULL;
}

static void	create_worker(void *(*func)(void *), void *arg)
{
    pthread_t		thread;
    pthread_attr_t	attr;
    int				ret;

    pthread_attr_init(&attr);

    if ((ret = pthread_create(&thread, &attr, func,	arg)) != 0)
    {
        fprintf(stderr,	"Can't create thread: %s\n",
                strerror(ret));
        ERR_LOG("Can't create thread: %s\n",  strerror(ret));
        exit(1);
    }
}

/*

    nthreads: 最大处理线程数
    main_base:  libevnt中的事件处理事件

*/


void thread_init(int nthreads, struct event_base *main_base)
{
    int			i;

    pthread_mutex_init(&init_lock, NULL);
    pthread_cond_init(&init_cond, NULL);

    pthread_mutex_init(&cqi_freelist_lock, NULL);
    cqi_freelist = NULL;

    threads	= calloc(nthreads, sizeof(LIBEVENT_THREAD));
    if (! threads)
    {
        perror("Can't allocate thread descriptors");
        ERR_LOG("Can't allocate thread descriptors");
        exit(1);
    }

    dispatcher_thread.base = main_base;          //调试线程事件为主线程中的处理事件
    dispatcher_thread.thread_id	= pthread_self();//调试线程为主线程本身

    for	(i = 0;	i <	nthreads; i++)
    {
        int	fds[2];
        if (pipe(fds))
        {
            perror("Can't create notify	pipe");
            ERR_LOG("Can't create notify pipe");
            exit(1);
        }

        threads[i].notify_receive_fd = fds[0];
        threads[i].notify_send_fd =	fds[1];

        setup_thread(&threads[i]);//设置处理线程
    }

    /* Create threads after	we've done all the libevent	setup. */
    for	(i = 0;	i <	nthreads; i++)
    {
        create_worker(worker_libevent, &threads[i]);
    }

    /* Wait	for	all	the	threads	to set themselves up before	returning. */
    pthread_mutex_lock(&init_lock);
    while (init_count <	nthreads)
    {
        pthread_cond_wait(&init_cond, &init_lock);
    }
    pthread_mutex_unlock(&init_lock);
}

static int new_socket(struct addrinfo *ai) 
{
    int	sfd;
    int	flags;

    if ((sfd = socket(ai->ai_family, ai->ai_socktype, ai->ai_protocol))	== -1) {
        return -1;
    }

    if ((flags = fcntl(sfd,	F_GETFL, 0)) < 0 ||
            fcntl(sfd, F_SETFL,	flags |	O_NONBLOCK)	< 0) {
        perror("setting	O_NONBLOCK");
        ERR_LOG("setting O_NONBLOCK");
        close(sfd);
        return -1;
    }
    return sfd;
}

/*
 * Initializes a connection	queue.
 */
static void	cq_init(CQ *cq)	{
    pthread_mutex_init(&cq->lock, NULL);
    pthread_cond_init(&cq->cond, NULL);
    cq->head = NULL;
    cq->tail = NULL;
}

/*
 * Looks for an	item on	a connection queue,	but	doesn't	block if there isn't
 * one.
 * Returns the item, or	NULL if	no item	is available
 */
static CQ_ITEM *cq_pop(CQ *cq) {
    CQ_ITEM	*item;

    pthread_mutex_lock(&cq->lock);
    item = cq->head;
    if (NULL !=	item) {
        cq->head = item->next;
        if (NULL ==	cq->head)
            cq->tail = NULL;
    }
    pthread_mutex_unlock(&cq->lock);

    return item;
}

/*
 * Adds	an item	to a connection	queue.
 */
 
static void	cq_push(CQ *cq,	CQ_ITEM	*item) {
    item->next = NULL;

    pthread_mutex_lock(&cq->lock);
    if (NULL ==	cq->tail)
        cq->head = item;
    else
        cq->tail->next = item;
    cq->tail = item;
    pthread_cond_signal(&cq->cond);
    pthread_mutex_unlock(&cq->lock);
}

/*
 * Returns a fresh connection queue	item.
 */
 /*
    cqi_new是从cqi_freelist列表头中取出一个CQ_ITEM
 */
static CQ_ITEM *cqi_new(void) {
    CQ_ITEM	*item =	NULL;
    pthread_mutex_lock(&cqi_freelist_lock);
    if (NULL != cqi_freelist) {
        item = cqi_freelist;
        cqi_freelist = item->next;
    }
    pthread_mutex_unlock(&cqi_freelist_lock);

    if (NULL ==	item) {
        int	i;

        /* Allocate	a bunch	of items at	once to	reduce fragmentation */
        item = malloc(sizeof(CQ_ITEM) *	ITEMS_PER_ALLOC);
        if (NULL ==	item)
            return NULL;

        /*
         * Link	together all the new items except the first	one
         * (which we'll	return to the caller) for placement	on
         * the freelist.
         */
        for	(i = 2;	i <	ITEMS_PER_ALLOC; i++)
            item[i - 1].next = &item[i];

        pthread_mutex_lock(&cqi_freelist_lock);
        item[ITEMS_PER_ALLOC - 1].next = cqi_freelist;//cqi_freelist = NULL;
        cqi_freelist = &item[1];//item[0]->next = ?
        pthread_mutex_unlock(&cqi_freelist_lock);
    }

    return item;
}


/*
 * Frees a connection queue	item (adds it to the freelist.)
 */
static void	cqi_free(CQ_ITEM *item)	{
    pthread_mutex_lock(&cqi_freelist_lock);
    item->next = cqi_freelist;
    cqi_freelist = item;
    pthread_mutex_unlock(&cqi_freelist_lock);
}

static void	conn_set_state(conn	*c,	enum conn_states state)
{
    assert(c !=	NULL);
    assert(state >=	conn_listening && state	< conn_max_state);

    if (state != c->state)
    {
        c->state = state;


    }
}

conn *conn_from_freelist()
{
    conn *c;

    pthread_mutex_lock(&conn_lock);
    if (free_conn_curr > 0)
    {
        c =	freeconns[--free_conn_curr];
    }
    else
    {
        c =	NULL;
    }
    pthread_mutex_unlock(&conn_lock);

    return c;
}

static enum	try_read_result	try_read_udp(conn *c)
{
    int	res;

    assert(c !=	NULL);

    res	= recvfrom(c->sfd, c->rbuf,	c->rsize,0,	&c->request_addr, &c->request_addr_size);
    if (res	> 1)
    {
        if(stats.run_level==1)
        {	
            printf("%u:recvfrom:%s\n",pthread_self(),c->rbuf);
            MSG_LOG("%u:recvfrom:%s\n",pthread_self(),c->rbuf);

        }
        c->rbuf[res]='\0';
        return READ_DATA_RECEIVED;
    }
    return READ_NO_DATA_RECEIVED;
}

static enum	try_read_result	try_read_network(conn *c)
{
    enum try_read_result gotdata = READ_NO_DATA_RECEIVED;
    int	res;
    int	num_allocs = 0;
    int   rcurr_index = 0;
    assert(c !=	NULL);
    
    if (c->sfd < 0)
        return READ_ERROR;

    c->rcurr = c->rbuf;
    c->rcursize=0;
    //memset(c->rbuf, 0, c->rsize);
    while (1)
    {

        res	= read(c->sfd, c->rbuf,c->rsize);
        if (res	> 0)
        {
            gotdata	= READ_DATA_RECEIVED;
            c->rcursize	= res;
            c->rbuf[c->rcursize]='\0';
            break;
        }
        if (res	== 0)
        {
            return READ_ERROR;
        }
        if (res	== -1)
        {
            if (errno == EAGAIN	|| errno ==	EWOULDBLOCK)
            {
                break;
            }
            return READ_ERROR;
        }
    }
    return gotdata;
}

static int try_read_data(conn *c)
{
    int res=0;
    res = IS_UDP(c->transport) ? try_read_udp(c) : try_read_network(c);
    return res;
}

static int try_write_data(conn *c)
{

    struct msghdr *msg;
    struct iovec	msg_iov;
    int res=0;
    char buf[]="200 ok!";


    if (IS_UDP(c->transport)){
        //c->go_state = conn_closing;
        //res=sendto(c->sfd,c->wbuf,c->wsize);
    }else{
        if (c->sfd < 0 )
            res = -1;
        else
            res=write(c->sfd,c->wbuf,c->wsize);
    }


    if (res == -1 &&	(errno == EAGAIN ||	errno == EWOULDBLOCK)){
        //if (!update_event(c,	EV_WRITE | EV_PERSIST)){
        if (!update_event(c,	EV_WRITE)){
            c->go_state = conn_closing;
            return 1;
        }else{	
            c->go_state = conn_write;//conn_closing;
            return 1;	
        }
    }
    //memset(c->wbuf,0, c->wsize);
    c->go_state = conn_waiting;
    return 0;
}

/*
static void clean_user_conf(user_conf *ui)
{
    if (ui)
    {
        if(ui->username)
        {
            free(ui->username);
            ui->username = NULL;
        }
        if (ui->pwd)
        {
            free(ui->pwd);
            ui->pwd = NULL;
        }
        //free(ui);
        //ui = NULL;
    }
}
*/
static void	conn_cleanup(conn *c)
{
    assert(c !=	NULL);
    c->ag_state=agent_auth_start;
    if (IS_UDP(c->transport))
    {
        conn_set_state(c, conn_read);
    }
}


static void	conn_close(conn	*c)
{
    //printf("conn close \n");
    assert(c !=	NULL);
    conn  *pro_conn=NULL;

    event_del(&c->event);
    close(c->sfd);
    c->sfd = -1;
    clean_measure_data(&(c->measure));
    //clean_user_conf(&(c->user_info));
    conn_cleanup(c);
    if(c->mac) 
    {
        free(c->mac);
        c->mac = NULL;
    }
    if (c->ip)
    {
        free(c->ip);
        c->ip = NULL;
    }
    if (c->username)
    {
        free(c->username);
        c->username = NULL;
    }
    if (c->passwd)
    {
        free(c->passwd);
        c->passwd = NULL;
    }
    if (c->agentID)
    {
        free(c->agentID);
        c->agentID = NULL;
    }
    c->switch_host[0]='\0';

    pthread_mutex_lock(&accept_conn_lock);
    if(accept_conn == c)
    {
        accept_conn = c->next;
    }	
    else
    {	
        for(pro_conn = accept_conn;pro_conn;pro_conn = pro_conn->next)
        {
            if(pro_conn->next == c)
            {
                pro_conn->next = c->next;
                break;
            }
        }
    } 
    pthread_mutex_unlock(&accept_conn_lock);

    if (c->rsize > READ_BUFFER_HIGHWAT || conn_add_to_freelist(c))
    {
        conn_free(c);

        STATS_LOCK();
        stats.conn_structs--;
        STATS_UNLOCK();
    }

    STATS_LOCK();
    stats.curr_conns--;
    STATS_UNLOCK();
    return;
}


/*

    驱动函数，主要负责处理所有事件
*/
void	drive_machine(conn *c)
{
    bool stop =	false;
    int	sfd, flags = 1;
    socklen_t addrlen;
    struct sockaddr_storage	addr;
    int	res;
    int	avail;
    char buffer[256]="";
    int buffer_size=0;

    struct _nac_if_conf  if_conf = {0,"",""};
    assert(c !=	NULL);

    while (!stop)
    {

        switch(c->state)
        {
            case conn_listening:
                if(stats.run_level==1)
                {		
                    printf("%lu:conn_listening:%d\n",pthread_self(),c->state);
                    MSG_LOG("%lu:conn_listening:%d\n",pthread_self(),c->state);
                }
                addrlen	= sizeof(addr);
                if ((sfd = accept(c->sfd, (struct sockaddr *)&addr,	&addrlen)) == -1)
                {
                    if (errno == EAGAIN	|| errno ==	EWOULDBLOCK)
                    {
                        stop = true;
                    }
                    else if	(errno == EMFILE)
                    {
                        accept_new_conns(false);
                        stop = true;
                    }
                    else
                    {
                        perror("accept()");
                        ERR_LOG("accept error!\n");
                        stop = true;
                    }
                    break;
                }
                if ((flags = fcntl(sfd,	F_GETFL, 0)) < 0 ||
                        fcntl(sfd, F_SETFL,	flags |	O_NONBLOCK)	< 0)
                {
                    perror("setting	O_NONBLOCK");
                    ERR_LOG("setting O_NONBLOCK 2");
                    close(sfd);
                    break;
                }
                if (!IS_KEEPALIVE(c->transport))
                {                
                    buffer_size=get_handshark_data(buffer,"START PLAIN\0",12,NULL);
                    if(write(sfd,buffer,buffer_size)==-1){
                        close(sfd);
                        stop=true;
                        break;
                    }                    
                }
                dispatch_conn_new(sfd, conn_waiting, EV_READ | EV_PERSIST,
                            DATA_BUFFER_SIZE, c->transport);
                stop = true;
                break;
            case conn_waiting:
                if(stats.run_level==1)
                {		
                    printf("%lu:conn_waiting:%d\n",pthread_self(),c->state);
                    MSG_LOG("%lu:conn_waiting:%d\n",pthread_self(),c->state);
                }
                if (!update_event(c, EV_READ | EV_PERSIST))
                {
                    conn_set_state(c, conn_closing);
                    break;
                }
                conn_set_state(c, conn_read);
                stop = true;
                break;

            case conn_read:
                if(stats.run_level==1)
                {		
                    printf("%lu:conn_read:%d\n",pthread_self(),c->state);
                }
                res=try_read_data(c);
                if (res == READ_ERROR){
                    conn_set_state(c,conn_closing);
                }else{
                    conn_set_state(c, conn_parse);
                }
                break;
            case conn_write:
                if(stats.run_level==1)
                {		
                    printf("%lu:conn_write:%d\n",pthread_self(),c->state);
                }
                try_write_data(c);
                if (IS_KEEPALIVE(c->transport))
                {
                    conn_set_state(c, conn_closing);
                    break;
                }
                /*如果已经认证失败，就直接关掉连接*/
                if(((c->ag_state==agent_auth_fail)||
                            (c->ag_state==agent_auth_isolate))&&
                        (c->measure.data_size<=c->measure.send_size)){   // 终端处于fail和isloate状态，发完数据后就关闭
                    conn_set_state(c,conn_closing);
                    break;
                }else if((c->ag_state==agent_auth_access)&&
                        (c->measure.data_size<=c->measure.send_size)){ //下发完成功信息
                    conn_set_state(c,conn_closing);
                    break;
                }else{
                    conn_set_state(c,c->go_state);
                }
                stop = true;
                break;	
            case  conn_parse://解析
                parse_request_conn(c);//解析函数
                conn_set_state(c,c->go_state);
                break;
            case conn_closing:
                if(stats.run_level==1)
                {		
                    printf("%lu:conn_close:%d\n",pthread_self(),c->state);
                }
                if (IS_UDP(c->transport))
                    conn_cleanup(c);
                else
                    conn_close(c);
                stop = true;
                break;
        }
    }

    return;
}


/*

    所有事件处理函数
*/


void event_handler(const int fd, const short which,	void *arg)
{
    DEBUG_LOG("event_handler begin!!!\n");
    if(stats.run_level==1)
    {		
        printf("event_handler:%d\n",fd);
    }
    conn *c;

    c =	(conn *)arg;
    assert(c !=	NULL);

    c->which = which;


    if (fd != c->sfd)
    {
        conn_close(c);
        return;
    }
    DEBUG_LOG("drive_machine~~\n");
    drive_machine(c);
    DEBUG_LOG("drive_machine~and event_handler end~\n");
    /* wait	for	next event */
    return;
}


/*
    conn_new 

*/
conn *conn_new(const int sfd, enum conn_states init_state,
        const int event_flags,
        const int read_buffer_size,	enum network_transport transport,
        struct event_base *base)
{
    conn *c	= conn_from_freelist();
    
    if (NULL ==	c)
    {

        if (!(c	= (conn	*)calloc(1,	sizeof(conn))))
        {
            fprintf(stderr,	"calloc()\n");
            ERR_LOG("calloc error!");
            return NULL;
        }

        c->rsize = read_buffer_size;
        c->rcursize=0;

        c->rbuf	= (char	*)calloc((size_t)c->rsize,1);
        c->rcurr=c->rbuf;


        STATS_LOCK();
        stats.conn_structs++;
        STATS_UNLOCK();
    }

    c->transport = transport;

    c->sfd = sfd;
    c->state = init_state;

    event_set(&c->event, sfd, event_flags, event_handler, (void	*)c);
    event_base_set(base, &c->event);
    c->ev_flags	= event_flags;

    if (event_add(&c->event, 0)	== -1)
    {
        if (conn_add_to_freelist(c))
        {
            conn_free(c);

            STATS_LOCK();
            stats.conn_structs--;
            STATS_UNLOCK();
        }
        perror("event_add");
        ERR_LOG("event_add() return -1");
        return NULL;
    }

    STATS_LOCK();
    stats.curr_conns++;
    stats.total_conns++;
    STATS_UNLOCK();


    return c;
}


/*

    dispatch_conn_new :conn new 调度?
*/

void dispatch_conn_new(int sfd,	enum conn_states init_state, int event_flags,
        int	read_buffer_size, enum network_transport transport)
{
    CQ_ITEM	*item =	cqi_new();
    int	tid	= (last_thread + 1)	% stats.thread_num;

    LIBEVENT_THREAD	*thread	= threads +	tid;

    last_thread	= tid;

    item->sfd =	sfd;
    item->init_state = init_state;
    item->event_flags =	event_flags;
    item->read_buffer_size = read_buffer_size;
    item->transport	= transport;

    cq_push(thread->new_conn_queue,	item);

    if (write(thread->notify_send_fd, "", 1) !=	1)
    {
        perror("Writing	to thread notify pipe");
        ERR_LOG("Writing to thread notify pipe");
    }
}

static void	maximize_sndbuf(const int sfd)
{
    socklen_t intsize =	sizeof(int);
    int	last_good =	0;
    int	min, max, avg;
    int	old_size;

    /* Start with the default size.	*/
    if (getsockopt(sfd,	SOL_SOCKET,	SO_SNDBUF, &old_size, &intsize)	!= 0)
    {
        return;
    }

    /* Binary-search for the real maximum. */
    min	= old_size;
    max	= MAX_SENDBUF_SIZE;

    while (min <= max)
    {
        avg	= ((unsigned int)(min +	max)) /	2;
        if (setsockopt(sfd,	SOL_SOCKET,	SO_SNDBUF, (void *)&avg, intsize) == 0)
        {
            last_good =	avg;
            min	= avg +	1;
        }
        else
        {
            max	= avg -	1;
        }
    }
}

/*
服务器socket
    port:               端口
    transport:          传输接收类型
    portnumber_file:    
*/
        
static int server_socket(int port, enum	network_transport transport,
        FILE *portnumber_file)
{
    int	sfd;
    struct linger ling = {0, 0};//TCP断开标志
    struct addrinfo	*ai;        //
    struct addrinfo	*next;      
    struct addrinfo	hints =	{ .ai_flags	= AI_PASSIVE,
        .ai_family = AF_UNSPEC };
    char port_buf[NI_MAXSERV];
    int	error;
    int	success	= 0;
    int	flags =1;

    hints.ai_socktype =	IS_UDP(transport) ?	SOCK_DGRAM : SOCK_STREAM;

    if (port ==	-1)
    {
        port = 0;
    }

    snprintf(port_buf, sizeof(port_buf), "%d", port);
    error= getaddrinfo(NULL, port_buf, &hints, &ai);
    if (error != 0)
    {
        if (error != EAI_SYSTEM)
            fprintf(stderr,	"getaddrinfo():	%s\n", gai_strerror(error));
        else
            perror("getaddrinfo()");
        return 1;
    }

    for	(next= ai; next; next= next->ai_next)
    {
        conn *listen_conn_add;
        if ((sfd = new_socket(next)) ==	-1)
        {
            continue;
        }

        setsockopt(sfd,	SOL_SOCKET,	SO_REUSEADDR, (void	*)&flags, sizeof(flags));
        if (IS_UDP(transport))
        {
            maximize_sndbuf(sfd);
        }
        else
        {
            error =	setsockopt(sfd,	SOL_SOCKET,	SO_KEEPALIVE, (void	*)&flags, sizeof(flags));
            if (error != 0)
                perror("setsockopt");

            error =	setsockopt(sfd,	SOL_SOCKET,	SO_LINGER, (void *)&ling, sizeof(ling));
            if (error != 0)
                perror("setsockopt");

            error =	setsockopt(sfd,	IPPROTO_TCP, TCP_NODELAY, (void	*)&flags, sizeof(flags));
            if (error != 0)
                perror("setsockopt");
        }

        if (bind(sfd, next->ai_addr, next->ai_addrlen) == -1)
        {
            if (errno != EADDRINUSE)
            {
                perror("bind()");
                close(sfd);
                freeaddrinfo(ai);
                return 1;
            }
            close(sfd);
            continue;
        }
        else
        {
            success++;
            if (!IS_UDP(transport) && listen(sfd, 1024)	== -1)
            {
                perror("listen()");
                close(sfd);
                freeaddrinfo(ai);
                return 1;
            }
        }

        if (IS_UDP(transport))
        {
            int	c;
            //是UDP的话直接入到处理事件中去
            for	(c = 0;	c <	stats.thread_num; c++)//为何此处有for,进行stats.thread_num次同样的操作
            {
                dispatch_conn_new(sfd, conn_read, EV_READ |	EV_PERSIST,
                        UDP_READ_BUFFER_SIZE, transport);
            }
        }
        else
        {
            //不是UDP则需要将其放入到listen conn中去
            if (!(listen_conn_add = conn_new(sfd, conn_listening,
                            EV_READ | EV_PERSIST, 1,
                            transport, main_base)))
            {
                fprintf(stderr,	"failed	to create listening	connection\n");
                exit(EXIT_FAILURE);
            }
            listen_conn_add->next =	listen_conn;
            listen_conn	= listen_conn_add;
        }
    }

    freeaddrinfo(ai);

    return success == 0;
}

extern int keepalive_stop;

static void	sig_handler(const int sig)
{
    if(stats.run_level==1)
    {		
        fprintf(stdout, "SIGINT handled.\n");
        fprintf(stdout, "nac_server exit normal.\n");
    }
    keepalive_stop = 1;
    MSG_LOG("=== Program will stop! ===\n");
    exit(EXIT_SUCCESS);
}

void usage()
{

    printf("cmd [option] [arg]:\n"
            "-b            		run as a daemon\n"
            "-d            		run as a debug\n"
            "-f <config file>   read config file (default:/etc/nac_event.conf)\n"
            "-v                 nac_erver version\n"
          );
    return;
}

int main (int argc, char **argv)
{
    int	c;
    int   set_conf=0;
    int is_daemon = 0;
    int is_core_dump = 0;
    // check auth nac_server license
    if(CHECK_LIC("TOPNAC_LIC_SERVER")==0)
    {
        fprintf(stderr,"no Topnac server license!\n");
        return -1;
    }
    
    signal(SIGINT, sig_handler);
    //操作断开的socket时，可能会触发这个信号,导致服务退出
    signal(SIGPIPE, SIG_IGN);
    if (sigignore(SIGPIPE) == -1){
        perror("failed to ignore SIGPIPE; sigaction");
        exit(EX_OSERR);
    }
    memset(&nac_conf,0,sizeof(nac_server_conf));

    while ( -1 != (c = getopt(argc, argv,"d:bCf:hv?")) )
    {
        switch(c)
        {
            case 'b':
                {
                    is_daemon = 1;
                    break;
                }
            case 'C':
                {
                    is_core_dump = 1;
                    break;
                }
                break;
            case 'd':
                {
                    stats.run_level = atoi(optarg);
                    break;
                }
            case 'f':
                {
                    snprintf(nac_conf.config_path, sizeof(nac_conf.config_path), "%s", optarg); 
                    break;
                }
            case 'v':
                {
                    fprintf(stdout, "nac_server version : %s\n", __NAC_SERVER_VERSION__);
                    exit(0);
                }
            case 'h':
            case '?':
            case ':':
                usage();
                exit(0);
                break;
            default:
                break;
        }
    } 

    if ( is_daemon )
    {
       daemon(1,1);  
    }

    if ( stats.run_level )
    {
        fprintf( stdout, "run_level :%d\n", stats.run_level );
    }
    if ( is_core_dump == 1 )
    {
        //启用coredump文件调试
        struct rlimit core;
        getrlimit(RLIMIT_CORE,&core);
        core.rlim_cur = RLIM_INFINITY;
        core.rlim_max= RLIM_INFINITY;
        setrlimit(RLIMIT_CORE,&core);
        //TLOG_DEBUG( "debug coredump is enable" );
    }

    load_nac_server_conf(&nac_conf);//加载/etc/nac_server.conf配置
    log_init();
    topzmq_context_init(&zmq_context,NAC_SERVER_CONF);
    stats_init();
    KTL_init();
    tawstd_init(0,NULL);
    //keepalive_init();/*------cache_______*/
    //print_nac_server_conf(&nac_conf);
    main_base =	event_init();
    conn_init();
    
    MSG_LOG("=== Program is starting === \n");

    thread_init(stats.thread_num, main_base);//线程处理
    if((nac_conf.server.type==NAC_SERVER_ALL)||(nac_conf.server.type==NAC_SERVER_TCP)){
        if (server_socket(stats.tcp_port,tcp_transport, NULL)){
            perror("failed to listen on	TCP	port ");
            exit(EX_OSERR);
        }
    }
    errno =0;
    if((nac_conf.server.type==NAC_SERVER_ALL)||(nac_conf.server.type==NAC_SERVER_TCP)){
        if (server_socket(stats.udp_port,udp_transport,NULL)){
            perror("failed to listen on	UDP	port %d");
            exit(EX_OSERR);
        }
    }
    offline_user_init();    
    keep_alive_table_work();
    errno = 0;
    if((nac_conf.server.type==NAC_SERVER_ALL)||(nac_conf.server.type==NAC_SERVER_TCP)){
        if (server_socket(stats.keepalive_tcp_port,tcp_keepalive_transport,NULL)){
            perror("failed to listen on	TCP	port %d");
            exit(EX_OSERR);
        }
    }
    errno = 0;
    if((nac_conf.server.type==NAC_SERVER_ALL)||(nac_conf.server.type==NAC_SERVER_UDP)){
        if (server_socket(stats.keepalive_udp_port,udp_keepalive_transport,NULL)){
            perror("failed to listen on	UDP	port %d");
            exit(EX_OSERR);
        }
    }
    event_base_loop(main_base, 0);
    offline_user_finsh();
    return 0;
}




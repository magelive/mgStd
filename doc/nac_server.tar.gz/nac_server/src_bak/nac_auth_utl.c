#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <security/pam_appl.h>
#include <security/pam_misc.h>
#include <stdio.h>
#include  "md5.h"
#include "nac_server.h"
#include "nac_auth_utl.h"
#include "PAM_check_user.h"
#include "nac_server_log.h"

void md5_decode(unsigned char *output, unsigned char * input, int len)
{
	FR_MD5_CTX context;
	fr_MD5Init(&context);                                             
  fr_MD5Update(&context, input, len);      
  fr_MD5Final(output, &context);    
}
void get_rand_str(char s[],int number)
{
	char str[64] = "00123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"; 
  int i;
  
  srand((unsigned int)time((time_t *)NULL));
  for(i=0;i<number;i++){
    s[i]=str[(rand()%62)+1];
  }
}

/*
    认证挑战信息
*/

int nac_check_user(char *username, char *passwd)
{
    int ret = -1;
    ret = PAM_auth(PAM_MODEL_NAME, username, passwd);
    if (ret == PAM_SUCCESS)
    {
        return 1;
    }
    return 0;
}

int nac_verify_chellage(struct conn *c)
{
	char	*ptr;
	char	string[1 + MAX_STRING_LEN*2]="";
	unsigned char output[MAX_STRING_LEN]="";
	unsigned short len;
	int clen=0;

	if (c->measure.data_size <= 16) {
        ERR_LOG("Expected 16 bytes of response to challenge, got %d", c->measure.data_size);
		//printf( "Expected 16 bytes of response to challenge, got %d", c->measure.data_size);
		return 0;
	}
	
	len = 0;
	ptr = string;
 	
 	clen=16;	
 	
	//*ptr++ = clen;
	//len++;
	memcpy(ptr, c->measure.challenge,  clen);
	len += clen;
	ptr+=clen;
	c->passwd = (char *)malloc(33);
	memset(c->passwd, 0, 33);
    int i;
	for (i = 0; i < 16; i++)
	{
	    sprintf(c->passwd+i*2, "%02x",(unsigned char)*(c->measure.tnccs_data+4+sizeof(struct_apply)+i));
	}
	
	c->passwd[32] = '\0';
	return nac_check_user(c->username,c->passwd);
}

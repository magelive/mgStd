#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sqlite3.h>

#include "nac_conn_sqlite3.h"

int  nac_policy_open_db(sqlite3 **pdb, char *dbpath)
{
    int ret = sqlite3_open(dbpath, pdb);
    if( ret != SQLITE_OK )
    {
	    printf("error:数据库打开失败");
	return  1;
    } 
    return 0;
}

int  nac_policy_reopen_db(sqlite3 **pdb,char *dbpath)
{
    if (*pdb)
	sqlite3_close( *pdb );
    return (nac_policy_open_db(pdb,dbpath));
}

void nac_policy_uninit_db(sqlite3 *pdb)
{	
    sqlite3_close( pdb );
}

int nac_exec_sql(sqlite3 **pdb,char *sql,nac_sql_callback callback,void *argv, char *dbpath)
{
	int rc=0;
	char *errmsg=NULL;
	if(pdb==NULL)
	{
		printf("wrong db handler\n");
		return 1;
	}
	if(*pdb==NULL)
	{
		nac_policy_open_db(pdb,dbpath);
	}
	
	rc=sqlite3_exec(*pdb,sql,callback,argv,&errmsg);
	if(rc!=SQLITE_OK)/*执行错误,重连一下数据库，再执行*/
	{
		nac_policy_reopen_db(pdb,dbpath);
		rc=sqlite3_exec(*pdb,sql,callback,argv,&errmsg);
		if(rc!=SQLITE_OK)
		{
			printf("执行sql:%s错误:%s",sql,errmsg);
			return -1;
		}	
	}
	
	return 0;	
}

int nac_get_table(sqlite3 **pdb,char *sql,char ***result,char *dbpath)
{
	int rc=0;
	char *errmsg=NULL;
	int rows=0;
	int cols=0;
	
	if(pdb==NULL)
	{
		printf("wrong db handler\n");
		return 1;
	}
	if(*pdb==NULL)
	{
		nac_policy_open_db(pdb,dbpath);
	}
	
	rc=sqlite3_get_table(*pdb,sql,result,&rows,&cols,&errmsg);
	if(rc!=SQLITE_OK)/*执行错误,重连一下数据库，再执行*/
	{
		nac_policy_reopen_db(pdb,dbpath);
		rc=sqlite3_get_table(*pdb,sql,result,&rows,&cols,&errmsg);
		if(rc!=SQLITE_OK)
		{
			printf("执行sql:%s错误:%s",sql,errmsg);
			return -1;
		}	
	}
	return rows;	
}

int nac_free_table(char **result)
{
	sqlite3_free_table(result);
	return 0;
}

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sqlite3.h>
#include <nac/nac_std.h>
#include "nac_load_conf.h"
#include "nac_server_log.h"

extern topnac_policy  glob_policy;


static int get_value(char *line,char**value)
{
    char *ps=NULL;
    char *pe=NULL;
    if(ps=strchr(line,'=')){
        while(*ps){
            if(*ps=='"'){
                ps++;
                if(pe=strchr(ps,'"')){
                    *value=strndup(ps,pe-ps);
                    return 0;
                }
            }
            ps++;
        }
    }
    return 1;
}

int load_server_conf(nac_server_conf *conf,char *conf_file)
{
    char *strval = NULL;
    int  ival = 0;
    char *pfield = NULL;
    char *token = NULL;
    int  i=0;

    if(! config_read_file(&(conf->conf), conf_file)){
        ns_err_log("%s:%d - %s\n", config_error_file(&(conf->conf)),
                config_error_line(&(conf->conf)), config_error_text(&(conf->conf)));
        config_destroy(&(conf->conf));
        return(1);
    }

    conf->auth_type = NAC_SERVER_ALL;
    conf->sync_type = NAC_SERVER_ALL;
    conf->is_auth = 1;
    conf->is_fastconnect = 1;
    conf->auth_tcp_port = conf->auth_udp_port = 2600;
    conf->sync_tcp_port = conf->sync_udp_port = 2600;
    conf->sync_times = 4;
    conf->sync_msec = 5000;                          //保活间隔时间
    conf->max_node = 100000;                           //缓冲最大节点
    conf->max_conn_struct = 10000;                    //最大处理数
    conf->thread_num = 4;                         //同时处理线程数
    conf->log_port = 514;                           //sys日志端口
    conf->log_level = 2;                          //sys日志等级
    conf->log_ip[32] = strdup("127.0.0.1");                        //sys日志输出地址 
    conf->PAM_model[256] = strdup("");                    //PAM认证模块名
    
    /*读取 server配置 */
    config_lookup_string(&(conf->conf),"server.type",(const char**)&strval);
    if(strval)
    {
        if(strcmp(strval,"tcp")==0)  
        {
            conf->server.type = NAC_SERVER_TCP;
        }
        else if(strcmp(strval,"udp")==0)  
        {
            conf->server.type = NAC_SERVER_UDP;
        }
        else if(strcmp(strval,"all")==0)  
        {
            conf->server.type = NAC_SERVER_ALL;
        }
        else
            conf->server.type = NAC_SERVER_ALL; /*默认全部打开*/
    }
    
    if(config_lookup_int(&(conf->conf),"server.keepalive_tcp_port",&ival))
    {
        conf->server.keepalive_tcp_port = ival;
    }
    else
    {
        conf->server.keepalive_tcp_port = 51743;
    }
    
    if(config_lookup_int(&(conf->conf),"server.keepalive_udp_port",&ival))
    {
        conf->server.keepalive_udp_port = ival;
    }
    else
    {
        conf->server.keepalive_udp_port = 51743;
    }
    
    if(config_lookup_int(&(conf->conf),"server.udp_port",&ival))
    {
        conf->server.udp_port = ival;
    }
    else
    {
        conf->server.udp_port = 51742;
    }
    
    if(config_lookup_int(&(conf->conf),"server.tcp_port",&ival))
    {
        conf->server.tcp_port = ival;
    }
    else 
    {
        conf->server.tcp_port = 51742;
    }

    if(config_lookup_int(&(conf->conf),"server.max_node",&ival))
    {
        conf->server.max_node = ival;
    }
    else
    {
        conf->server.max_node = 100000;
    }

    if(config_lookup_int(&(conf->conf),"server.max_conn_struct",&ival))
    {
        conf->server.max_conn_struct = ival;
    }
    else
    {
        conf->server.max_conn_struct = 10000;
    }

    if(config_lookup_int(&(conf->conf),"server.thread_num",&ival))
    {
        conf->server.thread_num = ival;
    }
    else
    {
        conf->server.thread_num = 4;
    }

    if(config_lookup_int(&(conf->conf),"server.is_auth",&ival))
    {
        conf->is_auth = ival;
    }
    else
    {
        conf->is_auth = 1;
    }   
    
    if(config_lookup_int(&(conf->conf),"server.keepalive_times",&ival))
    {
        conf->server.keepalive_times = ival;
    }
    else
    {
        conf->server.keepalive_times = 3;
    }
    if(config_lookup_int(&(conf->conf),"server.keepalive_msec",&ival))
    {
        conf->server.keepalive_msec= ival;
    }
    else
    {
        conf->server.keepalive_msec = 5000;
    }
    if(config_lookup_int(&(conf->conf),"server.is_fastconnect",&ival))
    {
        conf->is_fastconnect= ival;
    }
    else
    {
        conf->is_fastconnect = 1;
    }
    if (config_lookup_int(&(conf->conf), "server.check_time", &ival))
    {
        conf->server.check_time = ival;
    }
    else
    {
        conf->server.check_time = (60*1);
    }
    config_lookup_string(&(conf->conf),"server.log_ip",(const char**)&strval);
    if (strval)
    {
        conf->server.log_ip = strval;
    }
    else
    {
        conf->server.log_ip = "127.0.0.1";
    }
    if(config_lookup_int(&(conf->conf),"server.log_port",&ival))
    {
        conf->server.log_port= ival;
    }
    else
    {
        conf->server.log_port = 514;
    }
    if(config_lookup_int(&(conf->conf),"server.log_level",&ival))
    {
        conf->server.log_level= ival;
    }
    else
    {
        conf->server.log_level = 0;
    }
    
    return 0;
}

void load_nac_server_conf(nac_server_conf *conf)
{ 
    pthread_t reload_pid;
    conf->glob_policy = NULL;
    conf->lua_context = NULL;

    char *config_path = NAC_SERVER_CONF;
    if ( strlen(conf->config_path) > 0  )
        config_path = conf->config_path;
    load_server_conf(conf, config_path);
}

void unload_nac_server_conf(nac_server_conf *conf)
{
    //unload_ldap_conf(&(conf->ldap_conf));
    uninit_glob_nac_policy();
    uninit_lua_context(conf->lua_context);
    config_destroy(&(conf->conf));
}



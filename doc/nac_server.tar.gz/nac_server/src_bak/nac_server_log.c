
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdarg.h>
#include <time.h>
#include <event2/event.h>

#include "nac_server_log.h"
#include "nac_load_conf.h"
#define DATA_MTU        1400
#define DEFAULT_PORT    6325
#define DEFAULT_IP      "127.0.0.1"

extern nac_server_conf nac_conf;

static int log_fd = -1;
static int log_level = NAC_LOG_MSG;
static struct sockaddr_in log_addr;
static int send_log(char *, int);
void log_init()
{
    log_level = nac_conf.server.log_level;
    char *ip = nac_conf.server.log_ip;
    int port = nac_conf.server.log_port;
    printf("log ip = %s, port = %d\n", ip, port);
    
    /* 建立socket，注意必须是SOCK_DGRAM */
    if ((log_fd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) 
    {
        perror("log socket :");
        exit(1);
    }

    /* 填写sockaddr_in*/
    bzero(&log_addr, sizeof(log_addr));
    log_addr.sin_family = AF_INET;
    log_addr.sin_port = htons(port);
    log_addr.sin_addr.s_addr = inet_addr(ip);

    //init libevent log
    event_set_log_callback(set_libevent_log);
    return;
}


void get_cur_time(char *buf, int buf_len)
{
    if (buf == NULL)
        return;
    time_t tm;
    time(&tm); 
    struct tm *tf = localtime( &tm );
    snprintf( buf, buf_len, "%04d-%02d-%02d %02d:%02d:%02d",
        1900+tf->tm_year, 1+tf->tm_mon, tf->tm_mday,
            tf->tm_hour, tf->tm_min, tf->tm_sec );
    return;
}


void nac_server_log(int level, const char *fmt, ...)
{
    if (level < log_level)
        return;
    char buf[DATA_MTU];
    char *ptr = NULL;
    va_list ap;
    int len = 0;
    char *msg = NULL;
    int head_len = 0, ptr_len = 0;
    switch(level)
    {
        case NAC_LOG_DEBUG:
            msg = "DEBUG";
            break;
        case NAC_LOG_MSG:
            msg = "MSG";
            break;
        case NAC_LOG_WARN:
            msg = "WARN";
            break;
        case NAC_LOG_ERR:
            msg = "ERROR";
            break;
        default :
            msg = "UNKNOW";
            break;
    }
    //printf("msg = %s\n", msg);
    char cur_time[32];
    get_cur_time(cur_time, 32);
    pid_t pid = getpid();
    snprintf(buf, DATA_MTU, "[%s]<%s>[%d]:\0", msg, cur_time, pid); 
    head_len = strlen(buf);
    ptr = buf+head_len;
    ptr_len = DATA_MTU - head_len;
    va_start(ap, fmt);
    len = vsnprintf(ptr, ptr_len, fmt, ap);
    va_end(ap);

    if (log_fd == -1)
        log_init();

    send_log(buf, strlen(buf));
}

void nac_server_log_debug(const char *fmt, ...)
{
    if (NAC_LOG_DEBUG < log_level)
        return;
    char buf[DATA_MTU];
    char *ptr = NULL;
    va_list ap;
    int len = 0;
    char *msg = NULL;
    int head_len = 0, ptr_len = 0;
    msg = "DEBUG";
    char cur_time[32];
    get_cur_time(cur_time, 32);
    pid_t pid = getpid();
    pthread_t tid = pthread_self();
    snprintf(buf, DATA_MTU, "[%s]<%s>[%d-%0x]:\0", msg, cur_time, pid, tid); 
    head_len = strlen(buf);
    ptr = buf+head_len;
    ptr_len = DATA_MTU - head_len;
    va_start(ap, fmt);
    len = vsnprintf(ptr, ptr_len, fmt, ap);
    va_end(ap);

    if (log_fd == -1)
        log_init();

    send_log(buf, strlen(buf));
}

void nac_server_log_msg(const char *fmt, ...)
{
    if (NAC_LOG_MSG < log_level)
        return;
    char buf[DATA_MTU];
    char *ptr = NULL;
    va_list ap;
    int len = 0;
    char *msg = NULL;
    int head_len = 0, ptr_len = 0;
    msg = "MSG";
    char cur_time[32];
    get_cur_time(cur_time, 32);
    pid_t pid = getpid();
    snprintf(buf, DATA_MTU, "[%s]<%s>[%d]:\0", msg, cur_time, pid); 
    head_len = strlen(buf);
    ptr = buf+head_len;
    ptr_len = DATA_MTU - head_len;
    va_start(ap, fmt);
    len = vsnprintf(ptr, ptr_len, fmt, ap);
    va_end(ap);

    if (log_fd == -1)
        log_init();

    send_log(buf, strlen(buf));
}

void nac_server_log_warn(const char *fmt, ...)
{
    if (NAC_LOG_WARN < log_level)
        return;
    char buf[DATA_MTU];
    char *ptr = NULL;
    va_list ap;
    int len = 0;
    char *msg = NULL;
    int head_len = 0, ptr_len = 0;
    msg = "WARN";
    char cur_time[32];
    get_cur_time(cur_time, 32);
    pid_t pid = getpid();
    snprintf(buf, DATA_MTU, "[%s]<%s>[%d]:\0", msg, cur_time, pid); 
    head_len = strlen(buf);
    ptr = buf+head_len;
    ptr_len = DATA_MTU - head_len;
    va_start(ap, fmt);
    len = vsnprintf(ptr, ptr_len, fmt, ap);
    va_end(ap);

    if (log_fd == -1)
        log_init();

    send_log(buf, strlen(buf));
}

void nac_server_log_err(const char *fmt, ...)
{
    if (NAC_LOG_ERR < log_level)
        return;
    char buf[DATA_MTU];
    char *ptr = NULL;
    va_list ap;
    int len = 0;
    char *msg = NULL;
    int head_len = 0, ptr_len = 0;
    msg = "ERROR";
    char cur_time[32];
    get_cur_time(cur_time, 32);
    pid_t pid = getpid();
    snprintf(buf, DATA_MTU, "[%s]<%s>[%d]:\0", msg, cur_time, pid); 
    head_len = strlen(buf);
    ptr = buf+head_len;
    ptr_len = DATA_MTU - head_len;
    va_start(ap, fmt);
    len = vsnprintf(ptr, ptr_len, fmt, ap);
    va_end(ap);

    if (log_fd == -1)
        log_init();

    send_log(buf, strlen(buf));
}

static int send_log(char *buffer, int buffer_len)
{
    if (buffer == NULL || log_fd <= 0 || buffer_len <= 0)
        return -1;
    int sendsize = 0, ret = 0;
    int addr_len = sizeof(log_addr);
    while(sendsize < buffer_len)
    {
        ret = sendto(log_fd, buffer+sendsize, buffer_len-sendsize, 0, (struct sockaddr *)&log_addr, addr_len);
        if (ret <= 0)
            break;
        sendsize += ret;
    }
    return sendsize;
}

void log_fini()
{
    close(log_fd);
    log_fd = -1;
}

int test_main()
{
    log_init();
    int sendtimes = 0;
    while(sendtimes < 10000)
    {
       sendtimes++;
       nac_server_log(NAC_LOG_DEBUG, "This is debug log! send times %d!\n", sendtimes);
       nac_server_log(NAC_LOG_MSG, "This is msg log! send times %d!\n", sendtimes);
       nac_server_log(NAC_LOG_WARN, "This is warning log! send times %d!\n", sendtimes);
       nac_server_log(NAC_LOG_ERR, "This is error log! send times %d!\n", sendtimes);
       nac_server_log(18, "This is unkown log! send times %d!\n", sendtimes);
       usleep(1000*100);
    }
    log_fini();
}


void set_libevent_log(int level, const char *msg)
{
    char buf[DATA_MTU];
    bzero(buf, DATA_MTU); 
    char *s = NULL;
    switch(level)
    {
        case _EVENT_LOG_DEBUG:
            s = "debug";
            break;
        case _EVENT_LOG_MSG:
            s = "msg";
            break;
        case _EVENT_LOG_WARN:
            s = "warn";
            break; 
        case _EVENT_LOG_ERR:
            s = "error";
            break;
        default: 
            s = "?";    
            break;
    }
    snprintf(buf, DATA_MTU-1, "[evemt-%s]:%s\n", s, msg);
    send_log(buf, strlen(buf));
    return;
}


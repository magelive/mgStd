#ifndef _NAC_PARSE_XML_H_
#define _NAC_PARSE_XML_H_
#include <libxml2/libxml/tree.h>
#include <libxml2/libxml/parser.h>

typedef   void (*Process_Node)(xmlNodePtr node,void *arg);
char *get_path_node_value(xmlNodePtr root,char *path);
xmlDocPtr parse_xml_doc(void *data,xmlNodePtr *root, int size, int type);
void  destroy_xml_doc(xmlDocPtr doc);

void travle_xml_Child_Node(xmlNodePtr root,Process_Node fun,void *arg);
void print_xml_value(xmlNodePtr root);

#endif

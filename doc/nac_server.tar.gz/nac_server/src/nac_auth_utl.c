#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <security/pam_appl.h>
#include <security/pam_misc.h>
#include <stdio.h>
#include "nac_auth_utl.h"
#include "PAM_check_user.h"
#include "nac_server_log.h"

void get_rand_str(char s[],int number)
{
    char str[64] = "00123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"; 
    int i;

    srand((unsigned int)time((time_t *)NULL));
    for(i=0;i<number;i++){
        s[i]=str[(rand()%62)+1];
    }
}

/*
    认证挑战信息
*/

int nac_check_user(char *username, char *passwd)
{
    int ret = -1;
    ret = PAM_auth(PAM_MODEL_NAME, username, passwd);
    if (ret == PAM_SUCCESS)
    {
        return 1;
    }
    return 0;
}

int nac_verify_chellage(char *username, char *password_16)
{
    char *passwd_32 = NULL;
    
    passwd_32 = (char *)malloc(33);
    if (passwd_32 == NULL)
    {
        ns_err_log("passwd 32bit malloc faild!");
        return 0;
    }
    memset(passwd_32, 0, 33);
    int i;
    for (i = 0; i < 16; i++)
    {
        sprintf(passwd_32 + i*2, "%02x",(unsigned char)*(password_16)+i));
    }

    passwd_32[32] = '\0';
    int result = nac_check_user(username, passwd_32);
    free(passwd_32);
    return result; 
}

#ifndef  _NAC_LOAD_CONF_H_
#define  _MAC_LOAD_CONF_H_

#include <libconfig.h>
#include "nac_server.h"

#define NAC_SERVER_CONF   "/etc/nac_server.conf"

enum server_type
{
    NAC_SERVER_LOCAL,
    NAC_SERVER_UDP,
    NAC_SERVER_TCP,
    NAC_SERVER_ALL
};

typedef struct _nac_server_conf
{	
	config_t conf;                          //conf标识符
    enum server_type  auth_type;            //认证类型? :local tcp udp all
    enum server_type  sync_type;            //保活类型? :local tcp udp all
	int is_auth;                            //是否认证 0:1
	int is_fastconnect;                     //是否开启快速连接
    int	auth_tcp_port;                      //认证tcp端口
    int	auth_udp_port;                      //认证udp
    int sync_tcp_port;                      //保活tcp端口keepalive
    int sync_udp_port;                      //保活upd
    int sync_times;                         //保活次数
    int sync_msec;                          //保活间隔时间
    int max_node;                           //缓冲最大节点
    int max_conn_struct;                    //最大处理数
    int thread_num;                         //同时处理线程数
    int ngunp_sync_time;                    //和ngump同步时间
    int syslog_port;                           //sys日志端口
    int syslog_level;                          //sys日志等级
    char syslog_ip[32];                        //sys日志输出地址 
	char PAM_model[256];                    //PAM认证模块名
    char config_path[256];                  //配置文件路径
}nac_server_conf;

void load_nac_server_conf(nac_server_conf *conf);
void unload_nac_server_conf(nac_server_conf *conf);
#endif

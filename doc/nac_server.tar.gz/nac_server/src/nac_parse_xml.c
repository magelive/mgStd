#include <string.h>
#include <stdio.h> 
#include "nac_parse_xml.h"
#include "nac_server_log.h"

/******************************************************
 * 解析xml数据
 * type：0:内存,1:文件
 * data：type=0时代表xml数据,type=1时代表xml文件路径
 * size: type=0时代表data的大小,type=1时无意义
 * root: 解析成功后指向xml根节点
 *返回：成功：解析后的doc句柄
 *      失败：NULL			
 ******************************************************/

xmlDocPtr parse_xml_doc(void *data,xmlNodePtr *root, int size, int type)
{
    if(NULL==data)
    {
        ns_err_log("parse_xml_doc: emptyp data\n");
        return NULL;
    }	
    xmlDocPtr doc=NULL;
    xmlKeepBlanksDefault(0); 
    if(type)
    {	
        doc=xmlParseFile(data);//创建Dom树
    }
    else
    {
        doc=xmlParseMemory(data,size);
    }	
    if(doc==NULL)
    {
        ns_err_log("parse_xml_doc: Loading xml file failed.\n");
        return NULL; 
    }

    *root=xmlDocGetRootElement(doc);//获取根节点
    if(NULL==*root)
    {
        ns_err_log("parse_xml_doc: empty file\n");
        xmlFreeDoc(doc); 
        return NULL; 
    }
    return doc;
}

/*********************************************
 * 释放xml句柄
 **********************************************/ 

void  destroy_xml_doc(xmlDocPtr doc)
{
    if(doc)
    {	
        xmlFreeDoc(doc);
    }
    xmlCleanupParser();
}


void travle_xml_Child_Node(xmlNodePtr root,Process_Node fun,void *arg)
{
    xmlNodePtr  cur=NULL;
    xmlKeepBlanksDefault(0); 

    cur=root->xmlChildrenNode;
    if(cur!=NULL)
    {	
        while(cur !=NULL)
        {
            fun(cur,arg);
            cur=cur->next;
        }
    }
}

static void print_node_value(xmlNodePtr node,void *arg)
{
    xmlNodePtr cur=NULL;

    char *name=NULL;
    char *value=NULL;
    if(node)
    {
        if (node->type==XML_TEXT_NODE)
        {
            value=(char*)xmlNodeGetContent(node);
            printf(" %s \n",value);
            xmlFree(value);
            return ;
        }
        name=(char *)(node->name);

        printf("<%s ",name);

        xmlAttrPtr prop;
        xmlDocPtr doc;

        if (node->type == XML_ELEMENT_NODE)
        {    
            prop = node->properties;
            while (prop != NULL) 
            {
                printf("%s=\"%s\",",prop->name,xmlGetProp(node, prop->name));
                prop = prop->next;
            }
        }
        printf(">\n");

        cur=node->xmlChildrenNode;
        if(cur!=NULL)
        {
            while(cur!=NULL)
            {		
                if(cur->type == XML_ELEMENT_NODE)
                {
                    print_node_value(cur,arg);
                }
                else
                {
                    value=(char*)xmlNodeGetContent(cur);
                    printf(" %s \n",value);
                    xmlFree(value);
                }
                cur=cur->next;
            }
        }
        printf("</%s>",name);
    }
}

/**
 *
 *@path: A.B.C.D.E
 * */

static xmlNodePtr  get_path_node(xmlNodePtr node,char *path)
{
    xmlNodePtr cur=NULL;
    char *dim_s=NULL;
    char *dim_e=NULL;
    char *name=NULL;
    char *value=NULL;
    if(node)
    {
        dim_s=strchr(path,'.');
        name=(char *)(node->name);
        cur=node->xmlChildrenNode;

        if(dim_s)
        {
            dim_e=strchr(dim_s+1,'.');
            if(strncmp(name,path,dim_s-path)==0)
            {
                while(cur)
                {
                    if(dim_e)
                    {
                        if(strncmp((char*)(cur->name),dim_s+1,dim_e-dim_s-1)==0)
                        {
                            return  get_path_node(cur,dim_s+1);
                        }
                    }
                    else
                    {
                        if(strcmp((char*)(cur->name),dim_s+1)==0)
                        {
                            return cur;
                        }
                    }

                    cur=cur->next;
                }
            }
        }
        else
        {
            if(strcmp(name,path)==0)
            {
                return node;
            }
            else
            {
                return NULL;
            }
        }

    }
    return NULL;
}

char *get_path_node_value(xmlNodePtr root,char *path)
{
    char *value=NULL;
    xmlNodePtr node=get_path_node(root,path);
    if(node)
    {
        value=(char*)xmlNodeGetContent(node);
    }
    return value;
}

void print_xml_value(xmlNodePtr root)
{
    travle_xml_Child_Node(root,print_node_value,NULL);

}

/**
  int main(int argc, char *argv[])
  {
  xmlDocPtr doc=NULL;
  xmlNodePtr root=NULL;

  doc = parse_xml_doc(argv[1],&root,0, 1);
  xmlNodePtr node=get_path_node(root,argv[2]);
  if(node)
  {
  print_xml_value(node);
  }
  destroy_xml_doc(doc);

  return 0;
  }

 **/

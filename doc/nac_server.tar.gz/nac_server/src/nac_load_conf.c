#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sqlite3.h>
#include <nac/nac_std.h>
#include "nac_load_conf.h"
#include "nac_server_log.h"

static int get_value(char *line,char**value)
{
    char *ps=NULL;
    char *pe=NULL;
    if(ps=strchr(line,'=')){
        while(*ps){
            if(*ps=='"'){
                ps++;
                if(pe=strchr(ps,'"')){
                    *value=strndup(ps,pe-ps);
                    return 0;
                }
            }
            ps++;
        }
    }
    return 1;
}

int load_server_conf(nac_server_conf *conf,char *conf_file)
{
    char *strval = NULL;
    int  ival = 0;
    char *pfield = NULL;
    char *token = NULL;
    int  i=0;

    if(!config_read_file(&(conf->conf), conf_file)){
        ns_err_log("%s:%d - %s\n", config_error_file(&(conf->conf)),
                config_error_line(&(conf->conf)), config_error_text(&(conf->conf)));
        config_destroy(&(conf->conf));
        return(1);
    }

    conf->auth_type = NAC_SERVER_ALL;
    conf->sync_type = NAC_SERVER_ALL;
    conf->is_auth = 1;
    conf->is_fastconnect = 1;
    conf->auth_tcp_port = conf->auth_udp_port = 2600;
    conf->sync_tcp_port = conf->sync_udp_port = 2600;
    conf->sync_times = 4;
    conf->sync_msec = 5000;                          //保活间隔时间
    conf->max_node = 100000;                           //缓冲最大节点
    conf->max_conn_struct = 10000;                    //最大处理数
    conf->thread_num = 4;                         //同时处理线程数
    conf->ngunp_sync_time = 10;
    conf->syslog_port = 514;                           //sys日志端口
    conf->syslog_level = 2;                          //sys日志等级
    conf->syslog_ip[32] = strdup("127.0.0.1");                        //sys日志输出地址 
    conf->PAM_model[256] = strdup("");                    //PAM认证模块名
    
    /*读取 server配置 */
    if (config_lookup_string(&(conf->conf),"server.type",(const char**)&strval))
    {
        if(strval)
        {
            if(strcmp(strval,"tcp")==0)  
            {
                conf->auth_type = NAC_SERVER_TCP;
                conf->sync_type = NAC_SERVER_TCP;
            }
            else if(strcmp(strval,"udp")==0)  
            {
                conf->auth_type = NAC_SERVER_UDP;
                conf->sync_type = NAC_SERVER_UDP;
            }
            else if(strcmp(strval,"all")==0)  
            {
                conf->auth_type = NAC_SERVER_ALL;
                conf->sync_type = NAC_SERVER_ALL;
            }
        }
    }
    
    if(config_lookup_int(&(conf->conf),"server.keepalive_tcp_port",&ival))
    {
        conf->sync_tcp_port = ival;
    }
    
    if(config_lookup_int(&(conf->conf),"server.keepalive_udp_port",&ival))
    {
        conf->sync_udp_port = ival;
    }
    
    if(config_lookup_int(&(conf->conf),"server.udp_port",&ival))
    {
        conf->auth_udp_port = ival;
    }
    
    if(config_lookup_int(&(conf->conf),"server.tcp_port",&ival))
    {
        conf->auth_tcp_port = ival;
    }

    if(config_lookup_int(&(conf->conf),"server.max_node",&ival))
    {
        conf->max_node = ival;
    }

    if(config_lookup_int(&(conf->conf),"server.max_conn_struct",&ival))
    {
        conf->max_conn_struct = ival;
    }

    if(config_lookup_int(&(conf->conf),"server.thread_num",&ival))
    {
        conf->thread_num = ival;
    }

    if(config_lookup_int(&(conf->conf),"server.is_auth",&ival))
    {
        conf->is_auth = ival;
    }
    
    if(config_lookup_int(&(conf->conf),"server.keepalive_times",&ival))
    {
        conf->sync_times = ival;
    }
    
    if(config_lookup_int(&(conf->conf),"server.keepalive_msec",&ival))
    {
        conf->sync_msec= ival;
    }
    
    if(config_lookup_int(&(conf->conf),"server.is_fastconnect",&ival))
    {
        conf->is_fastconnect= ival;
    }
    
    if (config_lookup_int(&(conf->conf), "server.check_time", &ival))
    {
        conf->ngunp_sync_time = ival;
    }
    
    config_lookup_string(&(conf->conf),"server.log_ip",(const char**)&strval);
    if (strval)
    {
        conf->syslog_ip = strdup(strval);
    }

    if(config_lookup_int(&(conf->conf),"server.log_port",&ival))
    {
        conf->syslog_port= ival;
    }
    
    if(config_lookup_int(&(conf->conf),"server.log_level",&ival))
    {
        conf->syslog_level= ival;
    }
    
    return 0;
}

void load_nac_server_conf(nac_server_conf *conf)
{ 
    char *config_path = NAC_SERVER_CONF;
    if ( strlen(conf->config_path) > 0  )
        config_path = conf->config_path;
    load_server_conf(conf, config_path);
}

void unload_nac_server_conf(nac_server_conf *conf)
{
    config_destroy(&(conf->conf));
}



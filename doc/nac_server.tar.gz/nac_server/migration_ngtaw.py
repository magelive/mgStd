#!/usr/bin/env python
#-*- coding:UTF-8 -*-
import os
import shutil
import re
def migrate_file(filename):
    if not os.path.exists(filename+'.bak'):
        shutil.copy(filename,filename+'.bak')
    # res 
    include=re.compile('#include <tawstd/(.*).h>')
    #list_t=re.compile('(\s*|\()(list_)(\S+.*)')
    list_t=re.compile('.*[ \t\n\r\f\v(]+(list_)\S+')
    zytype=re.compile('.*(ZYT_\w+).*')
    #endof re
    f=open(filename+'.bak','r')
    out=open(filename,'w');
    include_changed=False
    for line in f:
        m =include.match(line)
        if m:
            out.write("//MIGRATE:"+line)
            if m.group(1).startswith('zy') :
                if not include_changed:
                   include_changed=True
                   out.write("#include <ngtawstd/zytypes.h>\n")
            else:
                out.write("#include <ngtawstd/%s.h>\n" % m.group(1))
            continue
        m = list_t.match(line)
        if m:
            out.write("//MIGRATE:"+line)
            #out.write( line[:m.start(1)]+"ts_list_"+line[m.end(1):] )
            #out.write( line.replace(""[:m.start(1)]+"ts_list_"+line[m.end(1):] )
            line =  line.replace(" list_"," ts_list_").replace("\tlist_","\tts_list_").replace(",list_",",ts_list_").replace("(list_","(ts_list_").replace("!list_","!ts_list_")
            if line.find('valist_next') >=0:
                out.write('''/* MIGRATE:
                MIGRATE: 由于不清楚当前是ZYLIST 还是 ZYMAP循环，所以不能自动迁移,
                MIGRATE: ZYMAP 循环:
                MIGRATE:  void* key=NULL;
                MIGRATE:  int key_len=0;
                MIGRATE:  ZYElem* item=NULL;
                MIGRATE:  ZYMAP_FOR_EACH(map, key,key_len,item)
                MIGRATE: ZLIST 循环:
                MIGRATE:  ZYElem* item=NULL;
                MIGRATE:  ZYLIST_FOR_EACH(list, item) 
                MIGRATE: */\n''')
                out.write(line)
            else:
                out.write(line)
            continue
        if re.match(r".*INIT_LOGGER.*",line):
            out.write("//MIGRATE:"+line)
            continue 
        if re.match(r".*TLOG_WARN.*",line):
            out.write("//MIGRATE:"+line)
            out.write(line.replace("TLOG_WARN","TLOG_WARNING"))
            continue 
        if re.match(r".*zymapgetorg.*",line):
            out.write("//MIGRATE:"+line)
            out.write(line.replace("zymapgetorg","zymap_get_zyorg"))
            continue 
        if re.match(r".*zymapgetlist.*",line):
            out.write("//MIGRATE:"+line)
            out.write(line.replace("zymapgetlist","zymap_get_zylist"))
            continue
        if re.match(r".*zymapgetmap.*",line):
            out.write("//MIGRATE:"+line)
            out.write(line.replace("zymapgetmap","zymap_get_zymap"))
            continue
        if re.match(r".*zymaplen.*",line):
            out.write("//MIGRATE:"+line)
            out.write(line.replace("zymaplen","_ZMLen"))
            continue
        if re.match(r".*zymapgetbuffer.*",line):
            out.write("//MIGRATE:"+line)
            out.write(line.replace("zymapgetbuffer","zymap_get_zybuffer"))
            continue
        if re.match(r".*zymapputstrcat.*",line):
            out.write("//MIGRATE:"+line)
            out.write(line.replace("zymapputstrcat","zymap_put_str_cat"))
            continue
        if re.match(r".*zymapputstr.*",line):
            out.write("//MIGRATE:"+line)
            out.write(line.replace("zymapputstr","zymap_put_str"))
            continue
        if re.match(r".*zymapputmap.*",line):
            out.write("//MIGRATE:"+line)
            out.write(line.replace("zymapputmap","zymap_put_zymap"))
            continue 
        if re.match(r".*zymapputint.*",line):
            out.write("//MIGRATE:"+line)
            out.write(line.replace("zymapputint","zymap_put_int32"))
            continue 
        if re.match(r".*zymapgetint.*",line):
            out.write("//MIGRATE:"+line)
            out.write(line.replace("zymapgetint","zymap_get_int32"))
            continue 
        if re.match(r".*zymapputdouble.*",line):
            out.write("//MIGRATE:"+line)
            out.write(line.replace("zymapputdouble","zymap_put_double"))
            continue 
        if re.match(r".*zymapgetdouble.*",line):
            out.write("//MIGRATE:"+line)
            out.write(line.replace("zymapgetdouble","zymap_get_double"))
            continue 
        if re.match(r".*zymapputlist.*",line):
            out.write("//MIGRATE:"+line)
            out.write(line.replace("zymapputlist","zymap_put_zylist"))
            continue 
        if re.match(r".*zymapclear.*",line):
            out.write("//MIGRATE:"+line)
            out.write(line.replace("zymapclear","zymap_reset"))
            continue 
        if re.match(r".*zymapgetstr.*",line):
            out.write("//MIGRATE:"+line)
            out.write(line.replace("zymapgetstr","zymap_get_str"))
            continue
        if re.match(r".*zylistgetmap.*",line):
            out.write("//MIGRATE:"+line)
            out.write(line.replace("zylistgetmap","zylist_get_zymap"))
            continue
        if re.match(r".*zylistaddmap.*",line):
            out.write("//MIGRATE:"+line)
            out.write(line.replace("zylistaddmap","zylist_append_zymap"))
            continue
        if re.match(r".*zymapnew.*",line):
            out.write("//MIGRATE:"+line)
            out.write(line.replace("zymapnew","zymap"))
            continue
        if re.match(r".*zylistnew.*",line):
            out.write("//MIGRATE:"+line)
            out.write(line.replace("zylistnew","zylist"))
            continue
        if re.match(r".*zymapdel.*",line):
            out.write("//MIGRATE:"+line)
            out.write(line.replace("zymapdel","zymap_free"))
            continue
        if re.match(r".*zylistdel.*",line):
            out.write("//MIGRATE:"+line)
            out.write(line.replace("zylistdel","zylist_free"))
            continue 
        if re.match(r".*zybufferdel.*",line):
            out.write("//MIGRATE:"+line)
            out.write(line.replace("zybufferdel","zybuffer_free"))
            continue 
        if re.match(r".*zylistlen.*",line):
            out.write("//MIGRATE:"+line)
            out.write(line.replace("zylistlen","_ZLLen"))
            continue 
        if re.match(r".*zymapdump.*",line):
            out.write("//MIGRATE:"+line)
            out.write(line.replace("zymapdump","zymap_dump_ptr"))
            continue
        if re.match(r".*zylistdump.*",line):
            out.write("//MIGRATE:"+line)
            out.write(line.replace("zylistdump","zylist_dump_ptr"))
            continue 
        if re.match(r".*INIT_LIST_HEAD.*",line):
            out.write("//MIGRATE:"+line)
            out.write(line.replace("INIT_LIST_HEAD","TS_INIT_LIST_HEAD")) 
            continue
        if re.match(r".*LIST_HEAD.*",line):
            out.write("//MIGRATE:"+line)
            out.write(line.replace("LIST_HEAD","TS_LIST_HEAD")) 
            continue
        if re.match(r".*zylistbsort.*",line):
            out.write("//MIGRATE:"+line)
            out.write(line.replace("zylistbsort","zylist_bsort")) 
            continue
    

        m=zytype.match(line)
        if m:
            out.write("//MIGRATE:"+line)
            if m.group(1) == "ZYT_unknown":
                out.write(line[:m.start(1)]+"ZYT_UNDEFINE".upper()+line[m.end(1):])
            else:
                out.write(line[:m.start(1)]+m.group(1).upper()+line[m.end(1):])
            continue


        out.write(line)
    f.close()

import sys
if __name__ == "__main__":
    mpath=["./"]
    if len(sys.argv) > 1:
        mpath=sys.argv[1:]
    for m in mpath:
        if os.path.isdir(m):
            for root,dirs ,files in os.walk(m) :
                for f in files:
                    if f.endswith('.c') or f.endswith('.h'):
                        migrate_file(root+'/'+f)
        elif os.path.isfile(m):
            if m.endswith('.c') or m.endswith('.h'):
                migrate_file(m)




#ifndef AC_BUF_H_
#define AC_BUF_H_

/**
 * 网络的读写的BUFFER
 */
#include "ac_list.h"
#include <stdint.h>


#define AC_BUF_FILE        1
#define AC_BUF_CLOSE_FILE  3

typedef struct ac_buf_t ac_buf_t;
typedef struct ac_file_buf_t ac_file_buf_t;
typedef struct ac_buf_string_t ac_buf_string_t;
typedef void (ac_buf_cleanup_pt)(ac_buf_t *, void *);

#define AC_BUF_DEFINE             \
    ac_list_t         node;       \
    int                 flags;      \
    ac_buf_cleanup_pt *cleanup;   \
    void                *args;

struct ac_buf_t {
    AC_BUF_DEFINE;
    char                *start;
    char                *pos;
    char                *last;
    char                *end;
};

struct ac_file_buf_t {
    AC_BUF_DEFINE;
    int                 fd;
    int64_t             offset;
    int64_t             count;
};

struct ac_buf_string_t {
    char        *data;
    int         len;
};

extern ac_buf_t *ac_buf_create( uint32_t size);
extern void ac_buf_set_cleanup(ac_buf_t *b, ac_buf_cleanup_pt *cleanup, void *args);
extern void ac_buf_set_data( ac_buf_t *b, const void *data, uint32_t size);
extern ac_buf_t *ac_buf_pack( const void *data, uint32_t size);
extern ac_file_buf_t *ac_file_buf_create();
extern void ac_buf_destroy(ac_buf_t *b);
extern int ac_buf_check_read_space( ac_buf_t *b, uint32_t size);
extern ac_buf_t *ac_buf_check_write_space( ac_list_t *bc, uint32_t size);
extern void ac_file_buf_set_close(ac_file_buf_t *b);

extern void ac_buf_chain_clear(ac_list_t *l);
extern void ac_buf_chain_offer(ac_list_t *l, ac_buf_t *b);

///////////////////////////////////////////////////////////////////////////////////////////////////
// ac_buf_string

#define ac_buf_string_set(str, text) {(str)->len=strlen(text); (str)->data=(char*)text;}

static inline char *ac_buf_string_ptr(ac_buf_string_t *s)
{
    return s->data;
}

static inline void ac_buf_string_append(ac_buf_string_t *s,
        const char *value, int len)
{
    s->data = (char *)(value - s->len);
    s->len += len;
}

static inline int ac_buf_len(ac_buf_t *b)
{
    if (unlikely(b->flags & AC_BUF_FILE))
        return ((ac_file_buf_t *)b)->count;
    else
        return (b->last - b->pos);
}

extern int ac_buf_string_copy( ac_buf_string_t *d, ac_buf_string_t *s);
extern int ac_buf_string_printf(ac_buf_string_t *d, const char *fmt, ...);


#endif //AC_BUF_H_

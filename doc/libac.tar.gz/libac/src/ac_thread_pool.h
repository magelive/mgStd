#ifndef AC_THREAD_POOL_H
#define AC_THREAD_POOL_H


/**
 * base pthread线程池
 */


#include "ac_struct.h"

#define ac_thread_pool_for_each(th, tp, offset)                   \
    for((th) = (typeof(*(th))*)&(tp)->data[offset];                 \
            (char*)(th) < (tp)->last;                               \
            th = (typeof(*th)*)(((char*)th) + (tp)->member_size))

// 第n个
static inline void *ac_thread_pool_index(ac_thread_pool_t *tp, int n)
{
    if (n < 0 || n >= tp->thread_count)
        return NULL;

    return &tp->data[n * tp->member_size];
}

static inline void *ac_thread_pool_hash(ac_thread_pool_t *tp, uint64_t hv)
{
    hv %= tp->thread_count;
    return &tp->data[hv * tp->member_size];
}

static inline void *ac_thread_pool_rr(ac_thread_pool_t *tp, int start)
{
    int         n, t;

    if ((t = tp->thread_count - start) > 0) {
        n = tawstd_atomic32_add_return(&tp->last_number, 1);
        n %= t;
        n += start;
    } else {
        n = 0;
    }

    return &tp->data[n * tp->member_size];
}

void *ac_thread_on_start(void *args);
void ac_thread_on_wakeup(void *args);
void ac_thread_init(void *args, ac_thread_pool_t *tp,
                      ac_thread_on_start_pt *start, uv_async_cb wakeup);
void ac_thread_pool_on_wakeup(ac_thread_pool_t *tp);
ac_thread_pool_t *ac_thread_pool_create(ac_io_t *eio, int thread_count, int member_size);
void ac_thread_pool_destroy(ac_thread_pool_t *tp);
//void ac_thread_close_cb(uv_async_t* handle);
//void ac_thread_on_close(void *args);
//void ac_thread_pool_on_close(ac_thread_pool_t *tp);
void ac_thread_pool_wakeup_session(ac_baseth_t *th);

#endif//AC_THREAD_POOL_H

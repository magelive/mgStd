#ifndef AC_HASH_H_
#define AC_HASH_H_

/**
 * 固定HASH桶的hashtable, 需要在使用的对象上定义一个ac_hash_list_t
 */

#include <ngtawstd/mem.h>
#include <ngtawstd/zytypes.h>
#include "ac_list.h"

typedef struct ac_hash_t ac_hash_t;
typedef struct ac_hash_list_t ac_hash_list_t;
typedef int (ac_hash_cmp_pt)(const void *a, const void *b);

struct ac_hash_t {
    ac_hash_list_t    **buckets;
    uint32_t            size;
    uint32_t            mask;
    uint32_t            count;
    int                 offset;

    uint64_t            seqno;
    ac_list_t              list;
};

struct ac_hash_list_t {
    ac_hash_list_t    *next;
    ac_hash_list_t    **pprev;
    uint64_t            key;
};

#define ac_hash_for_each(i, node, table)                      \
    for(i=0; i<table->size; i++)                                \
        for(node = table->buckets[i]; node; node = node->next)

ac_hash_t *ac_hash_create(uint32_t size, int offset);
int ac_hash_add(ac_hash_t *table, uint64_t key, ac_hash_list_t *list);
void *ac_hash_find(ac_hash_t *table, uint64_t key);
void *ac_hash_find_ex(ac_hash_t *table, uint64_t key, ac_hash_cmp_pt cmp, const void *a);
void *ac_hash_del(ac_hash_t *table, uint64_t key);
int ac_hash_del_node(ac_hash_list_t *n);
uint64_t ac_hash_key(uint64_t key);
uint64_t ac_hash_code(const void *key, int len, unsigned int seed);

int ac_hash_dlist_add(ac_hash_t *table, uint64_t key, ac_hash_list_t *hash, ac_list_t *list);
void *ac_hash_dlist_del(ac_hash_t *table, uint64_t key);

void ac_hash_destroy(ac_hash_t *table);


#endif //AC_HASH_H_

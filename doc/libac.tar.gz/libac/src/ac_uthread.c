#include <ngtawstd/zytypes.h>
#include <ngtawstd/mem.h>

#include "ac_util.h"
#include "ac.h"
#include "ac_uthread.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


/**
 * 用户态线程
 */

__thread ac_uthread_control_t *ac_uthread_var = NULL;

ac_uthread_t *ac_uthread_alloc(ac_uthread_start_pt *fn, void *args, int stack_size);
void ac_uthread_start(uint32_t y, uint32_t x);
void ac_uthread_context_switch(ucontext_t *from, ucontext_t *to);

/**
 * 需要初始化一下
 */
void ac_uthread_init(ac_uthread_control_t *control)
{
    ac_debug_log("ac_uthread_init ac_uthread_var==ac_uthread_control_t=%p",control);
    if (ac_uthread_var == NULL) {
        ac_uthread_var = control;
        memset(ac_uthread_var, 0, sizeof(ac_uthread_control_t));
        ac_list_init(&ac_uthread_var->runqueue);
        ac_list_init(&ac_uthread_var->thread_list);
    }
}

/**
 * 释放掉所有资源
 */
void ac_uthread_destroy()
{
    ac_debug_log("ac_uthread_destroy ac_uthread_t");
    ac_uthread_t      *t, *t2;

    if (!ac_uthread_var)
        return;

    ac_list_for_each_entry_safe(t, t2, &ac_uthread_var->thread_list, thread_list_node) {
        taw_free(t);
    }

    ac_uthread_var = NULL;
}

/**
 * 停止运行
 */
void ac_uthread_stop()
{
    if (ac_uthread_var) {
        ac_uthread_var->stoped = 1;
    }
}

/**
 * 创建一用户态线程
 */
ac_uthread_t *ac_uthread_create(ac_uthread_start_pt *start_routine, void *args, int stack_size)
{
    ac_debug_log("ac_uthread_create start=%p",start_routine);
    ac_uthread_t      *t;

    if (!ac_uthread_var)
        return NULL;

    if ((t = ac_uthread_alloc(start_routine, args, stack_size)) == NULL)
        return NULL;

    ac_uthread_var->thread_count ++;
    ac_list_add_tail(&t->thread_list_node, &ac_uthread_var->thread_list);

    ac_uthread_ready(t);
    ac_debug_log("ac_uthread_create return ac_uthread_t=%p",t);
    return t;
}

/**
 * 退出线程数
 */
void ac_uthread_exit(int val)
{
    ac_debug_log("ac_uthread_exit exiting = 1");
    ac_uthread_var->exit_value = val;
    ac_uthread_var->running->exiting = 1;
    ac_uthread_switch();
}

/**
 * 切换给其他CPU
 */
void ac_uthread_switch()
{
    ac_uthread_var->running->errcode = 0;
    ac_uthread_needstack(0);
    ac_uthread_context_switch(&ac_uthread_var->running->context, &ac_uthread_var->context);
}

/**
 * 得到当前正常运行的ac_uthread_t
 */
ac_uthread_t *ac_uthread_current()
{
    return (ac_uthread_var ? ac_uthread_var->running : NULL);
}

/**
 * 得到errcode
 */
int ac_uthread_get_errcode()
{
    if (ac_uthread_var && ac_uthread_var->running)
        return ac_uthread_var->running->errcode;
    else
        return 0;
}
/**
 * 设置errcode
 */
void ac_uthread_set_errcode(ac_uthread_t *t, int errcode)
{
    t->errcode = (errcode & 0xff);
}

/**
 * stack检查.
 */
void ac_uthread_needstack(int n)
{
    ac_uthread_t      *t;

    t = ac_uthread_var->running;

    if((char *)&t <= (char *)t->stk || (char *)&t - (char *)t->stk < 256 + n) {
        fprintf(stderr, "uthread stack overflow: &t=%p tstk=%p n=%d\n", &t, t->stk, 256 + n);
        abort();
    }
}

/**
 * 准备就绪, 加入到运行队列中
 */
void ac_uthread_ready(ac_uthread_t *t)
{
    if (t) {
        t->ready = 1;
        ac_list_add_tail(&t->runqueue_node, &ac_uthread_var->runqueue);
    }
}

/**
 * 空闲,释放CPU
 */
int ac_uthread_yield()
{
    int         n;

    n = ac_uthread_var->nswitch;
    ac_uthread_ready(ac_uthread_var->running);
    ac_uthread_switch();
    return ac_uthread_var->nswitch - n - 1;
}

/**
 * 调度控制
 */
int ac_uthread_scheduler()
{
    ac_debug_log("ac_uthread_scheduler");
    ac_uthread_t      *t;

    while(ac_uthread_var->stoped == 0) {
        if(ac_uthread_var->thread_count == 0) {
            break;
        }

        if (ac_list_empty(&ac_uthread_var->runqueue)) {
            fprintf(stderr, "no runnable user thread! (%d)\n", ac_uthread_var->thread_count);
            ac_uthread_var->exit_value = 1;
            break;
        }

        // first entry
        t = ac_list_entry(ac_uthread_var->runqueue.next, ac_uthread_t, runqueue_node);
        ac_debug_log("ac_uthread_scheduler get runqueue t=%p",t);
        ac_list_del(&t->runqueue_node);

        t->ready = 0;
        ac_uthread_var->running = t;
        ac_uthread_var->nswitch ++;

        // 切换回去运行
        ac_uthread_context_switch(&ac_uthread_var->context, &t->context);
        ac_uthread_var->running = NULL;

        // 用户线程退出了
        if(t->exiting) {
            ac_debug_log("ac_uthread_scheduler t->exiting t=%p free t",t);
            ac_list_del(&t->thread_list_node);
            ac_uthread_var->thread_count --;
            taw_free(t);

        }
    }

    return ac_uthread_var->exit_value;
}

/**
 * 打印出uthread信息
 */
void ac_uthread_print(int sig)
{
    ac_uthread_t      *t;
    char                *extra;

    fprintf(stderr, "uthread list:\n");
    ac_list_for_each_entry(t, &ac_uthread_var->thread_list, thread_list_node) {
        if(t == ac_uthread_var->running)
            extra = " (running)";
        else if(t->ready)
            extra = " (ready)";
        else
            extra = "";

        fprintf(stderr, "%6d %s\n", t->id, extra);
    }
}
///////////////////////////////////////////////////////////////////////////////////////////////////
//分配一个ac_uthread_t t，设置context,设置线程函数ac_uthread_start
ac_uthread_t *ac_uthread_alloc(ac_uthread_start_pt *fn, void *args, int stack_size)
{
    ac_uthread_t      *t;
    int                 size;
    sigset_t            zero;
    uint32_t            x, y;
    uint64_t            z;

    // 创建一个pool
    size = sizeof(ac_uthread_t) + stack_size;


    if ((t = (ac_uthread_t *) taw_malloc("ac_uthread_t", size, 0)) == NULL)
        return NULL;;

    // 初始化
    memset(t, 0, sizeof(ac_uthread_t));

    t->stk = (unsigned char *) (t + 1);
    t->stksize = stack_size;
    t->id = ++ ac_uthread_var->gid;
    t->startfn = fn;
    t->startargs = args;

    /* do a reasonable initialization */
    memset(&t->context, 0, sizeof(t->context));
    sigemptyset(&zero);
    sigprocmask(SIG_BLOCK, &zero, &t->context.uc_sigmask);

    /* must initialize with current context */
    if(getcontext(&t->context) < 0)
        return NULL;;

    /* call makecontext to do the real work. */
    t->context.uc_stack.ss_sp = t->stk;
    t->context.uc_stack.ss_size = t->stksize;
    z = (unsigned long)t;
    y = (uint32_t)z;
    x = (uint32_t)(z >> 32);

    makecontext(&t->context, (void( *)())ac_uthread_start, 2, y, x);

    return t;
}

void ac_uthread_start(uint32_t y, uint32_t x)
{
    ac_debug_log("ac_uthread_start ");
    uint64_t z;

    z = x;
    z <<= 32;
    z |= y;
    ac_uthread_t *t = (ac_uthread_t *)(long)z;
    t->startfn(t->startargs);//处理事件
    ac_uthread_exit(0);
}

void ac_uthread_context_switch(ucontext_t *from, ucontext_t *to)
{
     ac_debug_log("ac_uthread_context_switch");
    if(swapcontext(from, to) < 0) {
        fprintf(stderr, "swapcontext failed.\n");
        abort();
    }
}

/**
 * 用户态线程(uthread)的io函数
 */
void ac_io_on_uthread_start(void *args)
{
    ac_io_thread_t *ioth = (ac_io_thread_t *)args;

    if (ioth->on_utstart) (ioth->on_utstart)(ioth->ut_args);
}
void ac_io_on_uthread_uvstart(void *args)
{
    uv_run((uv_loop_t *)args, 0);
}

/**
 * 设置用户态线程开始
 */
void ac_acio_set_uthread_start(ac_io_t *acio, ac_io_uthread_start_pt *on_utstart, void *args)
{
    ac_io_thread_t        *ioth;

    acio->uthread_enable = 1;
    ac_thread_pool_for_each(ioth, acio->io_thread_pool, 0) {
        ioth->on_utstart = on_utstart;
        ioth->ut_args = args;
    }
}


///////////////////////////////////////////////////////////////////////////////////////////////////
// uthread wait;
int ac_client_uthread_wait_conn(ac_connection_t *c)
{
    if (c->status == AC_CONN_OK)
        return AC_OK;

    if ((c->uthread = ac_uthread_current()) == NULL) {
        return AC_ERROR;
    } else {
        ac_uthread_switch();
        return ac_uthread_get_errcode();
    }
}

int ac_client_uthread_wait_session(ac_session_t *s)
{
    if ((s->thread_ptr = ac_uthread_current()) == NULL) {
        return AC_ERROR;
    } else {
        ac_uthread_switch();
        return ac_uthread_get_errcode();
    }
}

void ac_client_uthread_set_handler(ac_handler_pt *handler)
{
    handler->on_connect = ac_client_uthread_wakeup_conn;
    handler->on_disconnect = ac_client_uthread_wakeup_conn;
    handler->process = ac_client_uthread_wakeup_session;
    handler->is_uthread = 1;
}
// io_handler
int ac_client_uthread_wakeup_conn(ac_connection_t *c)
{
    if (c->uthread) {
        ac_uthread_ready(c->uthread);

        ac_uthread_set_errcode(c->uthread, (c->conn_has_error ? AC_ERROR : AC_OK));
        c->uthread = NULL;
    }

    return AC_OK;
}
int ac_client_uthread_wakeup_session(ac_request_t *r)
{
    ac_session_t *s;
    ac_uthread_t *uth;

    s = (ac_session_t *) r->ms;

    if (s->type != AC_TYPE_SESSION) {
        ac_fatal_log("session error, r->ms->type: %d\n", s->type);
        return AC_ERROR;
    }

    if (s->thread_ptr) {
        uth = (ac_uthread_t *)s->thread_ptr;
        ac_uthread_ready(uth);
        ac_uthread_set_errcode(uth, (s->c->conn_has_error ? AC_ERROR : AC_OK));
        s->thread_ptr = NULL;
    }

    return AC_OK;
}





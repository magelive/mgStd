#ifndef AC_STRUCT_H_
#define AC_STRUCT_H_

#include "ac_hash.h"
#include <sched.h>
#include "uv.h"
#include <ngtawstd/atomic.h>
#include "ac_buf.h"

/**
 * 主要的结构体和回调函数
 */

///////////////////////////////////////////////////////////////////////////////////////////////////
// define
#define AC_MAX_THREAD_CNT         64
#define AC_IOTH_DOING_REQ_CNT     500000 //8192
#define AC_CONN_DOING_REQ_CNT     500000 //1024
#define AC_MAX_CLIENT_CNT         500000 //65536
#define AC_IDLE_TIMEOUT           (60*1000) //ms

#define AC_EVENT_READ             1
#define AC_EVENT_WRITE            2
#define AC_EVENT_TIMEOUT          4

#define AC_TYPE_SERVER            0
#define AC_TYPE_CLIENT            1

#define AC_TYPE_MESSAGE           1
#define AC_TYPE_SESSION           2

#define AC_CONN_OK                0
#define AC_CONN_CONNECTING        1
#define AC_CONN_AUTO_CONN         2
#define AC_CONN_CLOSE             3

#define AC_MESG_READ_AGAIN        1
#define AC_MESG_WRITE_AGAIN       2
#define AC_MESG_DESTROY           3

#define AC_IOV_MAX                256
#define AC_IOV_SIZE               262144

#define AC_CLIENT_DEFAULT_TIMEOUT 5000

#define AC_FILE_READ              1
#define AC_FILE_WRITE             2
#define AC_FILE_SENDFILE          3
#define AC_FILE_WILLNEED          4

#define ac_align_ptr(p, a)        (uint8_t*)(((uintptr_t)(p) + ((uintptr_t) a - 1)) & ~((uintptr_t) a - 1))
#define ac_align(d, a)            (((d) + (a - 1)) & ~(a - 1))
#define ac_max(a,b)               (a > b ? a : b)
#define ac_min(a,b)               (a < b ? a : b)

#define AC_OK                     0
#define AC_ERROR                  (-1)
#define AC_ABORT                  (-2)
#define AC_ASYNC                  (-3)
#define AC_BREAK                  (-4)
#define AC_AGAIN                  (-EAGAIN)

#define AC_CONNECT_ADDR           1
#define AC_DISCONNECT_ADDR        2
#define AC_MIN_INTERVAL           0.1

#define AC_IPV4                   1
#define AC_IPV6                   2
#define AC_TCP                    4
#define AC_UDP                    8
#define AC_SOCKET_UN              16
#define AC_FD                     32

//#define AC_BUF_ZBF                0
//#define AC_BUF_FILE               1
//#define AC_BUF_CLOSE_FILE         2

#define AC_LISTEN_CONN            1024

#define AC_POOL_ALIGNMENT         512
#define AC_POOL_PAGE_SIZE         4096
#define AC_IO_BUFFER_SIZE         8192

#define ac_trylock(lock)  ((lock)->cnt== 0 && tawstd_atomic32_test_and_set(lock))
#define ac_unlock(lock)   {__asm__ ("" ::: "memory"); (lock)->cnt = 0;}
#define ac_spin_unlock ac_unlock



static __inline__ void ac_spin_lock(tawstd_atomic32_t *lock)
{
    int i, n;

    for ( ; ; ) {
        if (lock->cnt == 0 && tawstd_atomic32_test_and_set(lock)) {
            return;
        }

        for (n = 1; n < 1024; n <<= 1) {

            for (i = 0; i < n; i++) {
                __asm__ (".byte 0xf3, 0x90");//pause
            }

            if (lock->cnt == 0 && tawstd_atomic32_test_and_set(lock)) {
                return;
            }
        }

        sched_yield();
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// typedef
typedef struct _ac_addr_t {
    char     addr[128];  //IPV4,IPV6的IP地址或者unix socket的文件路径
    int      port;       //端口
    int      conn_flag; //连接的类型，AC_TCP,AC_UDP,AC_IPV4,AC_IPV6,AC_SOCKET_UN,AC_FD
} ac_addr_t;

//结构体重命名
typedef struct ac_message_t ac_message_t;
typedef struct ac_request_t ac_request_t;
typedef struct ac_connection_t ac_connection_t;
typedef struct ac_message_session_t ac_message_session_t;
typedef struct ac_session_t ac_session_t;
typedef struct ac_listen_t ac_listen_t;
typedef struct ac_client_t ac_client_t;
typedef struct ac_io_t ac_io_t;
typedef struct ac_baseth_t ac_baseth_t;
typedef struct ac_io_thread_t ac_io_thread_t;
typedef struct ac_request_thread_t ac_request_thread_t;
typedef struct ac_thread_pool_t ac_thread_pool_t;
typedef struct ac_client_wait_t ac_client_wait_t;
typedef struct ac_connection_list_t ac_connection_list_t;
typedef struct ac_io_stat_t ac_io_stat_t;
typedef struct ac_uthread_t ac_uthread_t;
typedef struct ac_uthread_control_t ac_uthread_control_t;


//函数声明
typedef void *(ac_thread_on_start_pt)(void *args);
typedef int (ac_io_process_pt)(ac_request_t *r);
typedef int (ac_io_cleanup_pt)(ac_request_t *r, void *apacket);
typedef int (ac_request_process_pt)(ac_request_t *r, void *args);
typedef void *(ac_baseth_on_start_pt)(void *args);
typedef void (ac_io_stat_process_pt)(ac_io_stat_t *iostat);
typedef void (ac_io_uthread_start_pt)(void *args);
typedef void (ac_uthread_start_pt)(void *args);

//回调函数集合
typedef struct _ac_handler_pt {
    void                            *(*decode)(ac_message_t *m);
    int                             (*encode)(ac_request_t *r, void *packet);
    ac_io_process_pt                *process;
    int                             (*batch_process)(ac_message_t *m);
    ac_io_cleanup_pt                *cleanup;
    uint64_t                        (*get_packet_id)(ac_connection_t *c, void *packet);
    int                             (*on_connect) (ac_connection_t *c);
    int                             (*on_disconnect) (ac_connection_t *c);
    int                             (*new_packet) (ac_connection_t *c);
    int                             (*on_idle) (ac_connection_t *c);
    void                            *user_data, *user_data2;
    int                              is_uthread;

}ac_handler_pt;

// base thread
struct ac_baseth_t {
    ac_thread_on_start_pt           *on_start;
    pthread_t                       tid;
    int                             idx, iot;
    uv_loop_t*                      loop;
    uv_async_t                      thread_watcher;
   // uv_async_t                      *close_watcher;
    tawstd_atomic32_t               thread_lock;
    uv_stream_t                     stream_watcher;
    ac_io_t*                        acio;
};

// 处理IO的线程
struct ac_io_thread_t {

    ac_thread_on_start_pt           *on_start;
    pthread_t                       tid;
    int                             idx, iot;
    uv_loop_t                       *loop;
    uv_async_t                      thread_watcher;

    tawstd_atomic32_t               thread_lock;
    uv_stream_t                     stream_watcher;
    ac_io_t                         *acio;

    // queue
    ac_list_t                       conn_list;
    ac_list_t                       session_list;
    ac_list_t                       request_list;

    // listen watcher
    uv_async_t                      listen_watcher;

    //user thread
    ac_io_uthread_start_pt          *on_utstart;
    void                            *ut_args;

    // client list
     ac_hash_t                      *client_list;
     ac_list_t                      client_array;

    // connected list
    ac_list_t                       connected_list;
    tawstd_atomic32_t               doing_request_count;
    uint64_t                        done_request_count;
};

// worker长任务线程
struct ac_request_thread_t {
    ac_thread_on_start_pt           *on_start;
    pthread_t                       tid;
    int                             idx, iot;
    uv_loop_t                       *loop;
    uv_async_t                      thread_watcher;
   // uv_async_t                      *close_watcher;
    tawstd_atomic32_t               thread_lock;
    uv_stream_t                     stream_watcher;
    ac_io_t                         *acio;

    // queue
    int                             task_list_count;
    ac_list_t                       task_list;
    ac_list_t                       session_list;

    ac_request_process_pt           *process;
    void                            *args;
};


// 保存client
struct ac_client_t {
    ac_list_t                       ac_client_node;
    ac_addr_t                       addr;
    ac_connection_t                 *c;
    ac_handler_pt                   *handler;
    int                             timeout, ref;
    ac_hash_list_t                  client_list_node;
    void                            *user_data;
};

// 对应一个SOCKET连接
struct ac_connection_t {

    ac_io_thread_t                  *ioth;
    uv_loop_t                       *loop;
    ac_connection_t                 *next;
    ac_list_t                       conn_list_node;
    struct sockaddr                 *addr_udp;
    // file description
    uint32_t                        default_message_len;
    int                             reconn_time, reconn_fail;
    int                             idle_time;
    ac_addr_t                       addr;
    uv_handle_t                     *io_stream;
    uv_async_t                      write_watcher;
    uv_timer_t                      timeout_watcher;
    ac_list_t                       message_list;

    ac_list_t                       output;
    ac_handler_pt                   *handler;
    ac_client_t                     *client;
    ac_list_t                       session_list;//里面保存的是request
    ac_hash_t                       *send_queue;
    void                            *user_data;

    uint32_t                        status : 4;
    uint32_t                        event_status : 4;
    uint32_t                        type : 1;
    uint32_t                        async_conn : 1;
    uint32_t                        conn_has_error : 1;
    uint32_t                        tcp_cork_flag : 1;
    uint32_t                        tcp_nodelay_flag : 1;
    uint32_t                        wait_close : 1;
    uint32_t                        need_redispatch : 1;
    uint32_t                        read_eof : 1;
    uint32_t                        auto_reconn : 1;

    uint32_t                        doing_request_count;
    uint64_t                        done_request_count;
    uint64_t                        start_time, sw_time, last_time;

    ac_uthread_t                    *uthread;   //user thread
    char                            addr_udp_data[0];
};

//IO线程池
struct ac_thread_pool_t {
    int                             thread_count;
    int                             member_size;
    tawstd_atomic32_t               last_number;
    ac_list_t                       list_node;
    ac_thread_pool_t                *next;
    char                            *last;
    char                            data[0];
};

// 用于统计处理速度
struct ac_io_stat_t {
    int64_t                         last_cnt;
    uint64_t                        last_time;
    double                          last_speed;
    double                          total_speed;
    ac_io_stat_process_pt           *process;
    ac_io_t                         *acio;
};

//buffer
//struct ac_buffer_t {
//    int                             flags;
 //   ac_list_t                       list_node;
 //   ZYBuffer                        *zbf;
//};

//send file
//struct ac_file_buffer_t {
//    int                             flags;
 //   ac_list_t                       list_node;
 //   int                             fd;
 //   int64_t                         offset;
 //   int64_t                         count;
//};

// ipacket放进来的包, opacket出去的包
struct ac_request_t {
    ac_message_session_t            *ms;
    ac_list_t                       request_list_node;
    int                             retcode;
    void                            *ipacket;
    void                            *opacket;
    void                            *args;
};

#define AC_MESSAGE_SESSION_HEADER \
    ac_connection_t                 *c; \
    uint8_t                         type:4; \
    uint8_t                         async:4; \
    int8_t                          status;


struct ac_message_session_t {
    AC_MESSAGE_SESSION_HEADER
};

// 用于接收, 一个或多个ac_request_t
struct ac_message_t {
    AC_MESSAGE_SESSION_HEADER
    uint16_t                        recycle_cnt;
    ac_buf_t                        *input;
    ac_list_t                       message_list_node;
    ac_list_t                       request_list;
    ac_list_t                       request_done_list;
    int                             request_list_count;
    int                             next_read_len;
    int                             max_read_len;
    void                            *user_data;
};

// 用于发送, 只带一个ac_request_t
struct ac_session_t {
    AC_MESSAGE_SESSION_HEADER;
    int16_t                         error;
    int                             timeout;
    uv_timer_t                      timeout_watcher;

    ac_list_t                       session_list_node;
    ac_hash_list_t                  send_queue_hash;
    ac_list_t                       send_queue_list;
    ac_io_process_pt                *process; //在process中不能销毁ac_session_t
    ac_io_process_pt                *waithandler;
    ac_io_cleanup_pt                *cleanup;
    ac_addr_t                       addr;
    ac_list_t                       *nextb;//buffer 链表。

    uint64_t                        packet_id;
    void                            *thread_ptr;
    ac_request_t                    r;
    char                            data[0];
};

// 监听列表
struct ac_listen_t {

    int                             fd;
    int8_t                          cur, old;
    ac_addr_t                       addr;
    ac_handler_pt                   *handler;

    tawstd_atomic32_t               listen_lock;
    ac_io_thread_t                  *curr_ioth;
    ac_io_thread_t                  *old_ioth;

    ac_listen_t                     *next;
    uv_udp_t                        *udp_server;
    uv_stream_t                     *listen_watcher;
    char                            listen_watcher_data[0];
};

struct ac_client_wait_t {
    int                             done_count;
    uv_mutex_t                      mutex;
    uv_cond_t                       cond;
    ac_list_t                       session_list;
    ac_list_t                       next_list;
};

struct ac_connection_list_t {
    ac_connection_t                 *head;
    ac_connection_t                 *tail;
};

// ac_io对象
struct ac_io_t {
    ac_list_t                        acio_list_node;
    tawstd_atomic32_t                lock;

    ac_listen_t                      *listen;
    int                              io_thread_count;
    ac_thread_pool_t                 *io_thread_pool;
    ac_thread_pool_t                 *thread_pool;
    void                             *user_data;
    ac_list_t                        thread_pool_list;

    // flags
    uint32_t                         stoped : 1;
    uint32_t                         started : 1;
    uint32_t                         tcp_cork : 1;
    uint32_t                         tcp_nodelay : 1;
    uint32_t                         listen_all : 1;
    uint32_t                         uthread_enable : 1;
    uint32_t                         affinity_enable : 1;
    uint32_t                         no_redispatch : 1;

    uint64_t                         start_time;
    tawstd_atomic64_t                send_byte;
    tawstd_atomic64_t                recv_byte;
    tawstd_atomic32_t                connect_num;
};


struct ac_uthread_t {
    ac_list_t                runqueue_node;
    ac_list_t                thread_list_node;

    ac_uthread_start_pt      *startfn;
    void                       *startargs;

    uint32_t                   id;
    int8_t                     exiting;
    int8_t                     ready;
    int8_t                     errcode;
    uint32_t                   stksize;
    unsigned char              *stk;
    ucontext_t                 context;
};

struct ac_uthread_control_t {
    int                        gid;
    int                        nswitch;
    int16_t                    stoped;
    int16_t                    thread_count;
    int                        exit_value;
    ac_list_t                runqueue;
    ac_list_t                thread_list;
    ac_uthread_t             *running;
    ucontext_t                 context;
};
#endif /* AC_STRUCT_H_ */

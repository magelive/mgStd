#include <ngtawstd/zytypes.h>
#include <ngtawstd/mem.h>

#include "ac_util.h"
#include "ac.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <netinet/in.h>
#include <sys/un.h>
#include <sys/sendfile.h>
#include <asm/ioctls.h>
#include "ac_uthread.h"


//把io_thread_t释放掉
void ac_io_thread_destroy(ac_io_thread_t *ioth)
{
    ac_connection_t       *c, *c1;
    ac_session_t          *s, *s1;
    ac_client_t          *client,*client1;

    // session at ioth
    ac_spin_lock(&ioth->thread_lock);
    ac_list_for_each_entry_safe(s, s1, &ioth->session_list, session_list_node) {
        ac_list_del(&s->session_list_node);
    }
    // connection at ioth
    ac_list_for_each_entry_safe(c, c1, &ioth->conn_list, conn_list_node) {
        ac_debug_log("ac_connection_disconnect ac_io_thread_destroy ");
        ac_connection_destroy(c);
    }
    // foreach connected_list
    ac_list_for_each_entry_safe(c, c1, &ioth->connected_list, conn_list_node) {
        ac_debug_log("ac_connection_disconnect ac_io_thread_destroy ");
        ac_connection_destroy(c);
    }

    ac_list_for_each_entry_safe(client, client1, &c->conn_list_node, ac_client_node) {
        ac_debug_log("free client\n");
        taw_free(client);
    }

    ac_hash_destroy(ioth->client_list);

    ac_spin_unlock(&ioth->thread_lock);

}

//uv读数据的分配函数
void ac_malloc_cb(uv_handle_t* handle,
                            size_t suggested_size,
                            uv_buf_t* buf)
{
    void* p = taw_malloc("uv_buf_t.base",suggested_size,0);
    if(!p){
        buf->base = NULL;
        buf->len = 0;
        return;
    }
    buf->base = p;
    buf->len = suggested_size;
}

//创建一个message
ac_message_t *ac_message_create(ac_connection_t *c)
{

    ac_message_t         *m;
    ac_buf_t            *input;


    // 新建一个message
    m = (ac_message_t *)taw_malloc("ac_message_t", sizeof(ac_message_t),0);
    ac_debug_log("ac_message_create %p\n",m);
    memset(m,0,sizeof(ac_message_t));

    input = ac_buf_create(AC_POOL_ALIGNMENT);

    if (m == NULL || input == NULL) {
        return NULL;
    }

    m->c = c;
    m->next_read_len = 0;
    m->max_read_len = 0;
    m->input = input;
    m->type = AC_TYPE_MESSAGE;
    m->request_list_count = 0;
    m->recycle_cnt = 0;
    ac_list_init(&m->request_list);
    ac_list_init(&m->request_done_list);
    ac_list_add_tail(&m->message_list_node, &c->message_list);

    return m;
}
/**
 * destroy掉ac_message_t对象
 */
void ac_message_destroy(ac_message_t *m, int del)
{
    ac_debug_log("ac_message_destroy %p\n",m);
    ac_request_t  *r, *n;

    // delete from message_list
    if (del) {
        m->status = AC_MESG_DESTROY;
        ac_list_del(&m->message_list_node);

    }

    // server done
    if((&m->request_list)->next==NULL)
        (&m->request_list)->next = &m->request_list;
    ac_list_for_each_entry_safe(r, n, &m->request_list, request_list_node) {
            ac_list_del(&r->request_list_node);
            ac_request_server_done(r);
    }
    if((&m->request_done_list)->next==NULL)
        (&m->request_done_list)->next = &m->request_done_list;
    ac_list_for_each_entry_safe(r, n, &m->request_done_list, request_list_node) {
            ac_list_del(&r->request_list_node);
            ac_request_server_done(r);
    }

    ac_list_del(&m->message_list_node);

    if (del) {
        if (m->input){
            ac_buf_destroy(m->input);
        }

        taw_free(m);
    }

}

ac_connection_t *ac_connection_connect_thread(char* addr,
        ac_handler_pt *handler, int conn_timeout, void *args, int autoconn)
{

    ac_session_t s;
    memset(&s, 0, sizeof(ac_session_t));
    ac_addr_parse(addr, &s.addr);
    s.status = AC_CONNECT_ADDR;
    s.process = (ac_io_process_pt *)handler;
    s.timeout = conn_timeout;
    s.r.args = args;
    s.packet_id = autoconn;
    return ac_connection_do_client(&s);
}

/**
 * IO线程启动函数
 */
void *ac_io_on_thread_start(void *args)
{
    ac_listen_t           *l;
    ac_io_thread_t        *ioth;
    ac_io_t               *acio;
    ac_uthread_control_t  control;

    ioth = (ac_io_thread_t *) args;
    ac_baseth_self = (ac_baseth_t *) args;
    acio = ioth->acio;
    ac_info_log("ac_io_on_thread_start.\n");

    // 线程CPU亲和性
    if (acio->affinity_enable) {
        int cpunum = sysconf(_SC_NPROCESSORS_CONF);
        int st, cpuid;
        cpu_set_t mask;

        st = (cpunum <= acio->io_thread_count) ? 1 : (cpunum / acio->io_thread_count);
        cpuid = (uint32_t)(cpunum - 1 - ioth->idx * st) % cpunum;
        CPU_ZERO(&mask);
        CPU_SET(cpuid, &mask);

        if (sched_setaffinity(0, sizeof(mask), &mask) == -1) {
            ac_error_log("sched_setaffinity failure .\n");
        }
    }

    // 有listen
    if (acio->listen) {
        // 监听所有，直接开始读，或者UDP, 暂不支持listen_all
        ac_debug_log("listen_all=%d,io_thread_count=%d",acio->listen_all,acio->io_thread_count);
      //  if (acio->listen_all || (acio->listen->addr.conn_flag&AC_UDP) == AC_UDP) {
        if((acio->listen->addr.conn_flag&AC_UDP) == AC_UDP) {
            for (l = acio->listen; l; l = l->next){
                ac_connection_on_accept_udp(l);
            }


        } else {//只有一个线程抢监听
            ac_debug_log("listen seize.\n");
            uv_async_send(&ioth->listen_watcher);//切换listen,回调ac_listen_change_cb
        }
    }

    ac_debug_log("uv_run\n");
        // 允许使用用户线程
    if (acio->uthread_enable) {
        //uv_set_invoke_pending_cb(ioth->loop, ac_io_uthread_invoke);
        ac_uthread_init(&control);
        ac_uthread_create(ac_io_on_uthread_uvstart, ioth->loop, 256 * 1024);//启动uv_loop

        if (ioth->on_utstart) {
            ac_uthread_create(ac_io_on_uthread_start, ioth, AC_UTHREAD_STACK);//设置uthread 启动函数，需要用户实现。
            ac_thread_on_wakeup(ioth);
        }

        ac_uthread_scheduler();
        ac_uthread_destroy();
    } else {
        uv_run(ioth->loop, 0);
    }


    ac_baseth_self = NULL;

    ac_debug_log("pthread exit: %lx\n", pthread_self());

    return (void *)NULL;
}

//异步listen切换回调函数
void ac_listen_change_cb(uv_async_t* handle){
    ac_debug_log("ac_listen_change_cb\n");
    ac_listen_t               *l;
    ac_io_thread_t            *ioth;
    ioth = (ac_io_thread_t *) handle->data;

    for (l = ioth->acio->listen; l; l = l->next) {

        if (ac_trylock(&l->listen_lock)) {

            if (l->old_ioth == ioth) {
                 /**触发自己抢listen*/
                l->old_ioth = NULL;
                l->curr_ioth = ioth;
            } else if(l->old_ioth==NULL){
                /**轮流切换listen*/
                  l->cur = ioth->idx;
                   ac_debug_log("get listen l->curr_ioth=%p,ioth=%p\n", l->curr_ioth,ioth);
                  uv_stream_t *server;
                  if ((l->addr.conn_flag&AC_TCP)==AC_TCP){
                      server = (uv_stream_t *)(l->listen_watcher_data + ioth->idx * sizeof(uv_tcp_t));
                      ac_debug_log("ac listen change TCP l=%p,server=%p,server->l=%p\n",l,server,server->data);
                  }
                  else{
                      server = (uv_stream_t *)(l->listen_watcher_data + ioth->idx * sizeof(uv_pipe_t));
                      ac_debug_log("ac listen change PIPE l=%p,server=%p,server->l=%p\n",l,server,server->data);
                  }


                  uv_listen_ex(server, AC_LISTEN_CONN, ac_connection_on_accept_cb);
                  l->curr_ioth = ioth;

            }

        }
    }
    IF_UTHREAD_YIELD

}

void ac_connection_add_list(ac_connection_list_t *wlist, ac_connection_t *c)
{

    if (c->next == NULL) {
        if (wlist->head == NULL)
            wlist->head = c;
        else
            wlist->tail->next = c;

        wlist->tail = c;
        c->next = c;
    }
}


//server 线程触发监听
void ac_connection_on_accept_cb(uv_stream_t *server, int status)
{
    if (status == -1) {
        IF_UTHREAD_YIELD
        return;
    }

    ac_listen_t           *listen;
    uv_tcp_t              *tcpServer;
    uv_pipe_t             *pipeServer;
    int                   ret;

    listen = (ac_listen_t *) server->data;

    if((listen->addr.conn_flag&AC_TCP)==AC_TCP ){

         if ((tcpServer = (uv_tcp_t *) taw_malloc("uv_tcp_t", sizeof(uv_tcp_t), 0)) == NULL) {
            ac_error_log("taw_malloc failure: uv_tcp_t size=%d\n",sizeof(uv_tcp_t));
            IF_UTHREAD_YIELD
            return ;
        }

        ret = uv_tcp_init(ac_thread_self->loop, tcpServer);
        if (ret) {
            ac_error_log("Server tcp init error\n");
            IF_UTHREAD_YIELD
            return ;
        }
        uv_accept(server, (uv_stream_t*)tcpServer);

        ac_connection_server_new_connect((uv_handle_t*)tcpServer,listen);
    }
    else if((listen->addr.conn_flag&AC_SOCKET_UN)==AC_SOCKET_UN){
        if ((pipeServer = (uv_pipe_t *) taw_malloc("uv_pipe_t", sizeof(uv_pipe_t), 0)) == NULL) {
            ac_error_log("taw_malloc failure: uv_pipe_t size=%d\n",sizeof(uv_pipe_t));
            IF_UTHREAD_YIELD
            return ;
        }

        ret = uv_pipe_init(ac_thread_self->loop, pipeServer, 1);
        if (ret) {
            ac_error_log("uv_pipe_init: %s\n", uv_strerror(ret));
            IF_UTHREAD_YIELD
            return ;
        }

        uv_accept(server, (uv_stream_t*)pipeServer);

       ac_connection_server_new_connect((uv_handle_t*)pipeServer,listen);

   }

    IF_UTHREAD_YIELD
}


//udp 线程server开始读写
void ac_connection_on_accept_udp(ac_listen_t * listen)
{
    /*
    uv_udp_t              *udpServer;
    int                   ret;


    struct sockaddr       *addr_base;
    int  bind_flag = 0;
    if((listen->addr.conn_flag&AC_IPV6)==AC_IPV6){
            struct sockaddr_in6 addr6;
            uv_ip6_addr(listen->addr.addr, listen->addr.port, &addr6);
            addr_base = (struct sockaddr*)&addr6;
            bind_flag = 1;//UV_UDP_IPV6ONLY
    }
    else if((listen->addr.conn_flag&AC_IPV4)==AC_IPV4){
            ac_debug_log("AC_IPV4\n");
            struct sockaddr_in addr4;
            uv_ip4_addr(listen->addr.addr, listen->addr.port, &addr4);
            addr_base = (struct sockaddr*)&addr4;
    }
    if ((udpServer = (uv_udp_t *) taw_malloc("uv_udp_t", sizeof(uv_udp_t), 0)) == NULL) {
            ac_error_log("taw_malloc failure: uv_udp_t size=%d\n",sizeof(uv_udp_t));
            return ;
    }

    ret = uv_udp_init(ac_thread_self->loop, udpServer);
    if (ret) {
            ac_error_log("uv_udp_init: %s\n", uv_strerror(ret));
            return ;
    }

    ret = uv_udp_bind(udpServer, addr_base, bind_flag);
    if (ret) {
            ac_error_log("Bind error\n");
            return ;
    }

   // ret = uv_udp_open(udpServer, listen->fd);
   // if (ret) {
    //        ac_error_log("uv_udp_open: %s\n", uv_strerror(ret));
   //         return ;
   // }
    */
    ac_connection_server_new_connect((uv_handle_t*)listen->udp_server,listen);

}


//serve端生成connection对象
int ac_connection_server_new_connect(uv_handle_t *stream, ac_listen_t *listen){

    ac_connection_t       *c;
    ac_io_thread_t        *ioth;
    int                   ret;

        // 为新连接创建一个ac_connection_t对象
    if ((c = ac_connection_new(listen->addr.conn_flag)) == NULL) {
        ac_error_log("ac_connection_new error\n");
        return AC_ERROR;
    }

    //TCP和PIPE需要accept
    /**aceept tcp unix 的地址给c ，fd给c->fd*/

    strcpy(c->addr.addr,listen->addr.addr);
    c->addr.conn_flag = listen->addr.conn_flag;
    c->addr.port= listen->addr.port;

   // 初始化
    ioth = ac_thread_self;
    c->io_stream = stream;
    c->io_stream->data = c;
    c->ioth = ioth;
    c->loop = c->ioth->loop;
    c->sw_time = uv_now(c->loop);
    c->type = AC_TYPE_SERVER;
    c->handler = listen->handler;//回调函数
    c->send_queue=NULL;


    // 事件初始化

    uv_async_init(c->loop,&c->write_watcher, ac_connection_on_writable);
    uv_timer_init(c->loop,&c->timeout_watcher);

    //c->read_watcher.data = c;
    c->write_watcher.data = c;
    c->timeout_watcher.data = c;

    c->io_stream->loop = c->loop;
    c->start_time = uv_now(c->loop);

    ac_debug_log("server create addr=%s c=%p\n",c->addr.addr, c);

    // on connect
    if (c->handler->on_connect)
        (c->handler->on_connect)(c);

    // start idle
    if (c->handler->on_idle) {

        uint64_t t = ac_max(1000, c->idle_time); //最低也要1秒
        uv_timer_set_repeat(&c->timeout_watcher, t);
        ac_debug_log("server C on_dile timeout=%d",t);
        c->timeout_watcher.timer_cb = ac_connection_on_timeout_conn;
        uv_timer_again(&c->timeout_watcher);
    }

    //选择一个不是自己的线程序号
    int th_idx;
    do{
        tawstd_atomic32_add(&ioth->acio->connect_num, 1);
        th_idx = (ioth->acio->connect_num.cnt) % (ioth->acio->io_thread_count);
        th_idx = th_idx<0 ? (0-th_idx) : th_idx;
    }
    while(ioth->acio->io_thread_count != 1
          && ioth == ac_thread_pool_index(ioth->acio->io_thread_pool,th_idx));


    // 让出来给其他的线程，UDP下不用切换listen

    if (ioth->acio->listen_all == 0 && listen->old_ioth == NULL
            && listen->curr_ioth == ioth
            && (listen->addr.conn_flag&AC_UDP)!=AC_UDP
            && ioth->acio->io_thread_count != 1) {

        ac_io_thread_t *nextth;
        listen->old = listen->cur;
        listen->curr_ioth = NULL;


        listen->old_ioth = NULL;
        nextth = ac_thread_pool_index(ioth->acio->io_thread_pool,th_idx);
        ac_debug_log("ioth=%p nextth=%p",ioth,nextth);
        ac_unlock(&listen->listen_lock);

        ac_debug_log("uv_async_send(&nextth->listen_watcher);/listen change_cb");
        uv_async_send(&nextth->listen_watcher);//启动切换listen

    }

    // start read
    ac_list_add_tail(&c->conn_list_node, &c->ioth->connected_list);
    c->event_status = AC_EVENT_READ;
    ac_debug_log("uv_read_start\n");
    if((c->addr.conn_flag&AC_UDP) != AC_UDP)
        uv_read_start((uv_stream_t*)c->io_stream, ac_malloc_cb, ac_read_cb);
    else{
        ac_debug_log("udpServer->io_watcher.fd=%d",((uv_udp_t*)c->io_stream)->io_watcher.fd);
        ret = uv_udp_recv_start((uv_udp_t*)c->io_stream, ac_malloc_cb, ac_recv_cb);
        if (ret)
            ac_error_log("uv_udp_recv_start: %s\n", uv_strerror(ret));

    }
    return AC_OK;
}


void ac_recv_cb(uv_udp_t* handle,ssize_t nread,const uv_buf_t* buf,
                    const struct sockaddr* addr,unsigned flags)
{
    //addr是发送者的地址,有可能为空，只在本函数内有效。flags是发送类型，一般为0，IPV6_ONLY=1,

    ac_connection_t *c = (ac_connection_t *) handle->data;

    //复制一份
    if(addr && c->addr_udp){
        if((c->addr.conn_flag&AC_IPV4)==AC_IPV4){
                memcpy(c->addr_udp,addr,sizeof(struct sockaddr_in));
             ac_debug_log("ac_recv_cb c=%p addr:%s,port:%d",c,
                          inet_ntoa(((struct sockaddr_in*)c->addr_udp)->sin_addr),
                          ((struct sockaddr_in*)c->addr_udp)->sin_port);
        }
        else if((c->addr.conn_flag&AC_IPV6)==AC_IPV6){
                memcpy(c->addr_udp,addr,sizeof(struct sockaddr_in6));
        }

    }

    ac_read_cb((uv_stream_t*)handle, nread, buf);

}


//io线程异步唤醒回调函数
void ac_connect_wakeup_cb(uv_async_t* handle)
{

    ac_io_thread_t    *ioth = (ac_io_thread_t*)handle->data;
    if (ioth->acio->stoped) {
        ac_debug_log("close thread th=%p acio=%p\n", ioth,ioth->acio);
        ac_thread_pool_wakeup_session((ac_baseth_t*)ioth);
        uv_close((uv_handle_t*)&ioth->thread_watcher,NULL);
        uv_close((uv_handle_t*)&ioth->listen_watcher, NULL);
        uv_stop(ioth->loop);
        ac_debug_log("uv_stop: acio=%p\n", ioth->acio);
        if (ioth->acio->uthread_enable)
               ac_uthread_stop();

        return;
    }

    ac_debug_log("ac_connect_wakeup_cb loop %p\n",ac_thread_self->loop);
    ac_connection_t   *c;
    ac_list_t         conn_list;
    ac_list_t         session_list;
    ac_list_t         request_list;

    // 取回list
    ac_spin_lock(&ioth->thread_lock);
    ac_list_movelist(&ioth->conn_list, &conn_list);
    ac_list_movelist(&ioth->session_list, &session_list);
    ac_list_movelist(&ioth->request_list, &request_list);
    ac_spin_unlock(&ioth->thread_lock);

    // foreach
    ac_list_for_each_entry(c, &conn_list, conn_list_node) {
        c->loop = ioth->loop;
        c->start_time = uv_now(ioth->loop);
        ac_connection_uv_start(c);
    }
    ac_list_join(&conn_list, &ioth->connected_list);

    ac_connection_send_session_list(&session_list);
    ac_connection_send_response(&request_list);

    IF_UTHREAD_YIELD
}

//发送回复内容response
int ac_connection_send_response(ac_list_t *request_list)
{
    ac_debug_log("ac_connection_send_response");
    ac_request_t              *r, *rn;
    ac_message_t              *m;
    ac_connection_t           *c, *nc;
    ac_connection_list_t      wlist = {NULL, NULL};//将发送的链表
    ac_connection_list_t      flist = {NULL, NULL};//出错的链表
    int                       ret;
    int                       cnt_test=0;

    // encode
    ac_list_for_each_entry_safe(r, rn, request_list, request_list_node) {

        ac_list_del(&r->request_list_node);
        m = (ac_message_t *) r->ms;
        c = m->c;

        // 从其他进程返回后
        ret = AC_ERROR;

        if (r->retcode != AC_ERROR) {
             //把r->opacket 加入到connect->output
            if ((ret = ac_connection_request_done(r)) == AC_OK) {
                ac_connection_add_list(&wlist, c);
                cnt_test++;
            }
        } else { // 如果出错
            ac_connection_add_list(&flist, c);
        }

        // message是否也不在使用了
        if (m->request_list_count == 0 && ret == AC_OK && m->status != AC_MESG_READ_AGAIN)
            ac_message_destroy(m, 1);
    }

    // failure request, close connection
    if (flist.tail) {
        flist.tail->next = NULL;
        nc = flist.head;

        while((c = nc)) {
            nc = c->next;
            c->next = NULL;
            ac_debug_log("ac_connection_disconnect send response c = nc ");
            ac_connection_destroy(c);
        }
    }
    // foreach write socket
    if (wlist.tail) {
        wlist.tail->next = NULL;
        nc = wlist.head;

        while((c = nc)) {
            nc = c->next;

            c->next = NULL;
            if (ac_connection_write_socket(c) == AC_ABORT) {
                ac_debug_log("ac_connection_disconnect send response c = nc  ac_connection_write_socket==AC_ABORT");
                ac_connection_destroy(c);
            } else if (c->type == AC_TYPE_SERVER) {
                ac_connection_redispatch_thread(c);
            }
        }
    }

    return AC_OK;
}

//读事件回调函数
void ac_read_cb(uv_stream_t* stream,ssize_t nread,const uv_buf_t* buf)
{
    ac_connection_t   *c;
    ac_message_t      *m;

    c = (ac_connection_t *)stream->data;

    if(nread>0){

        // 防止请求过多
        if (c->type == AC_TYPE_SERVER && (c->doing_request_count > AC_CONN_DOING_REQ_CNT ||
                                            c->ioth->doing_request_count.cnt > AC_IOTH_DOING_REQ_CNT)) {
            //这里有时候会出错，doing_request_count异常，导致c析构，段错误。
            ac_warn_log("c=%p c->doing_request_count: %d, c->ioth->doing_request_count: %d\n",c,
                          c->doing_request_count, c->ioth->doing_request_count.cnt);
            goto error_exit;
        }

        // 最后的请求, 如果数据没完, 需要继续读
        m = ac_list_get_last(&c->message_list, ac_message_t, message_list_node);

        // 第一次读或者上次读完整了, 重新建一个ac_message_t
        if (m == NULL || m->status != AC_MESG_READ_AGAIN) {
            if ((m = ac_message_create(c)) == NULL) {
                ac_debug_log("ac_message_create failure, c=%p\n", c);
                goto error_exit;
            }
        }

        // 把数据存入message
        //数据重新拷贝一份

           // 检查buffer大小
        if (ac_buf_check_read_space( m->input,nread) != AC_OK) {
            ac_error_log("ac_buf_check_read_space failure, m=%p, len=%d\n", m, nread);
            goto error_exit;
        }

        memcpy(m->input->last,buf->base,nread);//接着上次的数据写入

        ac_debug_log("ac_read_cb read =%d ==>%s",nread,buf->base);
        //c->read_eof = (nread< m->next_read_len);
        c->last_time = uv_now(c->loop);
        c->reconn_fail = 0;

        tawstd_atomic64_add(&ac_thread_self->acio->recv_byte, nread);
        m->input->last += nread;

        if (c->default_message_len < AC_IO_BUFFER_SIZE )//&& m->next_read_len == nread)
            c->default_message_len = AC_IO_BUFFER_SIZE;

        // client

        if (AC_ERROR == ((c->type == AC_TYPE_CLIENT) ?
                           ac_connection_do_response(m) : ac_connection_do_request(m))) {
            goto error_exit;
        }

    }
    else if((c->addr.conn_flag&AC_UDP)!=AC_UDP)
    {
        //这里不uv_close,多Client重复连接会uv报错。
       // uv_close((uv_handle_t*)c->io_stream, NULL);
       //udp由于只有一个io线程，接受各个client数据，不能结束读

        ac_debug_log("read EOF, stop reading\n");
        uv_read_stop((uv_stream_t*)c->io_stream);
        goto error_exit;

    }
    taw_free(buf->base);
    IF_UTHREAD_YIELD
    return;

error_exit:
    taw_free(buf->base);
    ac_debug_log("ac_connection_disconnect send response read_cb");
    ac_connection_destroy(c);
    IF_UTHREAD_YIELD
}

//客户端处理相应
int ac_connection_do_response(ac_message_t *m)
{
    ac_debug_log("ac_connection_do_response\n");
    ac_connection_t       *c;
    ac_session_t          *s;
    uint64_t                packet_id;
    int                     i, cnt, left;
    void                    *packet;
    ac_list_t             list;

    c = m->c;

    // 处理buf
    cnt = 0;
    left = 0;
    ac_list_init(&list);

    while (m->input->pos < m->input->last) {
        if ((packet = (c->handler->decode)(m)) == NULL) {
            if (m->status != AC_ERROR)
                break;

            return AC_ERROR;
        }

        cnt ++;
        packet_id = ac_connection_get_packet_id(c, packet, 1);
        s = (ac_session_t *) ac_hash_dlist_del(c->send_queue, packet_id);

        if (s == NULL) {
            // 需要cleanup
            if (c->handler->cleanup)
                (c->handler->cleanup)(NULL, packet);

            ac_warn_log("not found session, c=%p, packet_id=%ld\n", c, packet_id);
            continue;
        }

        // process
        ac_thread_self->done_request_count ++;
        s->r.ipacket = packet;              // in

        if (s->async) {
            m->async = s->async;
            //ac_atomic_inc(&m->pool->ref);
            //message 直接在本函数中释放，decode中将数据复制到r->ipacket中。
            s->r.request_list_node.next = NULL;
            //(ac_list_t *) m;
        }

        // stop timer
        uv_timer_stop(&s->timeout_watcher);
        ac_list_del(&s->session_list_node);
        ac_request_client_done(&s->r);
       // c->pool->ref --;

        if (c->handler->batch_process) {
            ac_list_add_tail(&s->session_list_node, &list);

            if (++ left >= 32) {
                (c->handler->batch_process)((ac_message_t *)&list);
                left = 0;
            }
        } else if (ac_session_process(s, 0) == AC_ERROR) {
            ac_warn_log("ac_session_process error, s=%p\n",  s);
            return AC_ERROR;
        }
    }

    // batch process
    if (cnt) m->recycle_cnt ++;

    if (left > 0) {
        (c->handler->batch_process)((ac_message_t *)&list);
    }

    // close
    if (c->wait_close ){//&& c->pool->ref == 0) {
        return AC_ERROR;
    }

    // send new packet
    if (c->handler->new_packet) {
        left = (AC_CONN_DOING_REQ_CNT >> 1) - c->doing_request_count;

        if (c->ioth->doing_request_count.cnt > 0) {
            left = ac_min(left, (AC_IOTH_DOING_REQ_CNT >> 1) - c->ioth->doing_request_count.cnt);
        }

        if (left > 0) {

            left = ac_min(cnt, left);

            for(i = 0; i < left; i++) {
                if ((c->handler->new_packet)(c) == AC_ERROR)
                    return AC_ERROR;
            }
            //由于udp aysnc 收不到，注释了这个aysnc异步通信。
            //ac_debug_log("uv_async_send(&c->write_watcher);/new_packet write");
           // uv_async_send(&c->write_watcher);
        }
    }

    if ((m = ac_connection_recycle_message(m)) == NULL) {
        ac_warn_log("ac_connection_recycle_message error, m=%p\n",   m);
        return AC_ERROR;
    }

    // status, message 没读完
    if (m->input->pos < m->input->last) {
        m->status = AC_MESG_READ_AGAIN;
    } else {
        ac_message_destroy(m, 1);
    }
    ac_debug_log("response over.");

    return AC_OK;
}

//处理请求
int ac_connection_do_request(ac_message_t *m)
{
    ac_debug_log("ac_connection_do_request\n");
    ac_connection_t       *c;
    void                  *packet;
    ac_request_t          *r, *rn;
    int                   cnt, ret,left;

    cnt = 0;
    c = m->c;
      // 处理buf, decode
    while (m->input->pos < m->input->last) {
          ac_debug_log("decode m->input->pos=%p,m->input->last=%p",m->input->pos,m->input->last);
        if ((packet = (c->handler->decode)(m)) == NULL) {
            if (m->status != AC_ERROR)
                break;

            ac_warn_log("decode error, m=%p\n", m);
            return AC_ERROR;
        }

        // new request

        r = (ac_request_t *)taw_malloc("ac_request_t", sizeof(ac_request_t),0);
        if(r==NULL)
        {
            ac_error_log("taw_malloc error ac_request_t");
            return AC_ERROR;
        }

        r->ms = (ac_message_session_t *)m;
        r->ipacket = packet;    //进来的数据包

        // add m->request_list
        ac_list_add_tail(&r->request_list_node, &m->request_list);
        cnt ++;
    }

    // cnt
    if (cnt) {
        m->request_list_count += cnt;
        c->doing_request_count += cnt;
        tawstd_atomic32_add(&c->ioth->doing_request_count, cnt);
        m->recycle_cnt ++;
    }

    if ((m = ac_connection_recycle_message(m)) == NULL)
        return AC_ERROR;

    m->status = ((m->input->pos < m->input->last) ? AC_MESG_READ_AGAIN : 0);


    // batch process
    if (c->handler->batch_process)
        (c->handler->batch_process)(m);

    // process
    cnt = 0;
    ac_list_for_each_entry_safe(r, rn, &m->request_list, request_list_node) {
        ac_list_del(&r->request_list_node);
        ac_thread_self->done_request_count ++;

        // process
        ac_debug_log("process\n");
        if ((ret = (c->handler->process)(r)) == AC_ERROR)
            return AC_ERROR;

        if (ret == AC_OK && ac_connection_request_done(r) == AC_OK) {
            cnt ++;
        }

        // write to socket
        if (cnt >= 128) {
            cnt = 0;

            if (ac_connection_write_socket(c) == AC_ABORT)
                return AC_ERROR;
        }
    }

    // 所有的request都有reply了,一起才响应
    if (ac_connection_write_socket(c) == AC_ABORT) {
        return AC_ERROR;
    }
    ac_debug_log("ac_connection_write_socket OVER. M=%p",m);

    if (m->request_list_count == 0 && m->status != AC_MESG_READ_AGAIN) {
        ac_message_destroy(m, 1);
    }

    // 加入监听
    ac_debug_log("c->event_status == AC_EVENT_READ %d !c->wait_close %d",c->event_status == AC_EVENT_READ,!c->wait_close);
    if (c->event_status == AC_EVENT_READ && !c->wait_close)
        ac_connection_uv_start(c);

    ac_connection_redispatch_thread(c);

    return AC_OK;
}

//为了均衡，切换到其他线程
void ac_connection_redispatch_thread(ac_connection_t *c)
{
    ac_io_thread_t    *ioth;

    // 处理了4095次以下, 不够30秒，或者有读写没完, 不能切换
    // ac_debug_log("need_redispatch=%d ac_list_empty(&c->message_list)=%d,ac_list_empty(&c->output)=%d",
     //             c->need_redispatch,ac_list_empty(&c->message_list),ac_list_empty(&c->output));
    if (!c->need_redispatch || ac_list_empty(&c->message_list) == 0 ||
            ac_list_empty(&c->output) == 0 || ac_thread_self->acio->no_redispatch)
        return;

    // 选择一新的ioth
    ioth = (ac_io_thread_t *)ac_thread_pool_rr(ac_thread_self->acio->io_thread_pool, 0);

    if (ioth == c->ioth)
        return;

    ac_list_del(&c->conn_list_node);

    if((c->addr.conn_flag&AC_UDP)!=AC_UDP)
        uv_read_stop((uv_stream_t*)c->io_stream);
    else
        uv_udp_recv_stop((uv_udp_t*)c->io_stream);

    //writer_wacher 是uv_async,关闭旧的，在新的loop开启新的
    if(!uv_is_closing((uv_handle_t *)&c->write_watcher))
        uv_close((uv_handle_t*)&c->write_watcher,NULL);
    uv_timer_stop(&c->timeout_watcher);

    ac_info_log("connetion=%p redispatch %p to %p\n", c, c->ioth, ioth);

    // 加入到新的队列中
    c->event_status = AC_EVENT_READ;
    c->ioth = ioth;
    uv_unref(c->io_stream);

    c->loop = ioth->loop;
    c->need_redispatch = 0;

    ac_spin_lock(&ioth->thread_lock);
    ac_list_add_tail(&c->conn_list_node, &ioth->conn_list);
    uv_async_send(&ioth->thread_watcher);//异步通信没有启动。
    ac_spin_unlock(&ioth->thread_lock);

}


ac_message_t *ac_connection_recycle_message(ac_message_t *m)
{
    ac_message_t          *newm;
    int                     len;

    len = (m->input->last - m->input->pos);

    if (m->recycle_cnt < 16 || len == 0)
        return m;

    // 增加default_message_len大小
    m->c->default_message_len += len;
    newm = ac_message_create(m->c);
    m->c->default_message_len -= len;

    if (newm == NULL)
        return NULL;

    // 检查buffer大小
    if (ac_buf_check_read_space( newm->input,m->c->default_message_len + len) != AC_OK) {
            ac_error_log("ac_buf_check_read_space failure, m=%p, len=%d\n", m, m->c->default_message_len + len);
            ac_message_destroy(newm, 1);
            return NULL;
    }

    // 把旧的移到新的上面,新的buf长度不够。
    memcpy(newm->input->pos, m->input->pos, len);
    newm->input->last += len;

    // 删除之前的message
    if (m->request_list_count == 0) {
        ac_message_destroy(m, 1);
    } else {
        m->status = 0;
    }

    return newm;
}

//Server将处理完的数据encode
int ac_connection_request_done(ac_request_t *r)
{

   ac_connection_t       *c;
    ac_message_t          *m;
    int                   retcode = r->retcode;

    m = (ac_message_t *) r->ms;
    c = m->c;
     //ac_info_log("1ac_connection_request_done doing_request_count--=%d,doing_request_count=%d code=%d",
                // c->doing_request_count,c->ioth->doing_request_count.cnt,retcode);

    ac_debug_log("ac_connection_request_done r->opacket=%p,c=%p",r->opacket,c);

    // encode
    if (r->opacket) {
        if ((c->handler->encode)(r, r->opacket) != AC_OK){
                // ac_info_log("encode error");
                  return AC_ERROR;
        }


        if (retcode == AC_AGAIN) { // 当write_socket写完
            ac_list_add_tail(&r->request_list_node, &c->session_list);
            r->opacket = NULL;
        }
    }

    // retcode
    if (retcode == AC_OK) {
        // 计算
       // ac_info_log("ac_connection_request_done doing_request_count--=%d,doing_request_count=%d",c->doing_request_count,c->ioth->doing_request_count.cnt);
        assert(m->request_list_count > 0);
        assert(c->doing_request_count > 0);
        m->request_list_count --;
        c->doing_request_count --;
        c->done_request_count ++;
        tawstd_atomic32_dec(&c->ioth->doing_request_count);
        ac_list_add_tail(&r->request_list_node, &m->request_done_list);

         //设置redispatch，处理超过4095次，connecttion开始超过30秒才可以触发一次负载均衡
        //ac_debug_log("need_redispatch c->sw_time=%lld,uv_now=%lld inteval=%lld done_request_count=%lld",
         //                c->sw_time, uv_now(c->loop), uv_now(c->loop)-c->sw_time, c->done_request_count);
        if (unlikely((c->done_request_count & 0xfff) == 8 && c->sw_time < (uv_now(c->loop) - 30000))) {

            c->need_redispatch = 1;
            c->sw_time = uv_now(c->loop);
        }
    }

    return AC_OK;

}

void ac_connection_uv_start(ac_connection_t *c)
{
    ac_debug_log("ac_connection_uv_start\n");
    c->io_stream->loop = c->loop;
    if ((c->event_status & AC_EVENT_READ)){

        if((c->addr.conn_flag&AC_UDP)!=AC_UDP)
            uv_read_start((uv_stream_t* )c->io_stream,ac_malloc_cb,ac_read_cb);
        else{
            int r = uv_udp_recv_start((uv_udp_t*)c->io_stream, ac_malloc_cb, ac_recv_cb);
            if (r)
                ac_error_log("uv_udp_recv_start: %s\n", uv_strerror(r));

        }
    }


    if ((c->event_status & AC_EVENT_WRITE)){
        //改直接调用，在uv——async中，上一次触发ac_connect_wakeup_cb，同时触发了c->write_watcher
        //如果再发数据给uv——async，会导致下次空触发。

         ac_connection_on_writable(&c->write_watcher);
        // uv_async_send(&c->write_watcher);
    }


  if ((c->event_status & AC_EVENT_TIMEOUT)){
       uint64_t timeout,repeat;
       if(c->type==AC_TYPE_CLIENT){
            timeout=(c->client->timeout ? c->client->timeout : AC_CLIENT_DEFAULT_TIMEOUT) ;
            ac_debug_log("ac_connection_uv_start AC_TYPE_CLIENT  timeout=%d",timeout);
            uv_timer_start(&c->timeout_watcher, ac_connection_on_timeout_conn, timeout, 0);
       }
       else if(c->handler->on_idle){
            repeat = ac_max(1000, c->idle_time);
            ac_debug_log("ac_connection_uv_start server on idle  repeat=%d",repeat);
            uv_timer_start(&c->timeout_watcher, ac_connection_on_timeout_conn, 0, repeat);
       }
       else{
             uv_timer_start(&c->timeout_watcher, ac_connection_on_timeout_conn, AC_CLIENT_DEFAULT_TIMEOUT, 0);
       }

  }


    c->event_status = 0;
     ac_debug_log("ac_connection_uv_start over\n");
}


/**
 * 把connection上的output的buffer写到socket上
 *
 * @param c - ac_connection_t对象
 * @return  - AC_ABORT 网络断开
 *            AC_AGAIN 没写完,需要继续写
 *            AC_OK    写完了
 */
int ac_connection_write_socket(ac_connection_t *c)
{
    ac_debug_log("ac_connection_write_socket\n");
    int ret;

    // 空的直接返回
    if (ac_list_empty(&c->output)){
         ac_debug_log("ac_connection_write c->output  empty return.");
         return AC_OK;
    }

    // 加塞
    if ((c->addr.conn_flag&AC_TCP) && ac_thread_self->acio->tcp_cork && c->tcp_cork_flag == 0) {
        int value = 1;
        setsockopt(((uv_stream_t*)c->io_stream)->io_watcher.fd, IPPROTO_TCP, TCP_CORK, (const void *) &value, sizeof(value));
        c->tcp_cork_flag = 1;
    }

    ret = ac_socket_write(c->io_stream, &c->output);

    if (ret == AC_ERROR) {
        ac_warn_log("ret=%d, addr: %s, error: %s (%d)\n", ret,
                      c->addr.addr, strerror(errno), errno);
        c->conn_has_error = 1;
        return AC_ABORT;
    }

    c->last_time = uv_now(c->loop);

    if (ac_list_empty(&c->output) && c->wait_close) {// 需要关闭掉
        ac_debug_log(" c->wait_close =%d", c->wait_close);
        return AC_ABORT;
    }

    return ac_connection_write_again(c);
}

// 判断write again
int ac_connection_write_again(ac_connection_t *c)
{
    ac_request_t      *r, *rn;

    // 还有没写出去, 起写事件
    if (ac_list_empty(&c->output) == 0) {
        ac_debug_log("empty:%d,write again uv_async_send %p ",ac_list_empty(&c->output),&c->write_watcher);
        uv_async_send(&c->write_watcher);
        return AC_AGAIN;
    } else {
        if (c->type == AC_TYPE_SERVER) {
            if (!ac_list_empty(&c->session_list)) {
                ac_list_for_each_entry_safe(r, rn, &c->session_list, request_list_node) {
                    ac_list_del(&r->request_list_node);
                    (c->handler->process)(r);
                }
            } else if (c->wait_close) {// 需要关闭掉
                return AC_ABORT;
            }
        }

        //发完c->output,那么把s->nextb置空,这样connect超时，ac_session_process(s,1)中，不必置空output。
        ac_session_t  *s, *sn;
        if (c->send_queue) {
            ac_list_for_each_entry_safe(s, sn, &(c->send_queue->list), send_queue_list) {
                s->nextb = NULL;
            }
        }

        // tcp_nodelay, tcp_cork
        if ((c->addr.conn_flag&AC_TCP) && ac_thread_self->acio->tcp_nodelay && c->tcp_nodelay_flag == 0) {
            int value = 1;
            setsockopt(((uv_stream_t*)c->io_stream)->io_watcher.fd, IPPROTO_TCP, TCP_NODELAY, (const void *) &value, sizeof(value));
            c->tcp_nodelay_flag = 1;
        } else if ((c->addr.conn_flag&AC_TCP) && ac_thread_self->acio->tcp_cork && c->tcp_cork_flag == 0) {
            int value = 1;
            setsockopt(((uv_stream_t*)c->io_stream)->io_watcher.fd, IPPROTO_TCP, TCP_CORK, (const void *) &value, sizeof(value));
            c->tcp_cork_flag = 1;
        }
    }

    return AC_OK;
}

//异步write事件处理
void ac_connection_on_writable(uv_async_t *handle)
{
    ac_debug_log("ac_connection_on_writable\n");
    ac_connection_t       *c;
    int                     ret;


    c = (ac_connection_t *)handle->data;
    if(c->loop)
        c->loop = ac_thread_self->loop;

    if(c->io_stream)
        c->io_stream->loop = c->loop;
    ret = ac_connection_write_socket(c);

    if (ret == AC_ABORT){
        ac_debug_log("ac_connection_disconnect  ac_connection_write_socket AC_ABORT");
        ac_connection_destroy(c);
        IF_UTHREAD_YIELD
        return;
    }

    // connected.
    if (c->status == AC_CONN_CONNECTING && c->type == AC_TYPE_CLIENT) {
        c->status = AC_CONN_OK;

        if((c->addr.conn_flag&AC_UDP)!=AC_UDP)
            uv_read_start((uv_stream_t*)c->io_stream, ac_malloc_cb,ac_read_cb);
        else{
            int r=uv_udp_recv_start((uv_udp_t*)c->io_stream, ac_malloc_cb, ac_recv_cb);
            if (r)
                ac_error_log("uv_udp_recv_start: %s\n", uv_strerror(r));

        }
        uv_timer_set_repeat(&c->timeout_watcher, AC_MIN_INTERVAL*1000);
        c->timeout_watcher.timer_cb = ac_connection_on_timeout_conn;

        uv_timer_again(&c->timeout_watcher);


        // on connect
        if (c->handler->on_connect)
            (c->handler->on_connect)(c);
    }


    // send new packet
    if (c->handler->new_packet && c->type == AC_TYPE_CLIENT && ret == AC_OK
            && c->doing_request_count < (AC_CONN_DOING_REQ_CNT >> 1)) {
        if ((c->handler->new_packet)(c) == AC_ERROR){
            ac_debug_log("ac_connection_disconnect new_packet AC_ERROR");
            ac_connection_destroy(c);
            IF_UTHREAD_YIELD
            return;
        }
    }

    IF_UTHREAD_YIELD
    return;

}
/**
 * 把ac_list_t上的内容通过uv_write写到socket上
 */
#define AC_SOCKET_RET_CHECK(ret, size, again) if (ret<0) return ret; else size += ret; if (again) return size;
int ac_socket_write(uv_handle_t *fd, ac_list_t *l)
{
    ac_debug_log("ac_socket_write");
    ac_buf_t      *b, *b1;
    ac_file_buf_t  *fb;
    struct iovec    iovs[AC_IOV_MAX];
    int             sended, size, cnt, ret, wbyte, again;

    wbyte = cnt = sended = again = 0;


    // foreach
    ac_list_for_each_entry_safe(b, b1, l, node) {

        if(b->flags==AC_BUF_FILE){

            ac_debug_log("b->flags==AC_BUF_FILE");

            if (cnt > 0) {
                ret = ac_socket_chain_writev(fd,l,iovs,cnt,&again);
                AC_SOCKET_RET_CHECK(ret,wbyte,again);
                cnt=0;
            }
            fb = (ac_file_buf_t *)b;
            sended += fb->count;
            ret = ac_socket_sendfile(fd, fb, &again);
            AC_SOCKET_RET_CHECK(ret,wbyte,again);
        }
        else
        {
            size = b->last - b->pos;
            iovs[cnt].iov_base = b->pos;
            iovs[cnt].iov_len = size;
            ac_debug_log("b->flags!=AC_BUF_FILE size=%d",size);
            cnt ++;
            sended += size;

            // 数据量太大跳出
            if (cnt >= AC_IOV_MAX || sended >= AC_IOV_SIZE)
                break;

        }

    }
    ac_debug_log("ac_socket_write -> ac_socket_chain_writev cnt=%d",cnt);
    // writuv
    if (cnt > 0) {

        ret = ac_socket_chain_writev(fd,l,iovs,cnt,&again);
        AC_SOCKET_RET_CHECK(ret,wbyte,again);
    }

    return wbyte;
}
int ac_socket_chain_writev(uv_handle_t *fd, ac_list_t *l, struct iovec *iovs, int cnt, int *again)
{
     ac_debug_log("ac_socket_chain_writev");
    int             ret=0, sended, size;
    ac_buf_t      *b, *b1;

     ac_connection_t *c;

      c = (ac_connection_t *)fd->data;

      if((c->addr.conn_flag&AC_UDP)!=AC_UDP)
      {
           ac_debug_log("ac_socket_chain_writev AC_TCP or AC_IPC");
            do {
                ret = writev(((uv_stream_t*)fd)->io_watcher.fd, iovs, cnt);
                ac_debug_log("writev fd: %d,ret=%d,errno=%d\n", ((uv_stream_t*)fd)->io_watcher.fd, ret,errno);
            } while(ret == -1 && errno == EINTR);
            ac_debug_log("writev: %d, fd: %d\n", ret, ((uv_stream_t*)fd)->io_watcher.fd);
      }
      else
      {
            struct sockaddr* addr_base;

            if(c->addr_udp)
            {
                //udp收到数据的地址，ac_recv_cb中赋值
                addr_base = c->addr_udp;
                if((c->addr.conn_flag&AC_IPV4)==AC_IPV4)
                    ac_debug_log("sendto recv addr ip=%s port=%d\n",
                                 inet_ntoa(((struct sockaddr_in*)addr_base)->sin_addr),
                                 ((struct sockaddr_in*)addr_base)->sin_port);

            }
            else if((c->addr.conn_flag&AC_IPV6)==AC_IPV6)
            {
                ac_debug_log("sendto AC_IPV6,addr=%s,port=%d\n",c->addr.addr,c->addr.port);
                struct sockaddr_in6 addr6;
                uv_ip6_addr(c->addr.addr, c->addr.port, &addr6);
                addr_base = (struct sockaddr*)&addr6;


            }
            else if((c->addr.conn_flag&AC_IPV4)==AC_IPV4)
            {
                ac_debug_log("sendto AC_IPV4,addr=%s,port=%d\n",c->addr.addr,c->addr.port);
                struct sockaddr_in addr4;
                uv_ip4_addr(c->addr.addr, c->addr.port, &addr4);
                addr_base = (struct sockaddr*)&addr4;

            }


            // int i;
            // for(i=0; i<cnt; i++){
                struct msghdr h;
                memset(&h, 0, sizeof h);
                h.msg_name = addr_base;
                h.msg_namelen = ((c->addr.conn_flag&AC_IPV6)==AC_IPV6 ?
                sizeof(struct sockaddr_in6) : sizeof(struct sockaddr_in));
                h.msg_iov = iovs;
                h.msg_iovlen = cnt;

                do {
                   ret = sendmsg(((uv_udp_t*)fd)->io_watcher.fd, &h, 0);
                }
                while (ret == -1 && errno == EINTR);
                  // ret += sendto(((uv_udp_t*)fd)->io_watcher.fd, iovs[i].iov_base, iovs[i].iov_len, 0, (struct sockaddr*)addr_base, addr_len);
            // }


            ac_debug_log("sendto:c=%p addrudp=%p %d, fd: %d\n",c,c->addr_udp, ret,((uv_udp_t*)fd)->io_watcher.fd);
     }



    // 结果处理
    if (ret >= 0) {
        sended = ret;

        tawstd_atomic64_add(&ac_thread_self->acio->send_byte, sended);

        ac_list_for_each_entry_safe(b, b1, l, node) {
            size = b->last - b->pos;

            b->pos += sended;
            sended -= size;

            if (sended >= 0) {
                cnt --;
                ac_buf_destroy(b);

            }

            if (sended <= 0)
                break;
        }
        *again = (cnt > 0);
    } else {
        ret = ((errno == EAGAIN) ? AC_AGAIN : AC_ERROR);
    }

    return ret;
}

int ac_socket_sendfile(uv_handle_t *fd, ac_file_buf_t *fb, int *again){
    int ret;
    int sockfd=-1;

    if(fd->type == UV_UDP){
        ac_error_log("udp do not support sendfile");
        return AC_ERROR;
    }

    sockfd = ((uv_stream_t*)fd)->io_watcher.fd;

    do {

        ret = sendfile(sockfd, fb->fd, (off_t *)&fb->offset, fb->count);
    } while(ret == -1 && errno == EINTR);

    // 结果处理
    if (ret >= 0) {
        ac_debug_log("sendfile: %d, fd: %d\n", ret, sockfd);
        tawstd_atomic64_add(&ac_thread_self->acio->send_byte, ret);

        if (ret < fb->count) {
            fb->count -= ret;
            *again = 1;
        } else {
            ac_buf_destroy((ac_buf_t *)fb);
        }
    } else {
        ret = ((errno == EAGAIN) ? AC_AGAIN : AC_ERROR);
    }

    return ret;

}


//调用encode，并将请求加入ac_connect_t中。
int ac_connection_session_build(ac_session_t *s)
{
    ac_debug_log("ac_connection_session_build ");
    double                  t;
    ac_connection_t       *c = s->c;

    if (c->type != AC_TYPE_CLIENT)
        return AC_ERROR;

    // 得到packet_id
    s->packet_id = ac_connection_get_packet_id(c, s->r.opacket, 0);

    // encode
    (c->handler->encode)(&s->r, s->r.opacket);

    s->timeout_watcher.data = s;

    //可能有问题。
    ac_hash_dlist_add(c->send_queue, s->packet_id, &s->send_queue_hash, &s->send_queue_list);

    c->doing_request_count ++;

    // timeout设置
    t = (s->timeout ? s->timeout : AC_CLIENT_DEFAULT_TIMEOUT);

    //if (c->status == AC_CONN_OK) t += uv_now(c->loop);
    ac_debug_log("ac_connection_session_build t=%d uv_now=%lld c->status=%d",t,uv_now(c->loop),c->status );
    //初始化timer可能段错误
    uv_timer_init(c->loop,&s->timeout_watcher);

    // 加入c->session_list
    if (c->status != AC_CONN_OK) {
        uv_timer_start(&s->timeout_watcher, ac_connection_on_timeout_mesg, t, 0.0);
    } else {
        ac_list_add_tail(&s->session_list_node, &c->session_list);
        uv_timer_set_repeat(&c->timeout_watcher, AC_MIN_INTERVAL*1000);
        c->timeout_watcher.timer_cb = ac_connection_on_timeout_conn;
        uv_timer_again(&c->timeout_watcher);
    }

    return AC_OK;
}

// 处理超时的message的回调函数
void ac_connection_on_timeout_mesg(uv_timer_t* handle)
{
    static int now = 0;
    ac_connection_t   *c;
    ac_session_t      *s;

    s = (ac_session_t *)handle->data;
    c = s->c;

    ac_hash_dlist_del(c->send_queue, s->packet_id);
    s->packet_id = 0;

    // process
    if (now != (int)uv_now(handle->loop)) {
        ac_warn_log("timeout_mesg: %p\n", s);
    }

    if (ac_session_process(s, 1) == AC_ERROR){
        ac_debug_log("ac_connection_disconnectac_session_process AC_ERROR");
        ac_connection_destroy(c);
    }


    IF_UTHREAD_YIELD
}


//销毁ac_connection_t对象,调用on_disconnect
void ac_connection_destroy(ac_connection_t *c)
{
    ac_debug_log("ac_connection_destroy c=%p\n",c);
    ac_message_t  *m, *m2;
    ac_io_t       *acio;

    // release session
    ac_connection_wakeup_session(c);

    // disconnect
    acio = c->ioth->acio;

    ac_debug_log("on_disconnect\n");
    if (c->status != AC_CONN_CLOSE && c->handler->on_disconnect) {
        (c->handler->on_disconnect)(c);
    }

    // refcount
    if (c->status != AC_CONN_CLOSE && acio->stoped == 0) {
        if((c->addr.conn_flag&AC_UDP)!=AC_UDP)
            uv_read_stop((uv_stream_t*)c->io_stream);
        else
            uv_udp_recv_stop((uv_udp_t*)c->io_stream);

        if(!uv_is_closing((uv_handle_t *)&c->write_watcher))
            uv_close((uv_handle_t *)&c->write_watcher,NULL);
        c->status = AC_CONN_CLOSE;

        // wakeup other thread...TODO 给WORKER线程池启动。
        if (c->type == AC_TYPE_SERVER) {
            ac_thread_pool_t *tp = acio->thread_pool;

            while (tp) {
                ac_thread_pool_on_wakeup(tp);
                tp = tp->next;
            }
        }

    }

    if (c->type == AC_TYPE_SERVER) {
           ac_request_t *r, *n;
           ac_list_for_each_entry_safe(r, n, &c->session_list, request_list_node) {
               ac_request_server_done(r);
           }
       }


    if (acio->stoped == 0) return;

    // release request
    if (c->type == AC_TYPE_SERVER) {
        ac_request_t *r, *n;
        ac_list_for_each_entry_safe(r, n, &c->session_list, request_list_node) {
            ac_list_del(&r->request_list_node);
        }
    }

    // release message
    ac_list_for_each_entry_safe(m, m2, &c->message_list, message_list_node) {
        ac_message_destroy(m, 1);
    }

    //release output buffer list
    ac_buf_t *b,*b1;

    ac_list_for_each_entry_safe(b, b1, &c->output, node) {
        ac_debug_log("destroy buf %p not yet write\n",b);
        ac_buf_destroy(b);
    }
    ac_list_init(&c->output);

    if(c->io_stream != NULL){
        if((c->addr.conn_flag&AC_UDP)!=AC_UDP)
            uv_read_stop((uv_stream_t*)c->io_stream);
        else
            uv_udp_recv_stop((uv_udp_t*)c->io_stream);
    }



    if(!uv_is_closing((uv_handle_t *)&c->write_watcher))
        uv_close((uv_handle_t *)&c->write_watcher,NULL);
    uv_timer_stop(&c->timeout_watcher);

    // close
    //server 端的io_stream 也在中保存了一份，在acio_destroy时释放。
    //所以这里只需要释放client端的
    if (c->io_stream != NULL&&c->type == AC_TYPE_CLIENT) {
        ac_debug_log("free c->io_stream\n");
        if(!uv_is_closing(c->io_stream))
            uv_close(c->io_stream, NULL);
        taw_free(c->io_stream);
    }

    // autoreconn
    if (c->auto_reconn && acio->stoped == 0) {
        c->status = AC_CONN_AUTO_CONN;
        uint64_t t = c->reconn_time * (1 << c->reconn_fail);

        if (t > 15000) t = 15000;

        if (c->reconn_fail < 16) c->reconn_fail ++;

        ac_warn_log("[%p] connection reconn_time: %f, reconn_fail: %d\n", c, t, c->reconn_fail);
        uv_timer_set_repeat(&c->timeout_watcher, t);
        c->timeout_watcher.timer_cb = ac_connection_on_timeout_conn;
        uv_timer_again(&c->timeout_watcher);
        return;
    }

    ac_list_del(&c->conn_list_node);

    ac_hash_destroy(c->send_queue);

    //if (c->client) c->client->c = NULL;

    taw_free(c);

}

//销毁掉ac_request_t对象,调用cleanup
void ac_request_server_done(ac_request_t *r)
{
    ac_connection_t   *c = r->ms->c;

    if (c->type == AC_TYPE_SERVER && c->handler->cleanup) {
        (c->handler->cleanup)(r, NULL);
    }
    taw_free(r);
}

//session_timeout
void ac_connection_wakeup_session(ac_connection_t *c)
{
    ac_debug_log("ac_connection_wakeup_session");
    ac_session_t  *s, *sn;
    if (c->send_queue) {

        ac_list_for_each_entry_safe(s, sn, &(c->send_queue->list), send_queue_list) {
            ac_hash_del_node(&s->send_queue_hash);
            ac_session_process(s, 1);
        }
        ac_list_init(&c->send_queue->list);
    }

}

//得到packet的id
uint64_t ac_connection_get_packet_id(ac_connection_t *c, void *packet, int flag)
{
    ac_debug_log("ac_connection_get_packet_id ");
    uint64_t packet_id = 0;

    if (c->handler->get_packet_id) {
            ac_error_log("get_packet_id ");
        packet_id = (c->handler->get_packet_id)(c, packet);
    } else {
        packet_id = c->send_queue->seqno;

        if (flag) packet_id -= c->send_queue->count;

        packet_id <<= 16;
        int fd=-1;
        if(c->addr.conn_flag&AC_UDP)
            fd = ((uv_udp_t*)c->io_stream)->io_watcher.fd;
        else
            fd = ((uv_stream_t*)c->io_stream)->io_watcher.fd;

        packet_id |= (fd & 0xffff);
    }

    return packet_id;
}

ac_connection_t *ac_connection_do_client(ac_session_t *s)
{
    ac_debug_log("ac_connection_do_client loop %p  s->status=%d\n",ac_thread_self->loop,s->status);
    ac_io_thread_t        *ioth = ac_thread_self;
    ac_connection_t       *c = NULL;
    ac_client_t           *client;

    // hashcode
    client = (ac_client_t *)ac_client_list_find(ioth->client_list, &s->addr);
    ac_debug_log("ac_connection_do_client client_list %p  addr %s,flag=%d,port=%d\n",
                 ioth->client_list,s->addr.addr,s->addr.conn_flag,s->addr.port);
    c = (client && client->ref ? client->c : NULL);


    // 正常的session
    if (s->status == 0) {

        c = (client && client->ref ? client->c : NULL);



        if (s->process == NULL && c && c->handler) {
            s->process = c->handler->process;
        }

        if (c == NULL || ioth->acio->stoped) {//如果不能发送，直接执行session的回调函数process.
            ac_warn_log("fail to send,client=%p c=%p,stoped=%d",client,c,ioth->acio->stoped);
            s->error = 1;
            c = NULL;
            ac_session_process(s, 0);
        }

        return c;

    // 连接指令
    } else if (s->status == AC_CONNECT_ADDR) {
        if (client == NULL) {
            if ((client = (ac_client_t *)taw_malloc("ac_client_t",sizeof(ac_client_t),0)) == NULL){
                ac_error_log("taw malloc fail ac_client_t");
                return c;
            }

            memset(client, 0, sizeof(ac_client_t));

            strcpy(client->addr.addr,s->addr.addr);
            client->addr.port = s->addr.port;
            client->addr.conn_flag = s->addr.conn_flag;

            client->handler = (ac_handler_pt *)s->process;//连接时process内存的是结构体指针。
            client->timeout = s->timeout;
            client->user_data = s->r.args;
            ac_client_list_add(ioth->client_list, &client->addr, &client->client_list_node);
            ac_list_add_tail(&client->ac_client_node,&ioth->client_array);
        }

        if (client->c == NULL && (ac_connection_do_connect(client)!= AC_OK)){
            ac_error_log("create connect error c=%p,client=%p",client->c,client);
            return NULL;
        }


        c = client->c;

        c->user_data = client->user_data;

        if (s->packet_id) c->auto_reconn = 1;

        client->ref ++;

    // 断开指令
    } else if (client && --client->ref == 0) {

        if (client->c) {
            ac_info_log("ac_connection_do_client wait_close========================1")
            client->c->wait_close = 1;
            client->c->client = NULL;
        }

        ac_hash_del_node(&client->client_list_node);
         //client的释放都等到io线程destroy时
        //taw_free(client);
    }

    return c;
}

// add addr
int ac_client_list_add(ac_hash_t *table, ac_addr_t *addr, ac_hash_list_t *list)
{
    uint64_t            n;
    ac_hash_list_t    *first;

    n = ac_hash_code(addr, sizeof(ac_addr_t), 5);
    n &= table->mask;

    // init
    list->key = (long)(void *)addr;

    // add to list
    first = table->buckets[n];
    list->next = first;

    if (first) first->pprev = &list->next;

    table->buckets[n] = (ac_hash_list_t *)list;
    list->pprev = &(table->buckets[n]);

    return AC_OK;
}

/**
 * Client端连接到Server,这个函数应该是阻塞的，必须等到连接完成才能返回。
 */
int ac_connection_do_connect(ac_client_t *client)
{
    ac_debug_log("ac_connection_do_connect, ip:%s,port:%d,conn_flag:%d,\n",client->addr.addr,client->addr.port,client->addr.conn_flag);
    struct sockaddr* addr_base = NULL;
    ac_connection_t       *c;
    char                    buffer[32];

    int bind_flag = 0;
    if((client->addr.conn_flag&AC_IPV6)==AC_IPV6){
            ac_debug_log("AC_IPV6\n");

        struct sockaddr_in6 addr6;
        uv_ip6_addr(client->addr.addr, client->addr.port, &addr6);
        addr_base = (struct sockaddr*)&addr6;
        bind_flag = 1;
    }
    //如果没有设置IP类型，默认AC_IPV4
    else {//if((client->addr.conn_flag&AC_IPV4)==AC_IPV4){
        ac_debug_log("AC_IPV4\n");
        struct sockaddr_in addr4;
        uv_ip4_addr(client->addr.addr, client->addr.port, &addr4);
        addr_base = (struct sockaddr*)&addr4;

    }


    uv_stream_t* baseServer;
    uv_tcp_t* tcpServer;
    uv_udp_t* udpServer;
    uv_pipe_t* pipeServer;
    int r;
    if((client->addr.conn_flag&AC_TCP)==AC_TCP ){
        ac_debug_log("AC_TCP\n");

        int sockfd = -1;
        unsigned int addrlen;
        if (addr_base->sa_family == AF_INET){
            addrlen = sizeof(struct sockaddr_in);
            sockfd = socket(AF_INET, SOCK_STREAM, 0);
        }
        else if (addr_base->sa_family == AF_INET6){
            addrlen = sizeof(struct sockaddr_in6);
            sockfd = socket(AF_INET6, SOCK_STREAM, 0);
        }

         //允许reuse
          int yes = 1;
          r = setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof yes);

          /* connect to the server */
          int result = connect(sockfd, addr_base, addrlen);
          if(result == -1)
          {
                ac_error_log("connect failure\n");
                return AC_ERROR;
          }

         if ((tcpServer = (uv_tcp_t *) taw_malloc("uv_tcp_t", sizeof(uv_tcp_t), 0)) == NULL) {
                ac_error_log("taw_malloc failure: uv_tcp_t size=%d\n",sizeof(uv_tcp_t));
                return AC_ERROR;
          }
          baseServer = (uv_stream_t*)tcpServer;

          r = uv_tcp_init(ac_thread_self->loop, tcpServer);
          if (r) {
            ac_error_log("Socket creation error\n");
            return AC_ERROR;
          }
          if(uv_tcp_open(tcpServer, sockfd))
          {
            ac_error_log("Socket creation error\n");
            return AC_ERROR;
          }



    }
    else if((client->addr.conn_flag&AC_UDP)==AC_UDP)
    {
        ac_debug_log("AC_UDP\n");
        //使用了uv_udp_open,那么客户端不能正常退出，close_watcher没有收到。

        int sockfd = -1;
        int yes = 1;
        if (addr_base->sa_family == AF_INET){
            sockfd = socket(AF_INET, SOCK_DGRAM, 0);
        }
        else if (addr_base->sa_family == AF_INET6){
            sockfd = socket(AF_INET6, SOCK_DGRAM, 0);

            if (setsockopt(sockfd, IPPROTO_IPV6, IPV6_V6ONLY, &yes, sizeof yes) == -1) {
                ac_error_log("setsockopt IPV6_V6ONLY error\n");
                return AC_ERROR;
        }
        }

        //允许reuse
          yes = 1;
          r = setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof yes);

          if ((udpServer = (uv_udp_t *) taw_malloc("uv_udp_t", sizeof(uv_udp_t), 0)) == NULL) {
            ac_error_log("taw_malloc failure: uv_udp_t size=%d\n",sizeof(uv_udp_t));
            return AC_ERROR;
          }
          baseServer = (uv_stream_t*)udpServer;

          r = uv_udp_init(ac_thread_self->loop, udpServer);
          if (r) {
            ac_error_log("Socket creation error\n");
            return AC_ERROR;
          }
          if(uv_udp_open(udpServer, sockfd)){
            ac_error_log("Socket creation error\n");
            return AC_ERROR;
          }


    }
   else if ((client->addr.conn_flag&AC_SOCKET_UN)==AC_SOCKET_UN)
    {
          ac_debug_log("AC_SOCKET_UN\n");
          if ((pipeServer = (uv_pipe_t *) taw_malloc("uv_pipe_t", sizeof(uv_pipe_t), 0)) == NULL) {
            ac_error_log("taw_malloc failure: uv_pipe_t size=%d\n",sizeof(uv_pipe_t));
            return AC_ERROR;
          }

          struct sockaddr_un saddr;
          int new_sock;

          new_sock = socket(AF_UNIX, SOCK_STREAM, 0);

          memset(&saddr, 0, sizeof saddr);
          strncpy(saddr.sun_path, client->addr.addr, sizeof(saddr.sun_path) - 1);
          saddr.sun_path[sizeof(saddr.sun_path) - 1] = '\0';
          saddr.sun_family = AF_UNIX;

          r = connect(new_sock,(struct sockaddr*)&saddr, sizeof saddr);

          baseServer = (uv_stream_t*)pipeServer;
          pipeServer->data = client;


          r = uv_pipe_init(ac_thread_self->loop, pipeServer, 1);
          if (r) {
            ac_error_log("uv_pipe_init: %s\n", uv_strerror(r));
            return AC_ERROR;
          }

          r = uv_pipe_open(pipeServer,new_sock);
          if (r) {
            ac_error_log("Pipe open error\n");
            return AC_ERROR;
          }

    }
    else if ((client->addr.conn_flag&AC_FD)==AC_FD)
    {
        ac_debug_log("AC_FD\n");
         if ((pipeServer = (uv_pipe_t *) taw_malloc("uv_pipe_t", sizeof(uv_pipe_t), 0)) == NULL) {
            ac_error_log("taw_malloc failure: uv_pipe_t size=%d\n",sizeof(uv_pipe_t));
            return AC_ERROR;
          }

          r = uv_pipe_init(ac_thread_self->loop, pipeServer, 1);
          if (r) {
            ac_error_log("uv_pipe_init: %s\n", uv_strerror(r));
            return AC_ERROR;
          }

          r = uv_pipe_open(pipeServer,atoi(client->addr.addr));
          if (r) {
            ac_error_log("Pipe open error\n");
            return AC_ERROR;
          }

          baseServer = (uv_stream_t*)pipeServer;
          pipeServer->data = client;

    }
    return ac_connection_client_new_connect((uv_handle_t *)baseServer,client);
}


//client端生成connection对象
int ac_connection_client_new_connect(uv_handle_t *stream, ac_client_t *client){

    ac_debug_log("ac_connection_client_new_connect\n");
    int v;
    double           t;
    ac_connection_t *c;
        // 建立一个connection
    if ((c = ac_connection_new()) == NULL) {
        ac_error_log("new connect failure.\n");
        return AC_ERROR;
    }
    // 初始化
    c->io_stream = stream;
    c->io_stream->data = c;
    c->ioth = ac_thread_self;
    c->loop = ac_thread_self->loop;
    c->sw_time = uv_now(c->loop);
    c->io_stream->loop = c->loop;

    c->type = AC_TYPE_CLIENT;
    c->handler = client->handler;

    strcpy(c->addr.addr,client->addr.addr);
    c->addr.port = client->addr.port;
    c->addr.conn_flag = client->addr.conn_flag;

    c->client = client;
    client->c = c;

    // 连接
    c->status = AC_CONN_CONNECTING;

    v = offsetof(ac_session_t, send_queue_hash);

    c->send_queue = ac_hash_create(AC_CONN_DOING_REQ_CNT, v);

    // 初始化事件
     ac_debug_log(">>>>>>>>>>>>>>>uv_async_init c->write_watcher");
     uv_async_init(c->loop,&c->write_watcher, ac_connection_on_writable);

    t = (client->timeout ? client->timeout : AC_CLIENT_DEFAULT_TIMEOUT) ;

    uv_timer_init(c->loop,&c->timeout_watcher);
    c->write_watcher.data = c;
    c->timeout_watcher.data = c;

    // event_status
    if (c->status == AC_CONN_CONNECTING)
        v = (AC_EVENT_TIMEOUT | AC_EVENT_WRITE);
    else
        v = (AC_EVENT_TIMEOUT | AC_EVENT_READ);

    ac_debug_log("connect to '%s' success, connection=%p\n",
                   c->addr.addr, c);

    c->event_status = v;

    // 加入
    ac_list_add_tail(&c->conn_list_node, &c->ioth->connected_list);
    ac_connection_uv_start(c);

    return AC_OK;
}

//创建出一个connection_t对象
ac_connection_t *ac_connection_new(int flag)
{
    ac_connection_t       *c;
    int size = 0;
    if((flag&AC_IPV4) == AC_IPV4)
        size = sizeof(struct sockaddr_in);
    else if((flag&AC_IPV6) == AC_IPV6)
        size = sizeof(struct sockaddr_in6);
    c = (ac_connection_t *) taw_malloc("ac_connection_t", sizeof(ac_connection_t)+size, 0);

    if (c == NULL)
        return NULL;
    memset(c,0,size);

    c->doing_request_count=0;
    c->wait_close=0;

    // 初始化
    c->next = NULL;
    c->sw_time = 0;
    if(size)
        c->addr_udp = (struct sockaddr*)&(c->addr_udp_data[0]);
    c->reconn_time = 100;
    c->idle_time = AC_IDLE_TIMEOUT;
    ac_list_init(&c->message_list);
    ac_list_init(&c->session_list);
    ac_list_init(&c->conn_list_node);
    ac_list_init(&c->output);

    return c;

}

//调用process回调函数
int ac_session_process(ac_session_t *s, int stop)
{
    ac_debug_log("ac_session_process s->r=%p,s->p=%p",&s->r,s->process);
    int ret;
    if (stop) {

        uv_timer_stop(&s->timeout_watcher);
        ac_list_del(&s->session_list_node);
        ac_request_client_done(&s->r);

    }

    // timeout, 把output里的clear掉
    if (s->r.ipacket == NULL && s->nextb) {
        ac_buf_t *b, *b2;
        ac_list_for_each_entry_safe(b, b2, s->nextb, node) {

             if(&b->node && !ac_list_empty(&b->node))
                 ac_list_del(&b->node);
        }

        ac_list_del(s->nextb);
    }

    if (s->process) {
         ac_debug_log("ac_session_process process s->r=%p,s->p=%p",&s->r,s->process);
        ret = (s->process)(&s->r);
        if (s->waithandler)
            (s->waithandler)(&s->r);

        return ret;
    } else {
        if (s->waithandler)
            (s->waithandler)(&s->r);
        ac_session_destroy(s);
        ac_error_log("session process is null, s = %p\n", s);

        return AC_ERROR;
    }
}

void ac_request_client_done(ac_request_t *r)
{
    ac_connection_t   *c = r->ms->c;
    c->doing_request_count --;
    c->done_request_count ++;
    tawstd_atomic32_dec(&c->ioth->doing_request_count);
}

void *ac_client_list_find(ac_hash_t *table, ac_addr_t *addr)
{
    uint64_t            n;
    ac_hash_list_t    *list;

    n = ac_hash_code(addr, sizeof(ac_addr_t), 5);
    n &= table->mask;
    list = table->buckets[n];

    // foreach
    while(list) {
        if (memcmp((void *)(long)list->key, addr, sizeof(ac_addr_t)) == 0) {
            return ((char *)list - table->offset);
        }

        list = list->next;
    }

    return NULL;
}

//worker线程的唤醒的回调程序
void ac_request_on_wakeup(uv_async_t *handle)
{
    ac_debug_log("ac_request_on_wakeup\n");
    ac_baseth_t *thb = (ac_baseth_t*)handle->data;
    if (thb->acio->stoped) {
        ac_debug_log("close thread th=%p acio=%p\n", thb,thb->acio);
        ac_thread_pool_wakeup_session(thb);
        uv_close((uv_handle_t*)&thb->thread_watcher,NULL);
        uv_stop(thb->loop);
        if (thb->acio->uthread_enable)
               ac_uthread_stop();
        ac_debug_log("uv_stop: acio=%p\n", thb->acio);
        return;
    }

    ac_request_thread_t       *th;
    ac_list_t                 request_list;
    ac_list_t                 session_list;

    th = (ac_request_thread_t *) handle->data;

    // 取回list
    ac_spin_lock(&th->thread_lock);
    th->task_list_count = 0;

    ac_list_movelist(&th->task_list, &request_list);
    ac_list_movelist(&th->session_list, &session_list);
    ac_spin_unlock(&th->thread_lock);

    ac_request_doreq(th, &request_list);
    ac_request_dosess(th, &session_list);

}

//worker线程处理请求request
void ac_request_doreq(ac_request_thread_t *th, ac_list_t *request_list)
{
    ac_request_t              *r, *r2;
    ac_connection_t           *c;
    int                         cnt;

    cnt = 0;
    char ioth_flag[th->acio->io_thread_count];
    ac_list_t ioth_list[th->acio->io_thread_count];
    memset(ioth_flag, 0, sizeof(ioth_flag));

    // process
    ac_list_for_each_entry_safe(r, r2, request_list, request_list_node) {
        c = r->ms->c;

        ac_list_del(&r->request_list_node);

        // 处理
        if (c->status != AC_CONN_CLOSE) {
            r->retcode = (th->process)(r, th->args);
        } else {
            r->retcode = AC_ERROR;
        }

        if (!ioth_flag[c->ioth->idx])
            ac_list_init(&ioth_list[c->ioth->idx]);

        ac_list_add_tail(&r->request_list_node, &ioth_list[c->ioth->idx]);
        ioth_flag[c->ioth->idx] = 1;

        if (++ cnt >= 32) {
            ac_request_wakeup_ioth(th->acio, ioth_flag, ioth_list);
            cnt = 0;
        }
    }

    if (cnt > 0) {
        ac_request_wakeup_ioth(th->acio, ioth_flag, ioth_list);
    }
}

//worker处理完请求，唤醒io线程把结果发出去
void ac_request_wakeup_ioth(ac_io_t *acio, char *ioth_flag, ac_list_t *ioth_list)
{
    int                 i;
    ac_io_thread_t    *ioth;

    for(i = 0; i < acio->io_thread_count; i++) {
        if (!ioth_flag[i])
            continue;

        ioth_flag[i] = 0;
        ioth = (ac_io_thread_t *)ac_thread_pool_index(acio->io_thread_pool, i);

        // dispatch to ioth
        ac_spin_lock(&ioth->thread_lock);
        ac_list_join(&ioth_list[ioth->idx], &ioth->request_list);

        uv_async_send(&ioth->thread_watcher);
        ac_spin_unlock(&ioth->thread_lock);
    }
}

//worker线程处理待发请求session
void ac_request_dosess(ac_request_thread_t *th, ac_list_t *session_list)
{
    ac_session_t              *s, *s2;

    // process
    ac_list_for_each_entry_safe(s, s2, session_list, session_list_node) {
        ac_list_del(&s->session_list_node);

        if ((th->process)(&s->r, th->args) != AC_AGAIN) {
            ac_session_destroy(s);
        }
    }
}

//地址解析
int ac_addr_parse(const char *addr, ac_addr_t *ac_addr)
{
      int i, plen, ret;
      char conn_flag_str[64];
      char port_str[6];
      char *tmp = (char *)addr;//tcp://192.168.1.1:55555

      int len = strlen(tmp);// len==28


      for(i=0; i<len; i++){
            if(i+2<len && *(tmp+i)==':'
              && *(tmp+i+1)=='/'
              && *(tmp+i+2)=='/') //i==8
              break;
      }
      if(i==len)
        return AC_ERROR;

      plen = i;
      strncpy(conn_flag_str, tmp, i);//tcp
      conn_flag_str[i]=0;
    //  ac_debug_log("conn_flag_str=%s", conn_flag_str);

      i = len;

      //ipc和fd不需要端口
      if(strcmp(conn_flag_str,"ipc") && strcmp(conn_flag_str,"fd")){
          for(i = len-1; i>=0; i--){
                if(*(tmp+i)==':') //i==22
                  break;
          }
          if(i==len-1 || i<=0 || len-i>6)
             return AC_ERROR;

          strncpy(port_str, tmp+i+1, len-i-1);//55555
          port_str[len-i-1]=0;
       //   ac_debug_log("port_str=%s",port_str);
          ac_addr->port = atoi(port_str);
      }
      else
           ac_addr->port = 0;

      if(i-plen-3 <= 0)//没有ip的位置
         return AC_ERROR;

      strncpy(ac_addr->addr, tmp+plen+3, i-plen-3);//192.168.1.1
      ac_addr->addr[i-plen-3]=0;

      ac_addr->conn_flag = 0;

      if(strcmp(conn_flag_str,"ipc")==0)
          ac_addr->conn_flag |= AC_SOCKET_UN;
      else if(strcmp(conn_flag_str,"tcp")==0)
          ac_addr->conn_flag |= AC_TCP;
      else if(strcmp(conn_flag_str,"udp")==0)
          ac_addr->conn_flag |= AC_UDP;
      else if(strcmp(conn_flag_str,"fd")==0)
          ac_addr->conn_flag |= AC_FD;
      else
          return AC_ERROR;
     //   ac_debug_log("conn_flag  flag=%d\n",
       //                    ac_addr->conn_flag);

      unsigned char buf[128];
      ret = inet_pton(AF_INET6, ac_addr->addr, buf);
      if (ret > 0)
         ac_addr->conn_flag |= AC_IPV6;
      else if(ac_addr->conn_flag == AC_TCP || ac_addr->conn_flag == AC_UDP)
         ac_addr->conn_flag |= AC_IPV4;

      return AC_OK;
}


/**
 * thread发送packet的时候用, 同步, 等待返回结果
 */
void *ac_client_send(ac_io_t *acio, const char *addr, ac_session_t *s)
{
     ac_debug_log("ac_client_send s->process=%p",s->process);
    int                 ret;
    ac_client_wait_t   wobj;

    ac_client_wait_init(&wobj);
    ac_session_set_wobj(s, &wobj);
    s->waithandler = ac_client_send_handler;

    if ((ret = ac_client_send_request(acio, addr, s)) == AC_ERROR) {
        s->error = 1;
        ac_warn_log("ac_client_send_request error ret=%d\n", ret);
        return NULL;
    }

    ac_client_wait(&wobj, 1);
    uv_cond_destroy(&wobj.cond);
    uv_mutex_destroy(&wobj.mutex);
    return s->r.ipacket;
}

// init
void ac_client_wait_init(ac_client_wait_t *w)
{
    w->done_count = 0;
    ac_list_init(&w->next_list);
    ac_list_init(&w->session_list);
    uv_mutex_init(&w->mutex);
    uv_cond_init(&w->cond);
}

void ac_client_wait_wakeup(ac_client_wait_t *w)
{
    uv_mutex_lock(&w->mutex);
    w->done_count ++;
    uv_cond_signal(&w->cond);
    uv_mutex_unlock(&w->mutex);
}

void ac_client_wait(ac_client_wait_t *w, int count)
{
    uv_mutex_lock(&w->mutex);

    while(w->done_count < count) {
        uv_cond_wait(&w->cond, &w->mutex);
    }

    uv_mutex_unlock(&w->mutex);

    if (ac_list_empty(&w->next_list))
        return;

    // next
    ac_list_t         *list = &w->next_list;
    ac_session_t      *s, *sn;
    int                 cnt = 0;

    ac_list_for_each_entry_safe(s, sn, list, session_list_node) {
        w = (ac_client_wait_t *)s->r.request_list_node.prev;

        ac_list_del(&s->session_list_node);
        ac_list_add_tail(&s->session_list_node, &w->session_list);

        if (++ cnt >= 8) {
            ac_list_movelist(list, &w->next_list);
            ac_client_wait_wakeup(w);
            break;
        } else {
            ac_client_wait_wakeup(w);
        }
    }
}

int ac_client_send_handler(ac_request_t *r)
{
    ac_client_wait_t  *w = (ac_client_wait_t *)r->request_list_node.prev;
    ac_session_t      *s = (ac_session_t *)r->ms;
    ac_list_add_tail(&s->session_list_node, &w->session_list);
    ac_client_wait_wakeup(w);
    return AC_OK;
}

int _nonblock(int fd, int set) {
  int r;

  do
    r = ioctl(fd, FIONBIO, &set);
  while (r == -1 && errno == EINTR);

  if (r)
    return -errno;

  return 0;
}


int _cloexec(int fd, int set) {
  int r;

  do
    r = ioctl(fd, set ? FIOCLEX : FIONCLEX);
  while (r == -1 && errno == EINTR);

  if (r)
    return -errno;

  return 0;
}

//对超时的conn处理
void ac_connection_on_timeout_conn(uv_timer_t* handle)
{
    ac_session_t          *s, *s2;
    ac_connection_t       *c;
    uint64_t              t, now;
    c = (ac_connection_t *)handle->data;

    ac_debug_log("ac_connection_on_timeout_conn: c=%p, status=%d, type=%d\n", c, c->status, c->type);

    if (c->status == AC_CONN_AUTO_CONN) {
        ac_connection_autoconn(c);
    } else if (c->status != AC_CONN_OK) { // AC_CONN_CLOSE, AC_CONN_CONNECTING
        ac_connection_destroy(c);
    } else { // AC_CONN_OK
        now = uv_now(c->loop);
        ac_debug_log("timeout_conn:now=%lld",now);

        if (c->handler->on_idle && c->last_time + c->idle_time  < now) {//回调idle函数

            c->last_time = now;
            (c->handler->on_idle)(c);
        }

        if (c->type == AC_TYPE_CLIENT) {
            if (ac_list_empty(&c->session_list)) { //客户端有idle继续等待，没有idle停止
                if (c->handler->on_idle) {
                    t = ac_max(1000, c->idle_time);
                    uv_timer_set_repeat(&c->timeout_watcher, t);
                    c->timeout_watcher.timer_cb = ac_connection_on_timeout_conn;
                    uv_timer_again(&c->timeout_watcher);
                } else {
                    uv_timer_stop(&c->timeout_watcher);
                }
            }

            // 延迟开始超时
            ac_list_for_each_entry_safe(s, s2, &c->session_list, session_list_node) {
                t = s->timeout;// - now;
                ac_debug_log("s->timeout=%lld,now=%lld,t=%lld",s->timeout,now,t);
                if(t<=0){
                    ac_list_del(&s->session_list_node);
                    break;
                }
                ac_list_del(&s->session_list_node);

                uv_timer_start(&s->timeout_watcher, ac_connection_on_timeout_mesg, t, 0.0);
                s->timeout=0;
            }
        }
    }
    IF_UTHREAD_YIELD

}

void ac_connection_autoconn(ac_connection_t *c)
{
    int                 sockfd,r;
    struct sockaddr     *addr_base;
    char                buffer[32];

    if((c->addr.conn_flag&AC_IPV6)==AC_IPV6){
            ac_debug_log("AC_IPV6\n");

        struct sockaddr_in6 addr6;
        uv_ip6_addr(c->addr.addr, c->addr.port, &addr6);
        addr_base = (struct sockaddr*)&addr6;
    }
    //如果没有设置IP类型，默认AC_IPV4
    else {//if((client->addr.conn_flag&AC_IPV4)==AC_IPV4){
        ac_debug_log("AC_IPV4\n");
        struct sockaddr_in addr4;
        uv_ip4_addr(c->addr.addr, c->addr.port, &addr4);
        addr_base = (struct sockaddr*)&addr4;

    }

    c->status = AC_CONN_CLOSE;

    if (c->client == NULL)
        return;


    // 初始化
    if ((c->addr.conn_flag&AC_TCP)==AC_TCP){ //TCP重建socket
        unsigned int addrlen;
        if (addr_base->sa_family == AF_INET){
            addrlen = sizeof(struct sockaddr_in);
            sockfd = socket(AF_INET, SOCK_STREAM, 0);
        }
        else if (addr_base->sa_family == AF_INET6){
            addrlen = sizeof(struct sockaddr_in6);
            sockfd = socket(AF_INET6, SOCK_STREAM, 0);
        }

         //允许reuse
          int yes = 1;
          r = setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof yes);

          /* connect to the server */
          if(connect(sockfd, addr_base, addrlen)<0)
          {
            if (errno == ECONNREFUSED) {
                ac_error_log("connect to '%s' failure: %s (%d)\n",
                               c->addr.addr, strerror(errno), errno);
                close(sockfd);
                return;
            }
            if (errno != EINPROGRESS) {
                ac_error_log("connect to '%s' failure: %s (%d)\n",
                               c->addr.addr, strerror(errno), errno);
                goto error_exit;
            }

            c->status = AC_CONN_CONNECTING;
        }
        else
            c->status = AC_CONN_OK;

        uv_tcp_open((uv_tcp_t*)c->io_stream, sockfd);
    }
    else if((c->addr.conn_flag&AC_SOCKET_UN)==AC_SOCKET_UN){ //SOCKET UNIX重建socket
        struct sockaddr_un saddr;

          sockfd = socket(AF_UNIX, SOCK_STREAM, 0);

          memset(&saddr, 0, sizeof saddr);
          strncpy(saddr.sun_path, c->addr.addr, sizeof(saddr.sun_path) - 1);
          saddr.sun_path[sizeof(saddr.sun_path) - 1] = '\0';
          saddr.sun_family = AF_UNIX;

          if(connect(sockfd,(struct sockaddr*)&saddr, sizeof saddr)<0)
          {
            if (errno == ECONNREFUSED) {
                ac_error_log("connect to '%s' failure: %s (%d)\n",
                               c->addr.addr, strerror(errno), errno);
                close(sockfd);
                return;
            }
            if (errno != EINPROGRESS) {
                ac_error_log("connect to '%s' failure: %s (%d)\n",
                               c->addr.addr, strerror(errno), errno);
                goto error_exit;
            }

            c->status = AC_CONN_CONNECTING;
          }
          else
            c->status = AC_CONN_OK;

          uv_pipe_open((uv_pipe_t*)c->io_stream, sockfd);
    }

    if (c->status == AC_CONN_CONNECTING)
        c->event_status = (AC_EVENT_TIMEOUT | AC_EVENT_WRITE);
    else
        c->event_status = (AC_EVENT_TIMEOUT | AC_EVENT_READ);

    ac_debug_log("reconnect to '%s' success, connection=%p\n",
                   c->addr.addr, c);

    ac_connection_uv_start(c);
    return;
error_exit:
    c->auto_reconn = 0;
    ac_connection_destroy(c);
}

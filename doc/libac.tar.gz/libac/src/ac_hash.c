#include "ac_hash.h"

/**
 * 创建一ac_hash_t
 */
ac_hash_t *ac_hash_create(uint32_t size, int offset)
{
    ac_hash_t         *table;
    ac_hash_list_t    **buckets;
    uint32_t            n;

    // 2 ^ m
    n = 4;
    size &= 0x7fffffff;

    while(size > n) n <<= 1;

    // alloc
    buckets = (ac_hash_list_t **)taw_malloc("ac_hash_list_t*", n * sizeof(ac_hash_list_t *),0);
    table = (ac_hash_t *)taw_malloc("ac_hash_t", sizeof(ac_hash_t),0);

    if (table == NULL || buckets == NULL)
        return NULL;

    table->buckets = buckets;
    table->size = n;
    table->mask = n - 1;
    table->count = 0;
    table->offset = offset;
    table->seqno = 1;
    ac_list_init(&table->list);


    return table;
}
void ac_hash_destroy(ac_hash_t *table)
{
    if(table && table->buckets)
        taw_free(table->buckets);
    if(table)
        taw_free(table);
    table = NULL;
}

int ac_hash_add(ac_hash_t *table, uint64_t key, ac_hash_list_t *list)
{
    uint64_t            n;
    ac_hash_list_t    *first;

    n = ac_hash_key(key);
    n &= table->mask;

    // init
    list->key = key;
    table->count ++;
    table->seqno ++;

    // add to list
    first = table->buckets[n];
    list->next = first;

    if (first)
        first->pprev = &list->next;

    table->buckets[n] = (ac_hash_list_t *)list;
    list->pprev = &(table->buckets[n]);

    return 0;
}

void *ac_hash_find(ac_hash_t *table, uint64_t key)
{
    uint64_t            n;
    ac_hash_list_t    *list;

    n = ac_hash_key(key);
    n &= table->mask;
    list = table->buckets[n];

    // foreach
    while(list) {
        if (list->key == key) {
            return ((char *)list - table->offset);
        }

        list = list->next;
    }

    return NULL;
}

void *ac_hash_find_ex(ac_hash_t *table, uint64_t key, ac_hash_cmp_pt cmp, const void *a)
{
    uint64_t            n;
    ac_hash_list_t    *list;

    n = ac_hash_key(key);
    n &= table->mask;
    list = table->buckets[n];

    // foreach
    while(list) {
        if (list->key == key) {
            if (cmp(a, ((char *)list - table->offset)) == 0)
                return ((char *)list - table->offset);
        }

        list = list->next;
    }

    return NULL;
}

void *ac_hash_del(ac_hash_t *table, uint64_t key)
{
    uint64_t            n;
    ac_hash_list_t    *list;

    n = ac_hash_key(key);
    n &= table->mask;
    list = table->buckets[n];

    // foreach
    while(list) {
        if (list->key == key) {
            ac_hash_del_node(list);
            table->count --;

            return ((char *)list - table->offset);
        }

        list = list->next;
    }

    return NULL;
}

int ac_hash_del_node(ac_hash_list_t *node)
{
    ac_hash_list_t    *next, **pprev;

    if (!node->pprev)
        return 0;

    next = node->next;
    pprev = node->pprev;
    *pprev = next;

    if (next) next->pprev = pprev;

    node->next = NULL;
    node->pprev = NULL;

    return 1;
}

int ac_hash_dlist_add(ac_hash_t *table, uint64_t key, ac_hash_list_t *hash, ac_list_t *list)
{

    ac_list_add_tail(list,&table->list);
    return ac_hash_add(table, key, hash);
}

void *ac_hash_dlist_del(ac_hash_t *table, uint64_t key)
{
    char                *object;

    if ((object = (char *)ac_hash_del(table, key)) != NULL) {
        ac_list_del(( ac_list_t *)(object + table->offset + sizeof(ac_hash_list_t)));

    }

    return object;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// hash 64 bit
uint64_t ac_hash_key(volatile uint64_t key)
{
    void *ptr = (void *) &key;
    return ac_hash_code(ptr, sizeof(uint64_t), 5);
}

uint64_t ac_hash_code(const void *key, int len, unsigned int seed)
{
    const uint64_t m = __UINT64_C(0xc6a4a7935bd1e995);
    const int r = 47;

    uint64_t h = seed ^ (len * m);

    const uint64_t *data = (const uint64_t *)key;
    const uint64_t *end = data + (len / 8);

    while(data != end) {
        uint64_t k = *data++;

        k *= m;
        k ^= k >> r;
        k *= m;

        h ^= k;
        h *= m;
    }

    const unsigned char *data2 = (const unsigned char *)data;

    switch(len & 7) {
    case 7:
        h ^= (uint64_t)(data2[6]) << 48;

    case 6:
        h ^= (uint64_t)(data2[5]) << 40;

    case 5:
        h ^= (uint64_t)(data2[4]) << 32;

    case 4:
        h ^= (uint64_t)(data2[3]) << 24;

    case 3:
        h ^= (uint64_t)(data2[2]) << 16;

    case 2:
        h ^= (uint64_t)(data2[1]) << 8;

    case 1:
        h ^= (uint64_t)(data2[0]);
        h *= m;
    };

    h ^= h >> r;

    h *= m;

    h ^= h >> r;

    return h;
}

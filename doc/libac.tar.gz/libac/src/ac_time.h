#ifndef AC_TIME_H_
#define AC_TIME_H_

#include <stdio.h>
#include <stdarg.h>
#include <time.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>



/**
 * time的通用函数
 */


int ac_localtime(const time_t *t, struct tm *tp);
int64_t ac_time_now();



#endif//AC_TIME_H_

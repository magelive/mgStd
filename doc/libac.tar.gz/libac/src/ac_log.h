#ifndef AC_LOG_H_
#define AC_LOG_H_

/**
 * 简单的log输出
 */


#include "ac_thread_pool.h"
#include "ac_time.h"

typedef void (*ac_log_print_pt)(const char *message);
typedef enum {
    AC_LOG_OFF = 1,
    AC_LOG_FATAL,
    AC_LOG_ERROR,
    AC_LOG_WARN,
    AC_LOG_INFO,
    AC_LOG_DEBUG,
    AC_LOG_TRACE,
    AC_LOG_ALL
} ac_log_level_t;

#define ac_fatal_log(format, args...) if(ac_log_level>=AC_LOG_FATAL)      \
        ac_log_common(__FILE__, __LINE__, format, ## args);
#define ac_error_log(format, args...) if(ac_log_level>=AC_LOG_ERROR)      \
        ac_log_common(__FILE__, __LINE__, format, ## args);
#define ac_warn_log(format, args...) if(ac_log_level>=AC_LOG_WARN)        \
        ac_log_common(__FILE__, __LINE__, format, ## args);
#define ac_info_log(format, args...) if(ac_log_level>=AC_LOG_INFO)        \
        ac_log_common(__FILE__, __LINE__, format, ## args);
#define ac_debug_log(format, args...) if(ac_log_level>=AC_LOG_DEBUG)      \
        ac_log_common(__FILE__, __LINE__, format, ## args);
#define ac_trace_log(format, args...) if(ac_log_level>=AC_LOG_TRACE)      \
        ac_log_common(__FILE__, __LINE__, format, ## args);

// 打印backtrace
#define ac_PRINT_BT(format, args...)                                                        \
    {char _buffer_stack_[256];{void *array[10];int i, idx=0, n = backtrace(array, 10);        \
            for (i = 0; i < n; i++) idx += snprintf(idx+_buffer_stack_, 25, "%p ", array[i]);}\
        ac_log_common(__FILE__, __LINE__, "%s" format, _buffer_stack_, ## args);}

extern ac_log_level_t ac_log_level;
extern void ac_log_set_print(ac_log_print_pt p);
extern void ac_log_common(const char *file, int line, const char *fmt, ...);
extern void ac_log_print_default(const char *message);



#endif //AC_LOG_H_

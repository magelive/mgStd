#ifndef AC_UTHREAD_H_
#define AC_UTHREAD_H_

#include <stddef.h>
#include <stdlib.h>

#include "ac_struct.h"
#include <stdio.h>
#include "ac_thread_pool.h"
#include "ac_log.h"
#include <ucontext.h>

/**
 * 用户态线程
 */


#define AC_UTHREAD_STACK         65536


// 函数
void ac_uthread_init(ac_uthread_control_t *control);
void ac_uthread_destroy();
ac_uthread_t *ac_uthread_create(ac_uthread_start_pt *start, void *args, int stack_size);
ac_uthread_t *ac_uthread_current();
int ac_uthread_yield();
int ac_uthread_scheduler();
void ac_uthread_stop();
void ac_uthread_ready(ac_uthread_t *t);
void ac_uthread_switch();
void ac_uthread_needstack(int n);
void ac_uthread_ready(ac_uthread_t *t);
void ac_uthread_print(int sig);
int ac_uthread_get_errcode();
void ac_uthread_set_errcode(ac_uthread_t *t, int errcode);
void ac_io_on_uthread_start(void *args);
void ac_io_on_uthread_uvstart(void *args);
void ac_acio_set_uthread_start(ac_io_t *acio, ac_io_uthread_start_pt *on_utstart, void *args);
int ac_client_uthread_wait_conn(ac_connection_t *c);
int ac_client_uthread_wait_session(ac_session_t *s);
void ac_client_uthread_set_handler(ac_handler_pt *handler);
int ac_client_uthread_wakeup_conn(ac_connection_t *c);
int ac_client_uthread_wakeup_session(ac_request_t *r);

//////////////////////
// 下面对main的处理
#define AC_UTHREAD_RUN_MAIN(main_name)                                                \
    static int     ac_uthread_stacksize = 0;                                          \
    static int     ac_uthread_argc;                                                   \
    static char    **ac_uthread_argv;                                                 \
    static void ac_uthread_mainstart(void *v)                                         \
    {                                                                                   \
        main_name(ac_uthread_argc, ac_uthread_argv);                                \
    }                                                                                   \
    int main(int argc, char **argv)                                                     \
    {                                                                                   \
        int ret; struct sigaction sa, osa;                                              \
        ac_uthread_control_t control;                                                 \
        memset(&sa, 0, sizeof sa);                                                      \
        sa.sa_handler = ac_uthread_print;                                             \
        sa.sa_flags = SA_RESTART;                                                       \
        sigaction(SIGQUIT, &sa, &osa);                                                  \
        ac_uthread_argc = argc;                                                       \
        ac_uthread_argv = argv;                                                       \
        if (ac_uthread_stacksize == 0) ac_uthread_stacksize = 256*1024;             \
        ac_uthread_init(&control);                                                    \
        ac_uthread_create(ac_uthread_mainstart, NULL, ac_uthread_stacksize);      \
        ret = ac_uthread_scheduler();                                                 \
        ac_uthread_destroy();                                                         \
        return ret;                                                                     \
    }



#endif /* AC_UTHREAD_H_ */

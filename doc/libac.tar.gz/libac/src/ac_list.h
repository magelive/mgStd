#ifndef AC_LIST_H_
#define AC_LIST_H_

/**
 * 列表，参考kernel上的list.h
 */


// from kernel list
typedef struct ac_list_t ac_list_t;

struct ac_list_t {
    ac_list_t *next, *prev;
};

#define AC_LIST_HEAD_INIT(name) {&(name), &(name)}
#define ac_list_init(ptr) do {                \
        (ptr)->next = (ptr);                    \
        (ptr)->prev = (ptr);                    \
    } while (0)

static inline void __ac_list_add(ac_list_t *list,
                                   ac_list_t *prev, ac_list_t *next)
{
    next->prev = list;
    list->next = next;
    list->prev = prev;
    prev->next = list;
}
// list head to add it after
static inline void ac_list_add_head(ac_list_t *list, ac_list_t *head)
{
    __ac_list_add(list, head, head->next);
}
// list head to add it before
static inline void ac_list_add_tail(ac_list_t *list, ac_list_t *head)
{
    __ac_list_add(list, head->prev, head);
}
static inline void __ac_list_del(ac_list_t *prev, ac_list_t *next)
{
    next->prev = prev;
    prev->next = next;
}
// deletes entry from list
static inline void ac_list_del(ac_list_t *entry)
{
    __ac_list_del(entry->prev, entry->next);
    ac_list_init(entry);
}
// tests whether a list is empty
static inline int ac_list_empty(const ac_list_t *head)
{
    return (head->next == head);
}
// move list to new_list
static inline void ac_list_movelist(ac_list_t *list, ac_list_t *new_list)
{
    if (!ac_list_empty(list)) {
        new_list->prev = list->prev;
        new_list->next = list->next;
        new_list->prev->next = new_list;
        new_list->next->prev = new_list;
        ac_list_init(list);
    } else {
        ac_list_init(new_list);
    }
}
// join list to head
static inline void ac_list_join(ac_list_t *list, ac_list_t *head)
{
    if (!ac_list_empty(list)) {
        ac_list_t *first = list->next;
        ac_list_t *last = list->prev;
        ac_list_t *at = head->prev;

        first->prev = at;
        at->next = first;
        last->next = head;
        head->prev = last;
    }
}

// get last
#define ac_list_get_last(list, type, member)                              \
    ac_list_empty(list) ? NULL : ac_list_entry((list)->prev, type, member)

// get first
#define ac_list_get_first(list, type, member)                             \
    ac_list_empty(list) ? NULL : ac_list_entry((list)->next, type, member)

#define ac_list_entry(ptr, type, member) ({                               \
        const typeof( ((type *)0)->member ) *__mptr = (ptr);                \
        (type *)( (char *)__mptr - offsetof(type,member) );})

#define ac_list_for_each_entry(pos, head, member)                         \
    for (pos = ac_list_entry((head)->next, typeof(*pos), member);         \
            &pos->member != (head);                                         \
            pos = ac_list_entry(pos->member.next, typeof(*pos), member))

#define ac_list_for_each_entry_safe(pos, n, head, member)                 \
    for (pos = ac_list_entry((head)->next, typeof(*pos), member),         \
            n = ac_list_entry(pos->member.next, typeof(*pos), member);    \
            &pos->member != (head);                                         \
            pos = n, n = ac_list_entry(n->member.next, typeof(*n), member))



#endif//AC_LIST_H_

#ifndef AC_UTIL_H_
#define AC_UTIL_H_


#include <stddef.h>
#include <stdlib.h>

#include "ac_struct.h"
#include <stdio.h>
#include "ac_thread_pool.h"
#include "ac_log.h"

/**
 * Async Comm通用函数
 */


///////////////////////////////////////////////////////////////////////////WORKER
//worker线程的唤醒的回调程序
void ac_request_on_wakeup(uv_async_t *handle);

//worker线程处理请求request
void ac_request_doreq(ac_request_thread_t *th, ac_list_t *request_list);

//worker线程处理待发请求session
void ac_request_dosess(ac_request_thread_t *th, ac_list_t *session_list);

//worker处理完请求，唤醒io线程把结果发出去
void ac_request_wakeup_ioth(ac_io_t *acio, char *ioth_flag, ac_list_t *ioth_list);


//////////////////////////////////////////////////////////////////////////////message


//创建一个message
ac_message_t *ac_message_create(ac_connection_t *c);

//销毁一个message
void ac_message_destroy(ac_message_t *m, int del);

//调用encode，并将请求加入ac_connect_t中
int ac_connection_session_build(ac_session_t *s);

//调用session的回调函数process
int ac_session_process(ac_session_t *s, int stop);

//销毁ac_connection_t对象,调用on_disconnect
void ac_connection_destroy(ac_connection_t *c);

//销毁掉ac_request_t对象,调用cleanup
void ac_request_server_done(ac_request_t *r);

//服务器处理请求
int ac_connection_do_request(ac_message_t *m);

//客户端处理响应
int ac_connection_do_response(ac_message_t *m);

//没有收完一个消息，循环接受
ac_message_t *ac_connection_recycle_message(ac_message_t *m);

//销毁一个io线程
void ac_io_thread_destroy(ac_io_thread_t *ioth);

//////////////////////////////////////////////////////////////////////////////util

//内存分配函数
void ac_malloc_cb(uv_handle_t* handle,size_t suggested_size,uv_buf_t* buf);

//得到packet的id
uint64_t ac_connection_get_packet_id(ac_connection_t *c, void *packet, int flag);

//io线程启动函数
void *ac_io_on_thread_start(void *args);

//io异步唤醒回调函数
void ac_connect_wakeup_cb(uv_async_t* handle);

//server 接受连接回调函数
void ac_connection_on_accept_cb(uv_stream_t *server, int status);

//读事件回调函数
void ac_read_cb(uv_stream_t* stream,ssize_t nread,const uv_buf_t* buf);

//UDP读事件回调函数
void ac_recv_cb(uv_udp_t* handle,ssize_t nread,const uv_buf_t* buf,
                    const struct sockaddr* addr,unsigned flags);

//异步listen切换回调函数
void ac_listen_change_cb(uv_async_t* handle);

//异步触发write事件回调函数
void ac_connection_on_writable(uv_async_t *handle);

//tcp连接accept回调函数
//void ac_io_on_accept_cb(uv_stream_t* server, int status);

//socket写数据回调函数
//void ac_write_cb(uv_handle_t* req, int status);


// 处理超时的message的回调函数
void ac_connection_on_timeout_mesg(uv_timer_t* handle);

//io线程开始读
void ac_connection_uv_start(ac_connection_t *c);

// add addr
int ac_client_list_add(ac_hash_t *table, ac_addr_t *addr, ac_hash_list_t *list);

//通过zip获得client指针
void *ac_client_list_find(ac_hash_t *table, ac_addr_t *addr);

//将连接加入到连接链表中
void ac_connection_add_list(ac_connection_list_t *wlist, ac_connection_t *c);

//生成Client
ac_connection_t *ac_connection_do_client(ac_session_t *s);

//生成连接
int ac_connection_do_connect(ac_client_t *client);

//完成请求，引用计数减一
void ac_request_client_done(ac_request_t *r);

//生成一个连接对象
ac_connection_t *ac_connection_new();

//session_timeout
void ac_connection_wakeup_session(ac_connection_t *c);

//把ac_list_t上的内容通过uv_write写到socket上
int ac_socket_write(uv_handle_t* fd, ac_list_t *l);

//发送回复内容
int ac_connection_send_response(ac_list_t *request_list);

//Server将处理完的数据encode
int ac_connection_request_done(ac_request_t *r);

//为了均衡，切换到其他线程
void ac_connection_redispatch_thread(ac_connection_t *c);

//serve端生成connection对象
int ac_connection_server_new_connect(uv_handle_t *stream, ac_listen_t *listen);

//client端生成connection对象
int ac_connection_client_new_connect(uv_handle_t *stream, ac_client_t *client);


//把connection上的output的buffer写到socket上
int ac_connection_write_socket(ac_connection_t *c);

// 判断write again
int ac_connection_write_again(ac_connection_t *c);

//地址解析
int ac_addr_parse(const char *addr, ac_addr_t *ac_addr);

//client端数据完成之后的回调，用于同步发送
int ac_client_send_handler(ac_request_t *r);

void ac_client_wait(ac_client_wait_t *w, int count);

void ac_client_wait_wakeup(ac_client_wait_t *w);

//udp 线程server开始读写
void ac_connection_on_accept_udp(ac_listen_t * listen);

//建立连接
ac_connection_t *ac_connection_connect_thread( char* addr,
        ac_handler_pt *handler, int conn_timeout, void *args, int autoconn);

// init
void ac_client_wait_init(ac_client_wait_t *w);

//thread发送packet的时候用, 同步, 等待返回结果
void *ac_client_send(ac_io_t *acio,const char * addr, ac_session_t *s);

//调用uv的异步写数据
//int ac_socket_writuv(uv_stream_t *fd, ac_list_t *l, uv_buf_t *iovs, int cnt);

//调用writev同步的写数据
int ac_socket_chain_writev(uv_handle_t *fd, ac_list_t *l, struct iovec *iovs, int cnt, int *again);
//sendfile
int ac_socket_sendfile(uv_handle_t *fd, ac_file_buf_t *fb, int *again);

//设置非阻塞
int _nonblock(int fd, int set);

//不传给新进程
int _cloexec(int fd, int set);

//对超时的conn处理
void ac_connection_on_timeout_conn(uv_timer_t* handle);

//自动重连
void ac_connection_autoconn(ac_connection_t *c);
#endif /* AC_UTIL_H_ */

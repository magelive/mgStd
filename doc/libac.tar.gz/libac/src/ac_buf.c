#include <stdarg.h>
#include "ac_buf.h"
#include "ac_struct.h"
/**
 * 创建一个新的ac_buf_t
 */
ac_buf_t *ac_buf_create( uint32_t size)
{
    ac_buf_t          *b;

    if ((b = (ac_buf_t *)taw_malloc("ac_buf_t", sizeof(ac_buf_t),0)) == NULL)
        return NULL;

    memset(b,0,sizeof(ac_buf_t));

    if ((b->start = (char *)taw_malloc("buf", size,0)) == NULL)
        return NULL;

    b->pos = b->start;
    b->last = b->start;
    b->end = b->last + size;
    b->cleanup = NULL;
    ac_list_init(&b->node);

    return b;
}

/**
 * 把data包成ac_buf_t
 */
ac_buf_t *ac_buf_pack( const void *data, uint32_t size)
{
    ac_buf_t          *b;

    if ((b = (ac_buf_t *)taw_malloc("ac_buf_t",sizeof(ac_buf_t),0)) == NULL)
        return NULL;

    ac_buf_set_data( b, data, size);

    return b;
}

/**
 * 设置数据到b里
 */
void ac_buf_set_data( ac_buf_t *b, const void *data, uint32_t size)
{
    b->pos = (char *)data;
    b->last = b->pos + size;
    b->end = b->last;
    b->cleanup = NULL;
    b->flags = 0;
    ac_list_init(&b->node);
}

/**
 * 创建一个ac_file_buf_t, 用于sendfile等
 */
ac_file_buf_t *ac_file_buf_create()
{
    ac_file_buf_t     *b;

    b = (ac_file_buf_t *)taw_malloc("buf", sizeof(ac_file_buf_t),0);
    b->flags = AC_BUF_FILE;
    b->cleanup = NULL;
    ac_list_init(&b->node);

    return b;
}

void ac_file_buf_set_close(ac_file_buf_t *b)
{
    if ((b->flags & AC_BUF_FILE))
        b->flags = AC_BUF_CLOSE_FILE;
}

void ac_buf_set_cleanup(ac_buf_t *b, ac_buf_cleanup_pt *cleanup, void *args)
{
    b->cleanup = cleanup;
    b->args = args;
}

void ac_buf_destroy(ac_buf_t *b)
{
    if(b==NULL)
        return;
    ac_buf_cleanup_pt         *cleanup;
    ac_list_del(&b->node);

    if ((b->flags & AC_BUF_CLOSE_FILE) == AC_BUF_CLOSE_FILE)
        close(((ac_file_buf_t *)b)->fd);

    // cleanup
    if ((cleanup = b->cleanup)) {
        b->cleanup = NULL;
        (*cleanup)(b, b->args);
    }
    if(b->start)
        taw_free(b->start);

    b->start=NULL;
    taw_free(b);
    b=NULL;
}

/**
 * 空间不够,分配出一块来,保留之前的空间
 */
int ac_buf_check_read_space(ac_buf_t *b, uint32_t size)
{
    int             dsize;
    char            *ptr;

    if ((b->end - b->last) >= (int)size)
        return AC_OK;

    // 需要大小
    dsize = (b->last - b->pos);
   // size = ac_align(size + dsize, AC_POOL_PAGE_SIZE);

    // alloc
    if ((ptr = (char *)taw_malloc("buf", size+dsize,0)) == NULL)
        return AC_ERROR;

    // copy old buf to new buf
    if (dsize > 0)
        memcpy(ptr, b->pos, dsize);

    taw_free(b->start);

    b->start = ptr;
    b->pos = ptr;
    b->last = b->pos + dsize;
    b->end = b->pos + size;

    return AC_OK;
}

/**
 * 空间不够,分配出一块来,保留之前的空间
 */
ac_buf_t *ac_buf_check_write_space(ac_list_t *bc, uint32_t size)
{
    ac_buf_t          *b = ac_list_get_last(bc, ac_buf_t, node);

    if (b != NULL && (b->end - b->last) >= (int)size)
        return b;

    // 重新生成一个buf,放入buf_chain_t中
    size = ac_align(size, AC_POOL_PAGE_SIZE);

    if ((b = ac_buf_create( size)) == NULL)
        return NULL;

    ac_list_add_tail(&b->node, bc);

    return b;
}

/**
 * 清除掉
 */
void ac_buf_chain_clear(ac_list_t *l)
{

    ac_buf_t          *b, *b1;

    ac_list_for_each_entry_safe(b, b1, l, node) {
        ac_buf_destroy(b);
    }
    ac_list_init(l);
}

/**
 * 加到后面
 */
void ac_buf_chain_offer(ac_list_t *l, ac_buf_t *b)
{
    if (!l->next) ac_list_init(l);

    ac_list_add_tail(&b->node, l);
}

/**
 * 把s复制到d上
 */
int ac_buf_string_copy(ac_buf_string_t *d, ac_buf_string_t *s)
{
    if (s->len > 0) {
        d->data = (char *)taw_malloc("buf", s->len,0);
        memcpy(d->data, s->data, s->len);
        d->len = s->len;
    }

    return s->len;
}

int ac_buf_string_printf( ac_buf_string_t *d, const char *fmt, ...)
{
    int             len;
    char            buffer[2048];

    va_list args;
    va_start(args, fmt);
    len = vsnprintf(buffer, 2048, fmt, args);
    va_end(args);
    d->data = (char *)taw_malloc("buf", len + 1,0);
    memcpy(d->data, buffer, len);
    d->data[len] = '\0';
    d->len = len;
    return len;
}


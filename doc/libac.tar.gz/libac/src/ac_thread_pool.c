/*
* Copyright(C) 2011-2012 Alibaba Group Holding Limited
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License version 2 as
* published by the Free Software Foundation.
*/

#include "ac_struct.h"
#include "ac_log.h"
#include "ac_thread_pool.h"


__thread ac_baseth_t *ac_baseth_self = NULL;
//static void ac_thread_pool_invoke(struct ev_loop *loop);

/**
 * start
 */
void *ac_thread_on_start(void *args)
{
    ac_baseth_t       *th;
    th = (ac_baseth_t *) args;
    ac_baseth_self = th;
    uv_run(th->loop, 0);
    ac_baseth_self = NULL;

    return (void *)NULL;
}

/**
 * wakeup
 */
void ac_thread_on_wakeup(void *args)
{
    ac_baseth_t *th = (ac_baseth_t *)args;

    //ac_spin_lock(&th->thread_lock);
    uv_async_send(&th->thread_watcher);
    //ac_spin_unlock(&th->thread_lock);
}



void ac_thread_init(void *args, ac_thread_pool_t *tp,
                      ac_thread_on_start_pt *start, uv_async_cb wakeup)
{
    ac_baseth_t *th = (ac_baseth_t *)args;
    th->idx = (((char *)(th)) - (&(tp)->data[0])) / (tp)->member_size;
    th->on_start = start;

    tawstd_atomic32_init(&th->thread_lock);
    uv_async_init (th->loop,&th->thread_watcher, wakeup);
    th->thread_watcher.data = th;
    th->loop->data = th;

}

///////////////////////////////////////////////////////////////////////////////////////////////////
/**
 * ´´½¨Ò»¸öthread pool
 */
ac_thread_pool_t *ac_thread_pool_create(ac_io_t *acio, int thread_count, int member_size)
{
    ac_baseth_t           *th;
    ac_thread_pool_t      *tp;
    int                     size;

    size = sizeof(ac_thread_pool_t) + member_size * thread_count;

    if ((tp = (ac_thread_pool_t *) taw_malloc("ac_thread_pool_t", size,0)) == NULL)
        return NULL;

    tp->thread_count = thread_count;
    tp->member_size = member_size;
    tp->last = &tp->data[0] + member_size * thread_count;
    ac_list_add_tail(&tp->list_node,&acio->thread_pool_list);

    ac_thread_pool_for_each(th, tp, 0) {
        th->acio = acio;
    }
    tawstd_atomic32_init(&tp->last_number);
    return tp;
}

/**
 * wakeup pool
 */
void ac_thread_pool_on_wakeup(ac_thread_pool_t *tp)
{
    ac_baseth_t       *th;
    ac_thread_pool_for_each(th, tp, 0) {
        ac_thread_on_wakeup(th);
    }
}

/**
 * destroy pool
 */

void ac_thread_pool_destroy(ac_thread_pool_t *tp)
{
    ac_baseth_t       *th;

    ac_thread_pool_for_each(th, tp, 0) {
            uv_loop_close(th->loop);
    }
    taw_free(tp);
}



void ac_thread_pool_wakeup_session(ac_baseth_t *th)
{
    if (th->iot == 0)
        return;

    ac_connection_t       *c, *c1;
    ac_session_t          *s, *s1;
    ac_io_thread_t        *ioth = (ac_io_thread_t *) th;

    // session at ioth
    ac_spin_lock(&ioth->thread_lock);

    ac_list_for_each_entry_safe(s, s1, &ioth->session_list, session_list_node) {
        ac_list_del(&s->session_list_node);

        if (s->status == 0) ac_session_process(s, 0);
    }
    // connection at ioth
    ac_list_for_each_entry_safe(c, c1, &ioth->conn_list, conn_list_node) {
        ac_connection_wakeup_session(c);
    }
    // foreach connected_list
    ac_list_for_each_entry_safe(c, c1, &ioth->connected_list, conn_list_node) {
        ac_connection_wakeup_session(c);
    }
    ac_spin_unlock(&ioth->thread_lock);
}




#ifndef ASYNCOMM_H_
#define ASYNCOMM_H_


#include <stddef.h>
#include <stdlib.h>

#include "ac_struct.h"
#include <stdio.h>
#include "ac_thread_pool.h"
#include "ac_log.h"

#define ac_thread_self ((ac_io_thread_t*) ac_baseth_self)
#define ac_session_set_args(s, a)     (s)->r.args = (void*)a
#define ac_session_set_timeout(s, t)  (s)->timeout = t
#define ac_request_set_wobj(r, w)     (r)->request_list_node.prev = (ac_list_t *)w
#define ac_session_set_wobj(s, w)     ac_request_set_wobj(&((s)->r), w)
#define ac_client_set_wobj(c, w)     (c)->ac_client_node.prev = (ac_list_t *)w
#define ac_session_set_request(s, p, t, a)                \
    (s)->r.opacket = (void*) p;                             \
    (s)->r.args = (void*)a; (s)->timeout = t;
#define ac_session_packet_create(type, s, size)           \
    ((s = ac_session_create(size + sizeof(type))) ? ({    \
        memset(&((s)->data[0]), 0, sizeof(type));           \
        (s)->r.opacket = &((s)->data[0]);                   \
        (type*) &((s)->data[0]);}) : NULL)

#define ac_session_class_create(type, s, ...)             \
    ((s = ac_session_create(sizeof(type))) ? ({           \
        new(&((s)->data[0]))type(__VA_ARGS__);              \
        (s)->r.opacket = &((s)->data[0]);                   \
        (type*) &((s)->data[0]);}) : NUL

#define IF_UTHREAD_YIELD                                  \
    if (ac_thread_self->acio->uthread_enable)             \
        ac_uthread_yield();
       // while(ac_uthread_yield() > 0);

#define ac_io_create(cnt)                         ac_acio_create(ac_io_var, cnt)
#define ac_io_start()                             ac_acio_start(ac_io_var)
#define ac_io_wait()                              ac_acio_wait(ac_io_var)
#define ac_io_stop()                              ac_acio_stop(ac_io_var)
#define ac_io_destroy()                           ac_acio_destroy(ac_io_var)
#define ac_io_thread_loop(a)                      ac_acio_thread_loop(ac_io_var,a)
#define ac_io_set_uthread_start(start,args)       ac_acio_set_uthread_start(ac_io_var,start,args)
#define ac_io_stat_watcher_start(a1,a2,a3,a4)     ac_acio_stat_watcher_start(ac_io_var,a1,a2,a3,a4)
#define ac_io_listen(host,port,handler,conn_flag) ac_listen(ac_io_var,host,port,handler,conn_flag)
//#define ac_io_connect(addr,handler,t,args)        ac_connection_connect(ac_io_var,addr,handler,t,args,0)
#define ac_io_connect_thread(addr,h,t,args)       ac_connection_connect_thread(addr,h,t,args,0)
#define ac_io_disconnect(addr)                    ac_connection_disconnect(ac_io_var,addr)
//#define ac_io_disconnect_thread(addr)             ac_connection_disconnect_thread(ac_io_var,addr)
#define ac_request_thread_create(cnt, cb, args)   ac_work_thread_pool_create(ac_io_var, cnt, cb, args)
#define ac_io_send_request(addr,s)                ac_client_send_request(ac_io_var,addr,s)
#define ac_io_send(addr,s)                        ac_client_send(ac_io_var,addr,s);

extern __thread ac_baseth_t *ac_baseth_self;//bath线程
extern ac_io_t *ac_io_var;//全局默认的ac_io_t

/////////////////////////////////////////////////////////////////////////////ac_io
//初始化ac_io_t
ac_io_t * ac_acio_create(ac_io_t *acio, int io_thread_count);

//停止ac_io
int ac_acio_stop(ac_io_t *acio);

//启动io线程
int ac_acio_start(ac_io_t * acio);

//等待io线程结束
int ac_acio_wait(ac_io_t *acio);

//销毁acio
int ac_acio_destroy(ac_io_t *acio);
////////////////////////////////////////////////////////////////////////////server
//server调用,设置listen
//tcp_ipv4://192.168.79.200:55555
//udp_ipv6://fe80::20c:29fe:fe9b:547e:55555
//ipc:///home/myfilepath
ac_listen_t *ac_listen(ac_io_t *acio, const char *addr,  ac_handler_pt *handler);


ac_listen_t *ac_listen_ex(ac_io_t *acio, char *addr, int port, ac_handler_pt *handler,int conn_flag);
/////////////////////////////////////////////////////////////////////////////client

//client调用,连接server
//tcp_ipv4://192.168.79.200:55555
//udp_ipv6://fe80::20c:29fe:fe9b:547e:55555
//ipc:///home/myfilepath
int ac_connect(ac_io_t *acio, const char *addr, ac_handler_pt *handler, int conn_timeout, void *args, int autoconn);

//client异步发送请求
int ac_client_send_request(ac_io_t *acio,  const char *addr_str, ac_session_t *s);

//发出断开连接的请求
int ac_connection_disconnect(ac_io_t *acio, const char *addr);

//////////////////////////////////////////////////////////////////////////////work thread

// 长任务初始化工作线程池，使用默认worker线程启动函数
ac_thread_pool_t *ac_work_thread_pool_create(ac_io_t *acio, int cnt, ac_request_process_pt *cb, void *args);

// 初始化工作线程池,自定义worker线程启动函数
ac_thread_pool_t *ac_thread_pool_create_ex(ac_io_t *acio, int cnt,
        ac_baseth_on_start_pt *start, ac_request_process_pt *cb, void *args);

//将请求加入到worker线程队列中,hv是hash_key值
int ac_thread_pool_push(ac_thread_pool_t *tp, ac_request_t *r, uint64_t hv);

//将需要发送的buffer加到c->output上
void ac_request_addbuf(ac_request_t *r, ac_buf_t *b);

//将需要发送的bufferlist加到c->output上
void ac_request_addbuf_list(ac_request_t *r, ac_list_t *list);

//////////////////////////////////////////////////////////////////////////////message

//创建一个需要发出去的请求session
ac_session_t *ac_session_create(int size);

//销毁一个session
void ac_session_destroy(void *data);

//io线程发送请求LIST
int ac_connection_send_session_list(ac_list_t *list);

//io线程发送请求
int ac_connection_send_session(ac_connection_t *c, ac_session_t *s);

//信号处理
void ac_signal_handler(int sig);

//速度定时器
void ac_acio_stat_watcher_start(ac_io_t *acio, uv_timer_t *stat_watcher, double interval,
                                 ac_io_stat_t *iostat, ac_io_stat_process_pt *process);

//速度统计的定时回调函数
void ac_io_stat_process(uv_timer_t* handle);

void ac_io_print_status(ac_io_t *acio);


#endif /* ASYNCOMM_H_ */

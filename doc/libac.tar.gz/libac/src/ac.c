#include <ngtawstd/zytypes.h>
#include <ngtawstd/mem.h>

#include "ac.h"
#include "ac_util.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <netinet/in.h>
#include <sys/un.h>
#include "ac_uthread.h"

// 全局变量

ac_io_t *ac_io_var =NULL;
tawstd_atomic32_t ac_io_list_lock = TAWSTD_ATOMIC32_INIT(0);
ac_list_t ac_io_list_var = AC_LIST_HEAD_INIT(ac_io_list_var);


ac_io_t * ac_acio_create(ac_io_t* acio, int io_thread_count){
     ac_debug_log("ac_acio_start io_thread_count=%d",io_thread_count);

    ac_io_thread_t        *ioth;
    ac_thread_pool_t      *tp;
    int                     v;

    if (io_thread_count <= 0 || io_thread_count > AC_MAX_THREAD_CNT)
        io_thread_count = sysconf(_SC_NPROCESSORS_CONF); //获得内核数

    acio = (ac_io_t *)taw_malloc("ac_io_t",sizeof(ac_io_t),0);
    if(acio == NULL)
    {
        return NULL;
    }
        // 初始化
    memset(acio, 0, sizeof(ac_io_t));

    ac_io_var = acio;

    acio->io_thread_count = io_thread_count;

    //acio->loop = uv_default_loop();
    acio->start_time = uv_now(uv_default_loop());
    ac_list_init(&acio->thread_pool_list);


   // ev_set_allocator(ac_pool_realloc);

    // 创建IO线程池
    tp = ac_thread_pool_create(acio, io_thread_count, sizeof(ac_io_thread_t));

    if (tp == NULL){
        ac_acio_destroy(acio);
        return NULL;
    }

    acio->io_thread_pool = tp;
    acio->thread_pool = NULL;
    acio->tcp_nodelay = 1;
    acio->affinity_enable = 1;
    tawstd_atomic32_init(&acio->lock);
    tawstd_atomic64_init(&acio->send_byte);
    tawstd_atomic64_init(&acio->recv_byte);
    tawstd_atomic32_init(&acio->connect_num);
    // 初始化线程池
    ac_thread_pool_for_each(ioth, tp, 0) {

        ac_list_init(&ioth->connected_list);
        v = offsetof(ac_client_t, client_list_node);
        ioth->client_list = ac_hash_create( AC_MAX_CLIENT_CNT / io_thread_count, v);
        ac_list_init(&ioth->client_array);


        // 起异步事件
        ac_list_init(&ioth->conn_list);
        ac_list_init(&ioth->session_list);
        ac_list_init(&ioth->request_list);


        ioth->loop = uv_loop_new();
        ioth->listen_watcher.data = ioth;
        uv_async_init(ioth->loop,&ioth->listen_watcher, ac_listen_change_cb);


        ioth->iot = 1;

        tawstd_atomic32_init(&ioth->doing_request_count);

        // base thread init
        ac_thread_init(ioth, tp, ac_io_on_thread_start, ac_connect_wakeup_cb);
    }

    // 屏蔽掉SIGPIPE
    signal(SIGPIPE, SIG_IGN);

    struct sigaction sigact;
    sigact.sa_handler = ac_signal_handler;
    sigemptyset(&sigact.sa_mask);
    sigact.sa_flags = SA_RESETHAND;
    sigaction(SIGINT, &sigact, NULL);
    sigaction(SIGTERM, &sigact, NULL);
    sigaction(39, &sigact, NULL);


    // add to ac_io_list_var
    ac_spin_lock(&ac_io_list_lock);
    ac_list_add_tail(&acio->acio_list_node, &ac_io_list_var);
    ac_spin_unlock(&ac_io_list_lock);


    return acio;

}

//启动io线程
int ac_acio_start(ac_io_t * acio)
{


    ac_io_thread_t           *th;
    ac_thread_pool_t      *tp;

    if (acio == NULL )
        return AC_ERROR;

    if (acio->started)
        return AC_ABORT;

    if (acio->tcp_nodelay) acio->tcp_cork = 0;

    // 起线程
    ac_spin_lock(&acio->lock);

    ac_list_for_each_entry(tp, &acio->thread_pool_list, list_node) {
        ac_thread_pool_for_each(th, tp, 0) {
            pthread_create(&(th->tid), NULL, th->on_start, (void *)th);
            ac_info_log("pthread_create %p,tid %d\n",th,th->tid);
            //UDP只启动一个io线程。可以启动多个worker线程
            if (acio->listen && (acio->listen->addr.conn_flag&AC_UDP)==AC_UDP
                             &&acio->io_thread_count!=1){

                ac_info_log("pthread_create AC_UDP %p,tid %d\n",th,th->tid);
                acio->io_thread_count=1;
                break;
            }
        }
    }
    acio->started = 1;
    ac_spin_unlock(&acio->lock);

    return AC_OK;
}

//先关闭，再销毁
int ac_acio_stop(ac_io_t *acio)
 {
    if (acio == NULL || acio->stoped)
        return AC_ERROR;

    acio->stoped = 1;
    ac_debug_log("ac_acio_stop exit, acio=%p,acio->stoped=%d\n", acio,acio->stoped);

    //关闭io_stream，让async可以收到。
    ac_io_thread_t *ioth;
    ac_thread_pool_for_each(ioth, acio->io_thread_pool, 0) {

        ac_connection_t *c;
        ac_list_for_each_entry(c, &ioth->connected_list, conn_list_node) {
            if((c->addr.conn_flag&AC_UDP)==AC_UDP && !uv_is_closing(c->io_stream)){
                  ac_debug_log("uv_close c->io_stream");
                 uv_close(c->io_stream,NULL);
            }

       }
    }

    ac_thread_pool_t      *tp, *tp1;

    ac_list_for_each_entry_safe(tp, tp1, &acio->thread_pool_list, list_node) {
        //关闭所有线程的loop
        ac_thread_pool_on_wakeup(tp);
    }

    ac_debug_log("ac_acio_stop exit, acio=%p\n", acio);

    return AC_OK;

}

/**
 * 等待ac_io
 */
int ac_acio_wait(ac_io_t *acio)
{
    ac_io_thread_t           *th;
    ac_thread_pool_t         *tp;

    // 等待thread
    ac_spin_lock(&acio->lock);
    ac_list_for_each_entry(tp, &acio->thread_pool_list, list_node) {
        ac_thread_pool_for_each(th, tp, 0) {
            ac_info_log("ac_acio_wait %p,tid %d\n",th,th->tid);
            if (th->tid && pthread_join(th->tid, NULL) == EDEADLK) {
                ac_fatal_log("ac_io_wait fatal, acio=%p, tid=%lx\n", acio, th->tid);
                abort();
            }

            th->tid = 0;
        }
    }
    ac_spin_unlock(&acio->lock);

    ac_debug_log("ac_io_wait exit, acio=%p\n", acio);

    return AC_OK;
}



//销毁acio
int ac_acio_destroy(ac_io_t *acio)
{
    ac_io_thread_t        *ioth;
    ac_thread_pool_t      *tp;
    ac_listen_t           *l,*lp;

    if (acio == NULL)
        return;

    // 从ac_io_list_var去掉
    ac_spin_lock(&ac_io_list_lock);

    acio->stoped = 1;

    if (acio->acio_list_node.prev) ac_list_del(&acio->acio_list_node);

    ac_spin_unlock(&ac_io_list_lock);

    // close listen

    for (l = acio->listen; l; l = l->next) {
       close(l->fd);
    }

    // free listen
    for (l = acio->listen; l; l = l->next) {
        ac_debug_log("free listen\n");
        taw_free(l);
    }


    // destroy io_thread
    if (acio->io_thread_pool) {
        ac_thread_pool_for_each(ioth, acio->io_thread_pool, 0) {
            ac_io_thread_destroy(ioth);
        }
    }

    // destroy baseth pool
    if(acio->io_thread_pool)
        ac_thread_pool_destroy(acio->io_thread_pool);
    if(acio->thread_pool)
        ac_thread_pool_destroy(acio->thread_pool);

    taw_free(acio);

    ac_debug_log("ac_acio_destroy, acio=%p\n", acio);
}


/**
 * 新建一个session_t
 */
ac_session_t *ac_session_create(int size)
{
    ac_session_t  *s;
    ac_debug_log("ac_session_create size=%d",size);
    size += sizeof(ac_session_t);

    size = ac_align(size, AC_POOL_ALIGNMENT);//512
    // 新建一个message
    if ((s = (ac_session_t *)taw_malloc("ac_session_t", size,0)) == NULL) {
        return NULL;
    }
    memset(s, 0, sizeof(ac_session_t));

    s->r.ms = (ac_message_session_t *)s;
    s->type = AC_TYPE_SESSION;
    ac_list_init(&s->session_list_node);

    return s;
}
/**
 * destroy掉ac_session_t对象
 */
void ac_session_destroy(void *data)
{
    ac_debug_log("ac_session_destroy %p",data);
    ac_message_t          *m;
    ac_session_t          *s;

    s = (ac_session_t *) data;

    if (s->cleanup)
        (s->cleanup)(&s->r, NULL);

    // 如果存在
    if (s->async && (m = (ac_message_t *)s->r.request_list_node.next)) {
        s->r.request_list_node.next = NULL;
        ac_message_destroy(m, 0);
    }
    ac_debug_log("ac_session_destroy taw_free %p",s);
    taw_free(s);

}

int ac_connect(ac_io_t *acio, const char *addr, ac_handler_pt *handler, int conn_timeout, void *args, int autoconn)//client调用连接
{
    ac_debug_log("ac_connect");
    int         ret;

    ac_session_t *s = ac_session_create(0);
    s->status = AC_CONNECT_ADDR;
    s->process = (ac_io_process_pt *)handler;
    s->timeout = conn_timeout;
    s->r.args = args;
    s->packet_id = autoconn;

    if ((ret = ac_client_send_request(acio, addr, s)) != AC_OK)
        ac_session_destroy(s);

    return ret;
}

//异步发送请求
int ac_client_send_request(ac_io_t *acio, const char *addr_str, ac_session_t *s)//client发送请求
{
    ac_debug_log("ac_client_send_request\n");

    int ret;
    ac_addr_t  addr;
    ac_io_thread_t        *ioth = ac_thread_self;
    uint64_t                index;


    ret = ac_addr_parse(addr_str, &addr);
    if(ret!=0){
        ac_error_log("connect addr error.");
        return AC_ERROR;
    }

    if(acio == NULL){
       ac_error_log("acio is NULL.");
       return AC_ERROR;
    }

    if (acio->stoped || (ioth != NULL && ioth->iot && ioth->acio==acio)) {
        ac_error_log("ac_io_dispatch is failure: stoped: %d, ioth: %p, s=%p\n",
                       acio->stoped, ioth, s);
        return AC_ERROR;
    }

    index = ac_hash_code(&addr, sizeof(ac_addr_t), 7);
    ioth = (ac_io_thread_t *)ac_thread_pool_hash(acio->io_thread_pool, index);

    if (s->status == 0 && ioth->doing_request_count.cnt >= AC_IOTH_DOING_REQ_CNT) {
        ac_error_log("ioth->doing_request_count: %d, AC_IOTH_DOING_REQ_CNT: %d\n",
                       ioth->doing_request_count.cnt, AC_IOTH_DOING_REQ_CNT);
        return AC_ERROR;
    }

    s->async = 1;

    strcpy(s->addr.addr,addr.addr);
    s->addr.port = addr.port;
    s->addr.conn_flag = addr.conn_flag;
    ac_debug_log("ac_connection_send_session_list  addr %s,flag=%d,port=%d\n",
                            s->addr.addr,s->addr.conn_flag,s->addr.port);

    tawstd_atomic32_inc(&ioth->doing_request_count);

    // 唤醒io线程，处理请求
    ret = AC_OK;
    ac_spin_lock(&ioth->thread_lock);

    if (likely(acio->stoped == 0)) {
        ac_list_add_tail(&s->session_list_node, &ioth->session_list);
        ac_debug_log("uv_async_send(ioth->thread_watcher);/ac_connect_wakeup_cb");
        uv_async_send(&ioth->thread_watcher);//触发ac_connect_wakeup_cb
    } else {
        ret = AC_ERROR;
    }

    ac_unlock(&ioth->thread_lock);

    return ret;
}

ac_listen_t *ac_listen(ac_io_t *acio,const char *addr, ac_handler_pt *handler)
{
    int ret;
    ac_addr_t ac_addr;
    ret = ac_addr_parse(addr, &ac_addr);
    if(ret!=0){
        ac_error_log("listen addr error.");
        return NULL;
    }
    return ac_listen_ex(acio, ac_addr.addr, ac_addr.port, handler, ac_addr.conn_flag);
}

//conn_flag: tcp udp ipv4 ipv6 fd unsocket
ac_listen_t *ac_listen_ex(ac_io_t *acio, char *addr, int port, ac_handler_pt *handler, int conn_flag)
{
    ac_debug_log("ac_listen, ip:%s,port:%d,conn_flag:%d,\n",addr,port,conn_flag);
    int                     i, size, cnt, r;
    ac_listen_t             *l;
    int                     sockfd;
    unsigned int            addrlen;

    // 已经开始,不能再增加监听
    if (acio->started) {
        ac_error_log("connection_add_listen failure: acio->started=%d\n",acio->started);
        return NULL;
    }

    // alloc memory
    /**由于listen切换使用uv_async，所以ac_listen_t中需要保存io_thread_count个uv_async_t，以方便
       每个io线程触发异步切换listen*/
   // cnt = (acio->listen_all || acio->io_thread_count == 1) ? acio->io_thread_count : 2;
    cnt = acio->io_thread_count ;
    if((conn_flag&AC_TCP)==AC_TCP)
        size = cnt * sizeof(uv_tcp_t);
    else if((conn_flag&AC_SOCKET_UN)==AC_SOCKET_UN)
        size = cnt * sizeof(uv_pipe_t);

    size += sizeof(ac_listen_t);

    if ((l = (ac_listen_t *) taw_malloc("ac_listen_t", size, 0)) == NULL) {
        ac_error_log("taw_malloc failure: ac_listen_t size=%d\n",size);
        return NULL;
    }
    l->listen_watcher = (uv_stream_t*)&(l->listen_watcher_data[0]);

    strcpy(l->addr.addr,addr);
    l->addr.port = port;
    l->addr.conn_flag = conn_flag;

    tawstd_atomic32_init(&l->listen_lock);
    // 打开监听
    int bind_flag = 0;
    struct sockaddr* addr_base = NULL;
    if((conn_flag&AC_IPV6)==AC_IPV6){
        ac_debug_log("AC_IPV6\n");
        struct sockaddr_in6 addr6;
        uv_ip6_addr(addr, port, &addr6);
        addr_base = (struct sockaddr*)&addr6;
        bind_flag = 1;//UV_UDP_IPV6ONLY or UV_TCP_IPV6ONLY
    }
    else if((conn_flag&AC_IPV4)==AC_IPV4){
        ac_debug_log("AC_IPV4\n");
        struct sockaddr_in addr4;
        uv_ip4_addr(addr, port, &addr4);
        addr_base = (struct sockaddr*)&addr4;
    }


    uv_udp_t* udpServer;
    int ret;

    if((conn_flag&AC_TCP)==AC_TCP ){
        ac_debug_log("AC_TCP\n");

        if (addr_base->sa_family == AF_INET){
            addrlen = sizeof(struct sockaddr_in);
            sockfd = socket(AF_INET, SOCK_STREAM, 0);
        }
        else if (addr_base->sa_family == AF_INET6){
            addrlen = sizeof(struct sockaddr_in6);
            sockfd = socket(AF_INET6, SOCK_STREAM, 0);
        }

        //设置非阻塞
        _nonblock(sockfd, 1);

         _cloexec(sockfd, 1);

        //允许reuse
        int yes = 1;
        r = setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof yes);

        ret = bind(sockfd, addr_base, addrlen);
        if(ret == -1)
        {
            ac_error_log("bind failure\n");
            return NULL;
        }

        ret = listen(sockfd, AC_LISTEN_CONN);
        if(ret == -1)
        {
            ac_error_log("listen failure\n");
            return NULL;
        }

    }
    else if ((conn_flag&AC_UDP)==AC_UDP)
    {
         ac_debug_log("AC_UDP\n");
        /*

        if (addr_base->sa_family == AF_INET){
            addrlen = sizeof(struct sockaddr_in);
            sockfd = socket(AF_INET, SOCK_DGRAM, 0);
        }
        else if (addr_base->sa_family == AF_INET6){
            addrlen = sizeof(struct sockaddr_in6);
            sockfd = socket(AF_INET6, SOCK_DGRAM, 0);
        }

        //设置非阻塞
        _nonblock(sockfd, 1);

         _cloexec(sockfd, 1);

        //允许reuse
        int yes = 1;
        r = setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof yes);

        ret = bind(sockfd, addr_base, addrlen);
        if(ret == -1)
        {
            ac_error_log("bind failure\n");
            return NULL;
        }
        */

        int                   ret;

        if ((udpServer = (uv_udp_t *) taw_malloc("uv_udp_t", sizeof(uv_udp_t), 0)) == NULL) {
                ac_error_log("taw_malloc failure: uv_udp_t size=%d\n",sizeof(uv_udp_t));
                return NULL;
        }

        ret = uv_udp_init(uv_default_loop(), udpServer);
        if (ret) {
                ac_error_log("uv_udp_init: %s\n", uv_strerror(ret));
                return NULL;
        }

        ret = uv_udp_bind(udpServer, addr_base, bind_flag);
        if (ret) {
                ac_error_log("Bind error\n");
                return NULL;
        }
        udpServer->data = l;
        l->udp_server = udpServer;




    }
    else if ((conn_flag&AC_SOCKET_UN)==AC_SOCKET_UN)
    {
        ac_debug_log("AC_SOCKET_UN\n");
        struct sockaddr_un addr_un;

        sockfd = socket(AF_UNIX, SOCK_STREAM, 0);

        memset(&addr_un, 0, sizeof(struct sockaddr_un));
        addr_un.sun_family = AF_UNIX;
        strncpy(addr_un.sun_path, addr,sizeof(addr_un.sun_path) - 1);

        _nonblock(sockfd, 1);

         _cloexec(sockfd, 1);
        //允许reuse
          int yes = 1;
          r = setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof yes);

        ret = bind(sockfd, (struct sockaddr *) &addr_un, sizeof(struct sockaddr_un));
        if(ret == -1)
        {
            ac_error_log("bind failure\n");
            return NULL;
        }
        ret = listen(sockfd, AC_LISTEN_CONN);
        if(ret == -1)
        {
            ac_error_log("listen failure\n");
            return NULL;
        }


    }
    else if ((conn_flag&AC_FD)==AC_FD)
    {
        sockfd = atoi(addr);


    }
    l->fd = sockfd;

    // 初始化
    l->handler = handler;

    //用于异步启动IO线程

    ac_thread_pool_t *tp;
    ac_io_thread_t *th;

    ac_thread_pool_for_each(th, acio->io_thread_pool, 0) {

        if ((conn_flag&AC_TCP)==AC_TCP){
            uv_tcp_t *server = (uv_tcp_t *)(l->listen_watcher_data + th->idx * sizeof(uv_tcp_t));
            server->data = l;
            uv_tcp_init(th->loop, server);
            uv_tcp_open(server, sockfd);
        }
        else if((conn_flag&AC_SOCKET_UN)==AC_SOCKET_UN){
            uv_pipe_t *server = (uv_pipe_t *)(l->listen_watcher_data + th->idx * sizeof(uv_pipe_t));
            server->data = l;
            uv_pipe_init(th->loop, server,0);
            uv_pipe_open(server, sockfd);
        }

    }


    l->next = acio->listen;
    acio->listen = l;

    return l;
}

int ac_connection_send_session_list(ac_list_t *list)
{
    ac_debug_log("ac_connection_send_session_list loop %p\n",ac_thread_self->loop);
    ac_connection_t       *c;
    ac_session_t          *s, *s1;
    ac_connection_list_t  wlist = {NULL, NULL};
    int                     status;

    // foreach encode
    ac_list_for_each_entry_safe(s, s1, list, session_list_node) {
        ac_list_del(&s->session_list_node);

        ac_debug_log("ac_connection_send_session_list  addr %s,flag=%d,port=%d\n",
                            s->addr.addr,s->addr.conn_flag,s->addr.port);
        // connect, disconnect
        status = s->status;

        if ((c = ac_connection_do_client(s)) == NULL || status)
            continue;

        // build session
        s->c = c;

        if (ac_connection_session_build(s) == AC_OK) {
            ac_connection_add_list(&wlist, s->c);
        }
    }

    // foreach
    if (wlist.tail)
        wlist.tail->next = NULL;

    while(wlist.head) {
        c = wlist.head;
        wlist.head = c->next;
        c->next = NULL;

        if (c->status != AC_CONN_OK)
            continue;

        if (ac_connection_write_socket(c) == AC_ABORT) {
            ac_connection_destroy(c);
        }
    }

    return AC_OK;
}

//发出断开连接的请求
int ac_connection_disconnect(ac_io_t *acio, const char *addr)
{
    ac_debug_log("ac_connection_disconnect");
    int             ret;

    if (strlen(addr) == 0)
        return AC_ERROR;

    ac_session_t *s = ac_session_create(0);
    s->status = AC_DISCONNECT_ADDR;

    if ((ret = ac_client_send_request(acio, addr, s)) != AC_OK) {
        ac_session_destroy(s);
    }

    return ret;
}

/**
 * 发送到c上, 只允许本io线程调用
 */
int ac_connection_send_session(ac_connection_t *c, ac_session_t *s)
{
    ac_debug_log("ac_connection_send_session");
    ac_io_thread_t        *ioth = ac_thread_self;

    if (ioth == NULL || ioth->iot == 0 || ioth->acio->stoped) {
        return AC_ERROR;
    }

    if (s->status == 0 && ioth->doing_request_count.cnt >= AC_IOTH_DOING_REQ_CNT) {
        ac_error_log("ioth->doing_request_count: %d, ac_IOTH_DOING_REQ_CNT: %d\n",
                       ioth->doing_request_count.cnt, AC_IOTH_DOING_REQ_CNT);
        return AC_ERROR;
    }

    s->c = c;

    if (s->process == NULL) s->process = c->handler->process;


    tawstd_atomic32_inc(&ioth->doing_request_count);

    if (ac_connection_session_build(s) != AC_OK)
        return AC_ERROR;


    // 等下次写出去
    if (c->status != AC_CONN_OK )//|| uv_is_active((uv_handle_t*)&c->write_watcher))
        return AC_OK;

    // 写出到socket

    if (ac_connection_write_socket(c) == AC_ABORT) {
        ac_debug_log("ac_connection_disconnect ac_connection_write_socket == AC_ABORT");
        ac_connection_destroy(c);
        return AC_ABORT;
    }

    return AC_OK;
}


// push到c->output上
void ac_request_addbuf(ac_request_t *r, ac_buf_t *b)
{
    ac_message_session_t *ms = r->ms;

    if (ms->type == AC_TYPE_MESSAGE) {
        //TODO
    } else {
        ac_session_t *s = (ac_session_t *)ms;

        if (s->nextb == NULL) s->nextb = &b->node;
    }
    ac_debug_log("ac_request_addbuf c=%p b=%p,b->list_node=%p",ms->c,b,&b->node);

    ac_list_add_tail(&b->node, &ms->c->output);
}


//加list到c->output上
void ac_request_addbuf_list(ac_request_t *r, ac_list_t *list)
{
    ac_buf_t              *b;
    ac_message_session_t  *ms = r->ms;

    // 是否为空
    if (ac_list_empty(list))
        return;

    if (ms->type == AC_TYPE_MESSAGE) {
        // 在没写回去的时候
        b = ac_list_get_last(list, ac_buf_t, node);
        //tawstd_atomic32_inc(&ms->pool->ref);
        //ac_buf_set_cleanup(b, ac_message_cleanup, ms);
    } else {
        // 在超时的时间用到
        ac_session_t *s = (ac_session_t *)ms;
        b = ac_list_get_first(list, ac_buf_t, node);

        if (s->nextb == NULL && b) s->nextb = &b->node;
    }

    ac_list_join(list, &ms->c->output);
}


// 长任务初始化工作线程池
ac_thread_pool_t *ac_work_thread_pool_create(ac_io_t *acio, int cnt, ac_request_process_pt *cb, void *args)
{
    return ac_thread_pool_create_ex(acio, cnt, ac_thread_on_start, cb, args);
}

// 自定义worker线程启动函数
ac_thread_pool_t *ac_thread_pool_create_ex(ac_io_t *acio, int cnt,
        ac_baseth_on_start_pt *start, ac_request_process_pt *cb, void *args)
{
    ac_request_thread_t   *rth;
    ac_thread_pool_t      *tp;
    if ((tp = ac_thread_pool_create(acio, cnt, sizeof(ac_request_thread_t))) == NULL)
        return NULL;

    // 初始化线程池
    ac_thread_pool_for_each(rth, tp, 0) {
        rth->loop = uv_loop_new();
        ac_thread_init(rth, tp, start, ac_request_on_wakeup);

        rth->process = cb;
        rth->args = args;
        ac_list_init(&rth->task_list);
        ac_list_init(&rth->session_list);
    }

    // join
    tp->next = acio->thread_pool;
    acio->thread_pool = tp;

    return tp;
}

//将请求加入到worker线程队列中
int ac_thread_pool_push(ac_thread_pool_t *tp, ac_request_t *r, uint64_t hv)
{
    ac_request_thread_t   *rth;

    // dispatch，hash选取一个worker线程
    if (hv == 0) hv = ac_hash_key((long)r->ms->c);

    rth = (ac_request_thread_t *)ac_thread_pool_hash(tp, hv);
    ac_list_del(&r->request_list_node);

    // 引用次数
    r->retcode = AC_AGAIN;

    ac_spin_lock(&rth->thread_lock);
    ac_list_add_tail(&r->request_list_node, &rth->task_list);

    rth->task_list_count ++;
    //唤醒worker线程
    ac_debug_log("uv_async_send(rth->thread_watcher);loop=%p,hand->loop=%p",rth->loop,rth->thread_watcher.loop);
    uv_async_send(&rth->thread_watcher);
    ac_spin_unlock(&rth->thread_lock);

    return AC_OK;
}


void ac_signal_handler(int sig)
{
    ac_debug_log("sig=%d\n",sig);
    ac_io_t   *acio, *a1;

    if (ac_trylock(&ac_io_list_lock) == 0)
        return;

    if (sig == SIGINT || sig == SIGTERM) {
        ac_list_for_each_entry_safe(acio, a1, &ac_io_list_var, acio_list_node) {
            ac_acio_stop(acio);
        }
    } else if (sig == 39) {
        ac_list_for_each_entry_safe(acio, a1, &ac_io_list_var, acio_list_node) {
             ac_io_print_status(acio);
        }
    }

    ac_unlock(&ac_io_list_lock);
}


/**
 * 起处理速度定时器
 */
void ac_acio_stat_watcher_start(ac_io_t *acio, uv_timer_t *stat_watcher, double interval,
                                 ac_io_stat_t *iostat, ac_io_stat_process_pt *process)
{
    ac_io_thread_t    *ioth;

    memset(iostat, 0, sizeof(ac_io_stat_t));
    iostat->last_cnt = 0;
    iostat->last_time = acio->start_time;
    iostat->process = process;
    iostat->acio = acio;

    ioth = (ac_io_thread_t *)ac_thread_pool_index(acio->io_thread_pool, 0);
    uv_timer_init(ioth->loop, stat_watcher);
    stat_watcher->data = iostat;
    uv_timer_start(stat_watcher, ac_io_stat_process, 1, interval);
    ac_thread_on_wakeup(ioth);
}

/**
 * 统计处理函数
 */
void ac_io_stat_process(uv_timer_t* handle)
{
    ac_io_stat_t          *iostat;
    uint64_t               last_time, t1, t2;//毫秒
    int64_t                last_cnt;
    ac_io_thread_t        *ioth;
    ac_io_t               *acio;



    iostat = (ac_io_stat_t *)handle->data;
    acio = iostat->acio;
    ioth = (ac_io_thread_t *)ac_thread_pool_index(acio->io_thread_pool, 0);

    // 统计当前值
    last_time = uv_now(ioth->loop);
    last_cnt = 0;
    int ql = 0;
    ac_connection_t *c;
    ac_thread_pool_for_each(ioth, acio->io_thread_pool, 0) {
        last_cnt += ioth->done_request_count;
        ac_list_for_each_entry(c, &ioth->connected_list, conn_list_node) {
            ql += c->doing_request_count;
        }
   }

    t1 = last_time - iostat->last_time;
    t2 = last_time - acio->start_time;
    ac_info_log("interval time = %llu  run time = %llu", t1, t2);

    // 保存起来
    if(t1)
        iostat->last_speed = (acio->recv_byte.cnt - iostat->last_cnt)/ t1 ;
    else
        iostat->last_speed = 0;

    if(t2)
        iostat->total_speed = acio->recv_byte.cnt / t2;
    else
        iostat->total_speed = 0;

    iostat->last_cnt = acio->recv_byte.cnt;
    iostat->last_time = last_time;

    if (iostat->process == NULL) {
        ac_info_log("cnt: %" PRId64 ", speed: %.2f KB/S, total_speed: %.2f KB/S, recv: %"
                      PRIdFAST32 "KB, send: %" PRIdFAST32 "KB, ql:%d\n",
                      last_cnt, iostat->last_speed, iostat->total_speed,
                      acio->recv_byte.cnt/1024, acio->send_byte.cnt/1024, ql);
    } else {
        (iostat->process)(iostat);
    }
    IF_UTHREAD_YIELD

}

void ac_io_print_status(ac_io_t *acio)
{
    ac_connection_t       *c;
    ac_io_thread_t        *ioth;
    char                  buffer[32];

    // foreach connected_list
    ac_thread_pool_for_each(ioth, acio->io_thread_pool, 0) {
        ac_info_log("recv_byte:%d,thread:%d, doing: %d, done: %" PRIdFAST32 "\n",
                    acio->send_byte.cnt,
                    ioth->idx,
                    ioth->doing_request_count,
                    ioth->done_request_count);

        ac_list_for_each_entry(c, &ioth->connected_list, conn_list_node) {
            ac_info_log("%d %s => doing: %d, done:%" PRIdFAST32 "\n",
                          ioth->idx,
                          c->addr.addr,
                          c->doing_request_count, c->done_request_count);
        }
    }
}

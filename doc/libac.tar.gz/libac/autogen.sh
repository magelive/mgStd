#!/bin/sh

if [ "${prefix}" == "" ] ; then
 prefix=/usr
fi
NEEDAUTCONF=""
if [ -f "./config.log" ] ; then
NEEDAUTCONF=`grep ${CONFIG_SITE} ./config.log`
fi
if [ "$NEEDAUTCONF" == "" ] ; then
echo libtoolize --automake
libtoolize --automake

echo "aclocal ${OECORE_ACLOCAL_OPT}"
aclocal ${OECORE_ACLOCAL_OPT} > /dev/null 2>/dev/null

echo autoconf
autoconf > /dev/null 2> /dev/null
echo autoheader
autoheader > /dev/null 2>/dev/null
echo automake -a
automake -a > /dev/null 2>/dev/null
fi

if [ "${RTE_SDK}" == "" ] ; then
export RTE_SDK=${OECORE_TARGET_SYSROOT}/opt/DPDK/
fi
if [ "${RTE_TARGET}" == "" ] ; then
export RTE_TARGET=x86_64-atm-linuxapp-gcc
fi
if [ "${RTE_MACHINE}" == "" ] ; then
export RTE_MACHINE=atm
fi

export CFLAGS="-g -O0"
echo "ENV"
echo "------------------------------"
export | grep RTE
export | grep OE
export | grep CC
export | grep CFLAGS
echo "------------------------------"

if [ ! -f "Makefile" ] || [ "$NEEDAUTCONF" == "" ]; then
  echo ./configure ${CONFIGURE_FLAGS} --prefix=${OECORE_TARGET_SYSROOT}/${prefix} $*
  read -p "Press any key to configure..."
  CFLAGS="-g -O0 ${CFLAGS}" ./configure ${CONFIGURE_FLAGS} --prefix=${OECORE_TARGET_SYSROOT}/${prefix} $* CFLAGS="-g -O0 $CFLAGS" 
fi

if [  -f "Makefile" ];then
  read -p "Press any key to make..."
  make
fi

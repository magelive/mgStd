#include <ac.h>
#include <ac_util.h>
#include <ac_log.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <sys/time.h>
/**
 * echo packet
 */
typedef struct echo_packet_t {
    int                     len;
    char                    *data;
    char                    buffer[0];
} echo_packet_t;

double
difftimeval(const struct timeval *tv1, const struct timeval *tv2)
{
        double d;
        time_t s;
        suseconds_t u;

        s = tv1->tv_sec - tv2->tv_sec;
        u = tv1->tv_usec - tv2->tv_usec;
        if (u < 0){
            --s;
            u = tv1->tv_usec + 1000000.0  - tv2->tv_usec;
        }

        d = s;
        d *= 1000000.0;
        d += u;

        return d;
}

get_ip_port(char * host,char* ip,int* port){

    char                    *p;
    int                     len;

    if (host && (p = strchr(host, ':')) != NULL) {

        memcpy(ip, host, len);
        ip[len] = '\0';

        *port = atoi(p + 1);
    }
    else
         memcpy(ip, host, strlen(host));
}
/**
 * decode
 */
void *echo_decode(ac_message_t *m)
{
    echo_packet_t           *packet;
    long                    request_size;

    if ((packet = (echo_packet_t *)taw_malloc("echo_packet_t", sizeof(echo_packet_t),0)) == NULL)
        return NULL;


     if (m->c->handler->user_data) {
        request_size = (long)m->c->handler->user_data;
        ac_debug_log("echo_decode request_size:%d\n",request_size);
        if (m->input->last - m->input->pos < request_size) {
            //是否需要分几个包发送，下次发送的长度为next_read_len
            m->next_read_len = request_size - (m->input->last - m->input->pos);
            ac_debug_log("echo_decode next_read_len:%d\n",m->next_read_len);
            return NULL;
        }

        packet->data = (char *)m->input->pos;
        packet->len = request_size;
        m->input->pos += request_size;
    } else {

        packet->data = (char *)m->input->pos;
        packet->len = m->input->last - m->input->pos;
        m->input->pos = m->input->last;
    }

    ac_debug_log("echo_decode data:%p\n",packet->data);
    ac_debug_log("echo_decode len:%d\n",packet->len);

    return packet;
}

/**
 * encode
 */
int echo_encode(ac_request_t *r, void *data)
{
    echo_packet_t           *packet;
    ac_buf_t              *b;
    ac_connection_t       *c;
    ac_message_t          *m;
    m = (ac_message_t *) r->ms;
    c = m->c;

    packet = (echo_packet_t *) data;

    //zybuffer_set_buffer(b->zbf, packet->data, packet->len);
    ac_debug_log("echo_encode data:%p\n",packet->data);
    ac_debug_log("echo_encode len:%d \n",packet->len);

    if ((b = ac_buf_create( packet->len)) == NULL)
        return AC_ERROR;

    memcpy(b->pos, packet->data, packet->len);
    b->last += packet->len;

    ac_request_addbuf(r, b);

    //server的packet是decode时new出来的，需要free。
    //client的packet是和session一起new的，是session的一部分，在session析构时被释放。
    if(c->type==AC_TYPE_SERVER)
        taw_free(packet);

    return AC_OK;
}

int echo_encode_sendfile(ac_request_t *r, void *data)
{
    echo_packet_t           *packet;
    ac_file_buf_t              *b;

    packet = (echo_packet_t *) data;


    if ((b = ac_file_buf_create())==NULL)
        return AC_ERROR;

    b->fd=open("./abc.txt",O_RDWR,0);
    if(b->fd<0)
        return AC_ERROR;

    b->count=128;
    b->offset=0;
    ac_debug_log("echo_encode len:%d\n",b->count);

    ac_request_addbuf(r, (ac_buf_t*)b);

    return AC_OK;
}


#include <stdint.h>
#include <getopt.h>
#include <ac.h>
#include "echo_packet.h"
#include <sys/time.h>
#include <time.h>
#include <string.h>

// 命令行参数结构
typedef struct cmdline_param {
    char                    addr[128];
    int                     port;
    int                     conn_flag;
    int                     io_thread_cnt;
    int                     connect_cnt;
    int                     request_size;
    int64_t                 request_cnt;

    // count
    int64_t                 request_byte;
    tawstd_atomic32_t       process_byte;
    tawstd_atomic32_t       send_byte;
    struct timeval          start_time;
    ac_handler_pt           io_handler;
} cmdline_param;

/*************************************************************************************************
 * 函数定义部分
 *************************************************************************************************/
cmdline_param           cp;
static void print_usage(char *prog_name);
static int parse_cmd_line(int argc, char *const argv[], cmdline_param *cp);
static int echo_process(ac_request_t *r);
static int echo_new_packet(ac_connection_t *c);
//static int echo_disconnect(ac_connection_t *c);
//static int client_send_request(char* addr);
static void echo_uthread_start(void *args);
static void print_speed();

/**
 * 程序入口
 */
int main(int argc, char **argv)
{
    int                     i, ret;

    // default
    memset(&cp, 0, sizeof(cmdline_param));
    cp.io_thread_cnt = 1;
    cp.connect_cnt = 1;
    cp.request_cnt = 1000;
    cp.request_size = 512;

    // parse cmd line
    if (parse_cmd_line(argc, argv, &cp) == AC_ERROR)
        return AC_ERROR;

    // 对ac_io初始化, 设置io的线程数, file的线程数
    ac_io_t * acio = NULL;

    gettimeofday(&cp.start_time,NULL);

    if ((acio=ac_acio_create(acio,cp.io_thread_cnt))==NULL) {
        ac_error_log("ac_io_init error.\n");
        return AC_ERROR;
    }

    // 为监听端口设置处理函数，并增加一个监听端口
    memset(&cp.io_handler, 0, sizeof(cp.io_handler));
    cp.io_handler.decode = echo_decode;
    cp.io_handler.encode = echo_encode;
    cp.io_handler.process = echo_process;
    //cp.io_handler.new_packet = echo_new_packet;
   // io_handler.on_disconnect = echo_disconnect;
    cp.io_handler.user_data = (void *)(long)cp.request_size; //设置需要等够多少数据才算一个message


    ac_client_uthread_set_handler(&cp.io_handler);
    ac_io_set_uthread_start(echo_uthread_start, &cp);

    // 起线程并开始
    cp.request_byte = cp.request_cnt * cp.request_size;

    if (cp.request_byte < 0) cp.request_byte = ~(((int64_t)1) << 63);


    if (ac_io_start()) {
        ac_error_log("ac_io_start error.\n");
        return AC_ERROR;
    }

    // 等待线程退出
    ret = ac_io_wait();

    ac_io_destroy();

    print_speed();

    return ret;
}

/**
 * 命令行帮助
 */
static void print_usage(char *prog_name)
{
    fprintf(stderr, "%s -H host:port -c conn_cnt -n req_cnt -s size [-t thread_cnt]\n"
            "    -a, --addr              server address\n"
            "    -p, --port              server port\n"
            "    -f, --conn_flag         conn type:AC_IPV4 1 AC_IPV6 2 AC_TCP 4 AC_UDP 8 AC_FD 32\n"
            "    -c, --conn_cnt          connection count\n"
            "    -n, --req_cnt           request count\n"
            "    -s, --req_size          packet size of every request\n"
            "    -t, --io_thread_cnt     thread count for listen, default: 1\n"
            "    -h, --help              display this help and exit\n"
            "    -V, --version           version and build time\n\n"
            "eg: %s -a tcp://127.0.0.1:5000 -c2 -n2 -s128 \n"
            "    %s -a tcp://::1:5000 -c2 -n2 -s128 \n"
            "    %s -a udp://127.0.0.1:5000 -c2 -n2 -s128 \n"
            "    %s -a udp://::1:5000 -c2 -n2 -s128 \n"
            "    %s -a ipc:///home/myfile.ipc -c2 -n2 -s128 \n\n"
            , prog_name, prog_name, prog_name, prog_name, prog_name, prog_name);
}

/**
 * 解析命令行
 */
static int parse_cmd_line(int argc, char *const argv[], cmdline_param *cp)
{
    int                     opt;
    const char              *opt_string = "hVa:c:n:s:t:";
    struct option           long_opts[] = {
        {"addr", 1, NULL, 'a'},
        {"conn_cnt", 1, NULL, 'c'},
        {"req_cnt", 1, NULL, 'n'},
        {"req_size", 1, NULL, 's'},
        {"io_thread_cnt", 1, NULL, 't'},
        {"help", 0, NULL, 'h'},
        {"version", 0, NULL, 'V'},
        {0, 0, 0, 0}
    };

    opterr = 0;

    while ((opt = getopt_long(argc, argv, opt_string, long_opts, NULL)) != -1) {

        switch (opt) {

        case 'a':
            memcpy(cp->addr,optarg,strlen(optarg));
            break;

        case 't':
            ac_debug_log("cp->io_thread_cnt=%d",cp->io_thread_cnt);
            cp->io_thread_cnt = atoi(optarg);
            break;

        case 'c':
            cp->connect_cnt = atoi(optarg);
            break;

        case 'n':
            cp->request_cnt = atoi(optarg);
            break;

        case 's':

            if ((cp->request_size = atoi(optarg)) < 128)
                cp->request_size = 128;

            break;

        case 'V':
            fprintf(stderr, "BUILD_TIME: %s %s\n", __DATE__, __TIME__);
            return AC_ERROR;

        case 'h':
            print_usage(argv[0]);
            return AC_ERROR;

        default:
            break;
        }
    }

    return AC_OK;
}

static void print_speed()
{

    struct timeval end_time;
    gettimeofday(&end_time,NULL);
    double tms = difftimeval(&end_time, &cp.start_time)/1000.0 ;

    // speed
    ac_error_log("process_byte: %" PRIdFAST32 " send_byte: %" PRIdFAST32 "\n", cp.process_byte.cnt, cp.send_byte.cnt);
    ac_error_log("QPS: %.2f\n", 1.0 * cp.process_byte.cnt / tms / cp.request_size * 1000);

    ac_error_log("req: %.2f\n", 1.0 * cp.request_size);
    ac_error_log("tms: %.2f\n", 1.0 * tms);

    ac_error_log("Throughput: %.2f MB/s\n", 1.0 * cp.process_byte.cnt / tms / 1024 / 1024 * 1000);
}

static void echo_uthread_start(void *args)
{
    ac_connection_t         *c;
    ac_session_t            *s;
    echo_packet_t           *packet;
    char                    buffer[32];
    int                     i, size;

    // connect
    c = ac_io_connect_thread(cp.addr, &cp.io_handler, 0, NULL);

    if (c == NULL) {
        ac_error_log("connection failure: %s\n",cp.addr);
        goto error_exit;
    }

    if (ac_client_uthread_wait_conn(c) != AC_OK) {
        goto error_exit;
    }


    for(i = 0; i < cp.request_cnt; i++) {
        size = cp.request_size + sizeof(echo_packet_t);

        if ((packet = ac_session_packet_create(echo_packet_t, s, size)) == NULL)
            goto error_exit;

        packet->data = &packet->buffer[0];
        packet->len = cp.request_size;

        // send
        if (ac_connection_send_session(c, s) != AC_OK) {
            ac_session_destroy(s);
            ac_error_log("send failure.\n");
            goto error_exit;
        }

        if (ac_client_uthread_wait_session(s) != AC_OK)
            goto error_exit;

        ac_session_destroy(s);
        tawstd_atomic32_add(&cp.send_byte,cp.request_size);
        tawstd_atomic32_add(&cp.process_byte,cp.request_size);
          ac_debug_log("send=%d,process=%d\n",cp.send_byte.cnt,cp.process_byte.cnt);
    }

error_exit:
    ac_io_stop();
}

/**
 * 处理函数
 */
static int echo_process(ac_request_t *r)
{
    echo_packet_t           *reply;

    reply = (echo_packet_t *) r->ipacket;
    ac_error_log("echo_process reply=%p\n",reply);

    if (!reply)
        return AC_ERROR;

    tawstd_atomic32_add(&cp.process_byte, reply->len);

    if (cp.send_byte.cnt >= cp.request_byte ){//&& cp.process_byte.cnt == cp.send_byte.cnt) {
        ac_debug_log("echo_process call ac_io_stop\n");
        ac_io_stop();
    }

    ac_debug_log("echo_process over\n");
    return AC_OK;
}

/**
 * 新建packet
 */
static int echo_new_packet(ac_connection_t *c)
{

    ac_session_t          *s;
    echo_packet_t           *packet;
    if (cp.send_byte.cnt >= cp.request_byte)
        return AC_OK;
    if ((packet = ac_session_packet_create(echo_packet_t, s,cp.request_size)) == NULL)
        return AC_ERROR;

    packet->data = &packet->buffer[0];


    packet->data = &packet->buffer[0];
    packet->len = cp.request_size;

    //memset出问题，不是内存泄露或者越界
   // memset(packet->data, 0, packet->len);

    int i;
    for(i=4; i<cp.request_size; i++)
       packet->buffer[i]='\0';


    tawstd_atomic32_add(&cp.send_byte,cp.request_size);

    ac_connection_send_session(c, s);


    return AC_OK;
}

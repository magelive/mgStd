#include <getopt.h>
#include <ac.h>
#include "echo_packet.h"

// 命令行参数结构
typedef struct cmdline_param {
    char                    addr[256];
    int                     io_thread_cnt;
    int                     work_thread_cnt;
    ac_thread_pool_t       *threads;
}cmdline_param;

/*************************************************************************************************
 * 函数定义部分
 *************************************************************************************************/

cmdline_param           cp;

static void print_usage(char *prog_name);
static int parse_cmd_line(int argc, char *const argv[], cmdline_param *cp);
static int echo_process(ac_request_t *r);
static int echo_connect(ac_connection_t *c);
static int echo_async_process(ac_request_t *r);
static int easy_async_request_process(ac_request_t *r, void *args);
static int echo_idle(ac_connection_t *c);
/**
 * 程序入口
 */
int main(int argc, char **argv)
{

    ac_listen_t           *listen;
    ac_handler_pt         io_handler;
    int                     ret;

    // default
    memset(&cp, 0, sizeof(cmdline_param));
    cp.io_thread_cnt = 1;

    // parse cmd line
    if (parse_cmd_line(argc, argv, &cp) == AC_ERROR)
        return AC_ERROR;

    // 对ac_io初始化, 设置io的线程数, file的线程数

    ac_io_t * acio=NULL;
    if ((acio = ac_acio_create(acio,cp.io_thread_cnt))==NULL) {
        ac_error_log("ac_io_init error.\n");
        return AC_ERROR;
    }

    // 为监听端口设置处理函数，并增加一个监听端口
    //ac_io_var.tcp_defer_accept = 0;
    memset(&io_handler, 0, sizeof(io_handler));
    io_handler.decode = echo_decode;
    io_handler.encode = echo_encode;
    //io_handler.on_idle = echo_idle;

    io_handler.on_connect = echo_connect;

    //如果使用worker线程，那么在io线程的回调函数process中，将任务加入到worker的队列，
    //真正处理请求在worker的回调函数easy_async_request_process中。
    if(cp.work_thread_cnt){
        io_handler.process = echo_async_process;
        cp.threads = ac_request_thread_create(cp.work_thread_cnt,
                                            easy_async_request_process, NULL);
    }
    //不使用worker线程，直接在io线程的process中处理返回。
    else
        io_handler.process = echo_process;
   // io_handler.get_packet_id = echo_tbnet_packet_id;

    uv_timer_t              stat_watcher;
    ac_io_stat_t            iostat;
    //60秒输出一次统计信息
    ac_io_stat_watcher_start(&stat_watcher, 1200000.0, &iostat, NULL);


    if ((listen = ac_listen(acio, cp.addr, &io_handler)) == NULL) {
        ac_error_log("ac_io_add_listen error, addr: %s, %s\n",
                       cp.addr, strerror(errno));
        return AC_ERROR;
    } else {
        ac_error_log("listen start, addr = %s\n", cp.addr);
    }

    // 起线程并开始
    if (ac_io_start()) {
        ac_error_log("ac_io_start error.\n");
        return AC_ERROR;
    }

    // 等待线程退出
    ret = ac_io_wait();
    ac_io_destroy();

    return ret;
}

/**
 * 命令行帮助
 */
static void print_usage(char *prog_name)
{
    fprintf(stderr, "%s -p port [-t thread_cnt]\n"
            "    -a, --addr              address of the stream\n"
            "    -t, --io_thread_cnt     thread count for listen, default: 1\n"
            "    -w, --work_thread_cnt   thread count for worker, default: 0.If not 0,use workers.\n"
            "    -h, --help              display this help and exit\n"
            "    -V, --version           version and build time\n\n"
            "eg: %s -a tcp://127.0.0.1:5000 \n"
            "    %s -a tcp://::1:5000 -t 5 -w 5\n"
            "    %s -a udp://127.0.0.1:5000 \n"
            "    %s -a udp://::1:5000 -w 5\n"
            "    %s -a ipc:///home/myfile.ipc -t 5 -w 5\n\n"
            , prog_name, prog_name, prog_name, prog_name, prog_name, prog_name);

}

/**
 * 解析命令行
 */
static int parse_cmd_line(int argc, char *const argv[], cmdline_param *cp)
{
    int                     opt;
    const char              *opt_string = "hVf:a:w:t:";
    struct option           long_opts[] = {
        {"addr", 1, NULL, 'a'},
        {"io_thread_cnt", 1, NULL, 't'},
        {"help", 0, NULL, 'h'},
        {"version", 0, NULL, 'V'},
        {"work_count", 0, NULL, 'w'},
        {0, 0, 0, 0}
    };

    opterr = 0;

    while ((opt = getopt_long(argc, argv, opt_string, long_opts, NULL)) != -1) {
        switch (opt) {

        case 'a':
            memcpy(cp->addr,optarg,strlen(optarg));
            break;

        case 't':
            cp->io_thread_cnt = atoi(optarg);
            break;

        case 'w':
            cp->work_thread_cnt = atoi(optarg);
            break;

        case 'V':
            fprintf(stderr, "BUILD_TIME: %s %s\n", __DATE__, __TIME__);
            return AC_ERROR;

        case 'h':
            print_usage(argv[0]);
            return AC_ERROR;


        default:
            break;
        }
    }

    return AC_OK;
}


/**
 * 处理函数
 */
static int echo_process(ac_request_t *r)
{
    // 直接用in packet
    echo_packet_t           *reply;
    reply = (echo_packet_t *) r->ipacket;

    if (!reply)
        return AC_ERROR;
    r->retcode=AC_OK;
    //taw_free(r->ipacket);
    r->opacket = r->ipacket;
    return AC_OK;
}

static int echo_connect(ac_connection_t *c)
{
  //  ac_error_log("handler->on_connect callback\n");
    return AC_OK;
}
static int echo_idle(ac_connection_t *c)
{
    ac_debug_log("echo_idle c=%p\n",c);
    return AC_OK;
}
static int echo_async_process(ac_request_t *r)
{
    echo_packet_t           *reply;
    reply = (echo_packet_t *) r->ipacket;
    ac_connection_t *c = ((ac_message_t*)(r->ms))->c;
    ac_debug_log("io thread process c=%p c->addr_udp=%p",c,c->addr_udp);

    if (!reply)
        return AC_ERROR;

    ac_thread_pool_push(cp.threads, r, ac_hash_key((uint64_t)(long)r));
    return AC_AGAIN;
}

static int easy_async_request_process(ac_request_t *r, void *args)
{

    echo_packet_t           *reply = (echo_packet_t *) r->ipacket;
    echo_packet_t           *opacket;
    opacket = (echo_packet_t*)taw_malloc("echo_packet_t",sizeof(echo_packet_t)+reply->len,0);
    opacket->len = reply->len;
    memcpy(opacket->buffer, reply->data,reply->len);
    opacket->data = opacket->buffer;
    r->opacket = opacket;

    return AC_OK;
}


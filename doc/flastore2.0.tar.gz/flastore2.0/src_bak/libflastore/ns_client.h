#ifndef NS_CLIENT_H
#define NS_CLIENT_H

//#include "fl_struct.h"
#include <ac.h>
#include "comm_buf.h"
#include "fl_define.h"

typedef struct _NodeServerClient{
    ConnManager           conn_manager;

}NodeServerClient;

int write_ns_file(NodeServerClient *ns_client, const char* name, uint64_t offset, uint64_t length, uint32_t protocol_flag, void* data,ZYBuffer *file_info_ex);

ZYBuffer *read_ns_file(NodeServerClient *ns_client,const char* name, uint64_t offset, uint32_t protocol_flag, const char* file_name, uint64_t file_offset, uint64_t length);

int close_ns(NodeServerClient *ns_client, uint32_t flag);//�ر�ns
#endif // NS_CLIENT_H

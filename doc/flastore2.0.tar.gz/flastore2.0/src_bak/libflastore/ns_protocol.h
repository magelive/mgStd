#ifndef NS_PROTOCOL_H
#define NS_PROTOCOL_H

#include "comm_buf.h"

#define FL_REQUEST_WRITE                0
#define FL_REQUEST_READ                 1
#define FL_COMMAND_CLOSE_NS             2
#define FL_COMMAND_DELETE_NS_FILE       3
#define FL_COMMAND_FLUSH_NS_CACHE       4

#define FL_REQUEST_MAX                  26

CommBuf *create_write_ns_request(const char *name, uint64_t offset, uint64_t length, uint32_t protocol_flag, void* data,ZYBuffer *file_info_ex);

CommBuf *create_read_ns_request(const char* name, uint64_t offset, uint32_t protocol_flag, const char* file_name, uint64_t file_offset,uint64_t length);

CommBuf *create_close_ns_request(uint32_t flag);

CommBuf *create_delete_ns_file_request(uint32_t flag, uint64_t time);

CommBuf *create_flush_ns_cache_request(uint32_t flag);


#endif // NS_PROTOCOL_H

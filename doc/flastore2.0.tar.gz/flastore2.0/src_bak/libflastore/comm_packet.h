#ifndef FL_COMM_PACKET_H
#define FL_COMM_PACKET_H

#include "comm_buf.h"
#include <ngtawstd/zytypes.h>

/**
 * decode
 */
static void *comm_decode(ac_message_t *m)
{
    CommBuf           *packet;
    /*
    if (m->max_read_len==0) {
        memcpy(&m->max_read_len,m->input->pos,4);
        m->input->pos+=4;
        fl_debug_log("comm_decode max_read_len:%d\n",m->max_read_len);
    }
    */
    int len = m->input->last - m->input->pos;

    /*
    if(m->next_read_len==0){
        m->next_read_len = len;
    }
    if (m->next_read_len < m->max_read_len ) {
            m->next_read_len += len;
            fl_debug_log("comm_decode next_read_len:%d\n",m->next_read_len);
            return NULL;
    }
    */

    if ((packet = (CommBuf *)taw_malloc("CommBuf", sizeof(CommBuf)+len,0)) == NULL)
        return NULL;//SERVER在rs_request中析构，如果rs_request中没有用新的CommBuf，那么在encode中析构
                    //CLIENT在session的i packet中析构。
    packet->data_ptr = &packet->data[0];
    memcpy(packet->data_ptr, m->input->pos, len);
    packet->len = len;
    m->input->pos = m->input->last;

    //int replay_num = *((int*)packet->data_ptr);
    //fl_debug_log("header ===========%d",replay_num);


    return packet;
}

/**
 * encode
 */
static int comm_encode(ac_request_t *r, void *data)
{
    CommBuf           *packet;
    ac_buf_t              *b;
    ac_connection_t       *c;
    ac_message_t          *m;
    m = (ac_message_t *) r->ms;
    c = m->c;

    packet = (CommBuf *) data;
   // fl_debug_log("comm_encode data:%p\n",packet->data_ptr);
    fl_debug_log("comm_encode len:%d \n",packet->len);
    if(!data)
        return AC_ERROR;

    if ((b = ac_buf_create( packet->len )) == NULL)
        return AC_ERROR;

    //memcpy(b->pos, &packet->len, 4);
    //memcpy(b->pos+4, packet->data_ptr, packet->len);
   // b->last += packet->len+4;
    memcpy(b->pos, packet->data_ptr, packet->len);
    b->last += packet->len;

    ac_request_addbuf(r, b);

    if(c->type==AC_TYPE_SERVER)//析构rs_request的opacket
        taw_free(packet);

    return AC_OK;
}


#endif // FL_COMM_PACKET_H

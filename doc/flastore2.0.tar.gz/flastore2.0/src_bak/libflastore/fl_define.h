#ifndef FL_DEFINE_H
#define FL_DEFINE_H

/** Portability macros for C code. */

#if defined (__GLIBC__)
# include <endian.h>
# if (__BYTE_ORDER == __LITTLE_ENDIAN)
#  define FL_LITTLE_ENDIAN
# elif (__BYTE_ORDER == __BIG_ENDIAN)
#  define FL_BIG_ENDIAN
# elif (__BYTE_ORDER == __PDP_ENDIAN)
#  define FL_PDP_ENDIAN
# else
#  error Unknown machine endianness detected.
# endif
# define FL_BYTE_ORDER __BYTE_ORDER
#elif defined(__sparc) || defined(__sparc__) \
   || defined(_POWER) || defined(__powerpc__) \
   || defined(__ppc__) || defined(__hpux) \
   || defined(_MIPSEB) || defined(_POWER) \
   || defined(__s390__)
# define FL_BIG_ENDIAN
# define FL_BYTE_ORDER 4321
#elif defined(__i386__) || defined(__alpha__) \
   || defined(__ia64) || defined(__ia64__) \
   || defined(_M_IX86) || defined(_M_IA64) \
   || defined(_M_ALPHA) || defined(__amd64) \
   || defined(__amd64__) || defined(_M_AMD64) \
   || defined(__x86_64) || defined(__x86_64__) \
   || defined(_M_X64)

# define FL_LITTLE_ENDIAN
# define FL_BYTE_ORDER 1234
#else
# error The file Common/endian.h needs to be set up for your CPU type.
#endif

/* Name mangling */
#ifdef __cplusplus
#  define FL_EXTERN_C  extern "C"
#else
#  define FL_EXTERN_C  extern
#endif

/* Calling convention */
#ifdef _MSC_VER
#  define FL_CDECL      __cdecl
#else
#  define FL_CDECL
#endif

#define FL_PUBLIC(ret_type)     ret_type FL_CDECL
#define FL_EXTERN(ret_type)     FL_EXTERN_C FL_PUBLIC(ret_type)

#ifdef __GNUC__
#  define FL_NORETURN __attribute__((__noreturn__))
#  define FL_FORMAT(x) __attribute__((format x))
#  define FL_FUNC __PRETTY_FUNCTION__
#  define FL_COND(x, _prob_) __builtin_expect(x, _prob_)
#else
#  define FL_NORETURN
#  define FL_FORMAT(x)
#  ifndef __attribute__
#    define __attribute__(x)
#  endif
#  define FL_FUNC __func__
#  define FL_COND(x, _prob_) (x)
#endif

#define FL_LIKELY(x) FL_COND(x, 1)
#define FL_UNLIKELY(x) FL_COND(x, 0)

/* We want C limit macros, even when using C++ compilers */
#ifndef __STDC_LIMIT_MACROS
#  define __STDC_LIMIT_MACROS
#endif

#define FL_OK             0
#define FL_ERROR          1
#define FL_CLOSED         2
#define FL_SAFE_MODE      3

#define FL_OVER_WRITE     0
#define FL_SINGLE         1
#define FL_REPLICATIONS   2

#define FL_HTTP_GET       0
#define FL_HTTP_POST      1
#define FL_SMTP           2
#define FL_POP3           3
#define FL_FTP            4
#define FL_PCAP           5
#define FL_PROTOCOL_MAX   6

#define FL_READ_RETRY_TIMES      2
#define FL_WRITE_RETRY_TIMES     3

#define FL_DEFAULT_CONF_FILE  "/etc/flastore2.conf"

#define fl_trace_log      ac_trace_log
#define fl_debug_log      ac_info_log
#define fl_info_log       ac_info_log
#define fl_warn_log       ac_warn_log
#define fl_error_log      ac_error_log
#define fl_fatal_log      ac_fatal_log


#define RS_TIMER_INTERVEL 30000
#define RS_IPC_DEFAULT_FILE_PATH "/home/czl/flastore/ipc"

#define NS_ALIGN_SIZE 512
#define NS_TIMER_INTERVEL 3000 //debug 30000

#define ns_align(length) (length%NS_ALIGN_SIZE>0) ? (length/NS_ALIGN_SIZE+1)*NS_ALIGN_SIZE : length

#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <strings.h>
#include <stdlib.h>
#include <ac.h>
#include <ac_util.h>
#endif /* FL_DEFINE_H */

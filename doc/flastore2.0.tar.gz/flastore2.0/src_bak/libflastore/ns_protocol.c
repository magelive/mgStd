#include "ns_protocol.h"
#include "serialization.h"


//与Ns的通信协议
CommBuf *create_write_ns_request(const char* name, uint64_t offset, uint64_t length, uint32_t protocol_flag, void* data, ZYBuffer *file_info_ex){

    CommBuf *cbuf = commbuf_new(FL_REQUEST_WRITE, encoded_length_str16(name) + 8 + 8 + 4 + length + _ZBLen(file_info_ex));

    encode_str16(&cbuf->data_ptr, name,strlen(name));
	encode_i64(&cbuf->data_ptr, offset);
    encode_i64(&cbuf->data_ptr, length);
    encode_i32(&cbuf->data_ptr, protocol_flag);
    memcpy(cbuf->data_ptr, data, length);
    fl_debug_log("create_write_ns_request _ZBLen(file_info_ex)=%d ",_ZBLen(file_info_ex));
    memcpy(cbuf->data_ptr+length, file_info_ex->data,  _ZBLen(file_info_ex));

    cbuf->data_ptr = &cbuf->data[0];

    return cbuf;
}

CommBuf *create_read_ns_request(const char* name, uint64_t offset, uint32_t protocol_flag,const char* file_name, uint64_t file_offset, uint64_t length){

    CommBuf *cbuf = commbuf_new(FL_REQUEST_READ,encoded_length_str16(file_name)+encoded_length_str16(name) + 8 + 8 + 8 + 4);
    encode_str16(&cbuf->data_ptr, name,strlen(name));
	encode_i64(&cbuf->data_ptr, offset);
    encode_i32(&cbuf->data_ptr, protocol_flag);
    encode_str16(&cbuf->data_ptr, file_name,strlen(file_name));
	encode_i64(&cbuf->data_ptr, file_offset);
    encode_i64(&cbuf->data_ptr, length);
    cbuf->data_ptr = &cbuf->data[0];

    return cbuf;
}

CommBuf *create_close_ns_request(uint32_t flag){

    CommBuf *cbuf = commbuf_new(FL_COMMAND_CLOSE_NS, 4);
    encode_i32(&cbuf->data_ptr, flag);
    cbuf->data_ptr = &cbuf->data[0];

    return cbuf;
}

CommBuf *create_flush_ns_cache_request(uint32_t flag){

    CommBuf *cbuf = commbuf_new(FL_COMMAND_FLUSH_NS_CACHE, 4);
    encode_i32(&cbuf->data_ptr, flag);
    cbuf->data_ptr = &cbuf->data[0];

    return cbuf;
}
CommBuf *create_delete_ns_file_request(uint32_t flag, uint64_t time){

    CommBuf *cbuf = commbuf_new(FL_COMMAND_DELETE_NS_FILE, 4 + 8);
    encode_i32(&cbuf->data_ptr, flag);
    encode_i64(&cbuf->data_ptr, time);
    cbuf->data_ptr = &cbuf->data[0];

    return cbuf;
}

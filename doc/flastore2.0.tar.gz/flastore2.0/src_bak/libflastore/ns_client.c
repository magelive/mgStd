//rpc 调用 node server 的client 接口函数

//用于 1、用户客户端调用读写接口
//     2、root server下发block操作命令，关闭ns等。
#include "ns_client.h"
#include "ns_protocol.h"
#include <ac_util.h>
#include <unistd.h>
#include "serialization.h"

extern  uint32_t decode_i32(const uint8_t **bufp, size_t *remainp);

int write_ns_file(NodeServerClient *ns_client, const char* name, uint64_t offset, uint64_t length, uint32_t protocol_flag, void* data,ZYBuffer *file_info_ex)
{
    fl_debug_log("NodeServerClient------------>  write_ns_file");

    CommBuf *cbp = create_write_ns_request(name, offset, length, protocol_flag, data, file_info_ex);
    CommBuf *cbp_cb = send_message_sync(&ns_client->conn_manager, cbp, handler_easy, FL_COMM_DEFAULT_TIMEOUT);

    if(cbp_cb==NULL)
         return 0;

    size_t remain= cbp_cb->len;
    int reply_num = decode_i32((const uint8_t**)&cbp_cb->data_ptr, &remain);
    fl_debug_log("write_ns_file reply: %d ", reply_num);

    taw_free(cbp);
    taw_free(cbp_cb);
    return reply_num;
}

ZYBuffer *read_ns_file(NodeServerClient *ns_client,const char* name, uint64_t offset, uint32_t protocol_flag, const char* file_name, uint64_t file_offset, uint64_t length)
{
    fl_debug_log("NodeServerClient------------> read_ns_file");

    CommBuf *cbp = create_read_ns_request(name, offset, protocol_flag, file_name, file_offset, length);
    CommBuf *cbp_cb = send_message_sync(&ns_client->conn_manager, cbp, handler_easy, 5000);

    if(cbp_cb==NULL)
         return 0;

    ZYBuffer  *buffer = zyload_zybuffer_ptr(cbp_cb->data_ptr,cbp_cb->len);
    // fl_debug_log("NodeServerClient read_ns_file buffer:%s",(char*)buffer->data);

    taw_free(cbp);
    taw_free(cbp_cb);
    return buffer;
}

int close_ns(NodeServerClient *ns_client, uint32_t flag){
    fl_debug_log("NodeServerClient------------>close_ns");
    CommBuf *cbp = create_close_ns_request(flag);

    CommBuf *cbp_cb = send_message_sync(&ns_client->conn_manager, cbp, handler_easy, 60000*30);
    taw_free(cbp);
    taw_free(cbp_cb);
    return 0;
}

int flush_ns_cache(NodeServerClient *ns_client, uint32_t flag){
    fl_debug_log("NodeServerClient------------>flush_ns_cache");
    CommBuf *cbp = create_flush_ns_cache_request(flag);

    CommBuf *cbp_cb = send_message_sync(&ns_client->conn_manager, cbp, handler_easy, 60000*30);
    taw_free(cbp);
    taw_free(cbp_cb);
    return 0;
}

int delete_ns_file(NodeServerClient *ns_client, uint32_t flag, time_t time){
    fl_debug_log("NodeServerClient------------>delete_ns_file");
    CommBuf *cbp = create_delete_ns_file_request(flag,time);

    CommBuf *cbp_cb = send_message_sync(&ns_client->conn_manager, cbp, handler_easy, FL_COMM_DEFAULT_TIMEOUT);
    taw_free(cbp);
    taw_free(cbp_cb);
    return 0;
}

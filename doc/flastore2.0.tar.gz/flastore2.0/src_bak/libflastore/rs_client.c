//rpc 调用 root server 的client 接口函数

//用于 1、用户客户端获得元数据信息,新建文件，关闭文件
//     2、 node server向 root server 注册，汇报block变化，写完收完block。
#include "rs_client.h"
#include "rs_protocol.h"
#include <ac_util.h>
#include <unistd.h>
#include "serialization.h"

extern  uint32_t decode_i32(const uint8_t **bufp, size_t *remainp);


ZYList* create_file(RootServerClient *rs_client, const char *name, uint64_t block_len, uint32_t protocol_flag){
    fl_debug_log("RSclient------------>create_file");

    char client_name[128];
    gethostname(client_name, sizeof(client_name));

    CommBuf *cbp = create_create_file_request(name, client_name, block_len, protocol_flag);
    CommBuf *cbp_cb = send_message_sync(&rs_client->conn_manager, cbp, handler_easy, FL_COMM_DEFAULT_TIMEOUT);
    if(cbp_cb==NULL)
    {
        taw_free(cbp);
        taw_free(cbp_cb);
        return NULL;
    }
    fl_debug_log("reply cbp_cb: %p,len=%d", cbp_cb,cbp_cb->len-4);

    size_t remain = cbp_cb->len;
    int reply_num = decode_i32((const uint8_t**)&cbp_cb->data_ptr, &remain);
    fl_debug_log("reply: %d ns locations", reply_num-2);
    ZYList *ns_locations = NULL;
    if(reply_num){

        ns_locations = zyload_zylist_ptr(cbp_cb->data_ptr,cbp_cb->len-4);
        /*
        ZYElem* melement = NULL;
        ZYLIST_FOR_EACH(ns_locations,melement)
        {
            if(melement->type==ZYT_INT64){
                fl_debug_log("create_file get filesize %lld",zyelem_get_int64(melement,NULL));
            }
            else{
                fl_debug_log("create_file get ns locations %s", zyelem_get_str(melement,NULL));
            }

        }
        */
    }
    else{
        fl_debug_log("file closed or no node server.can not write");
    }

    taw_free(cbp);
    taw_free(cbp_cb);
    return ns_locations;
}

//追加文件，随机返回ns位置信息。
ZYList* append_file(RootServerClient *rs_client, const char *name, uint32_t protocol_flag){
    fl_debug_log("RSclient------------>append_file");

    CommBuf *cbp = create_append_file_request(name,protocol_flag);
    CommBuf *cbp_cb = send_message_sync(&rs_client->conn_manager, cbp, handler_easy, FL_COMM_DEFAULT_TIMEOUT);
    if(cbp_cb==NULL)
    {
        taw_free(cbp);
        taw_free(cbp_cb);
        return NULL;
    }
    size_t remain = cbp_cb->len;
    int reply_num = decode_i32((const uint8_t**)&cbp_cb->data_ptr, &remain);
    fl_debug_log("reply: %d ns locations", reply_num-1);

    ZYList *ns_locations = zyload_zylist_ptr(cbp_cb->data_ptr,cbp_cb->len-4);
    if(!ns_locations)
     {
        taw_free(cbp);
        taw_free(cbp_cb);
        return NULL;
    }
    /*
    ZYElem* melement = NULL;
    ZYLIST_FOR_EACH(ns_locations,melement)
    {
            if(melement->type==ZYT_INT64)
            {
                uint64_t offset = zyelem_get_int64(melement,NULL);
                fl_debug_log("append_file get offset %lld",offset);
            }
            else
            {
                char *location = zyelem_get_str(melement,NULL);
                fl_debug_log("append_file get ns locations %s",location);
            }

    }*/

    taw_free(cbp);
    taw_free(cbp_cb);
    return ns_locations;
}

//关闭文件，并PUBLISH发布消息。异步发送，不必等返回值，发送成功则返回。
int close_file(RootServerClient *rs_client, const char *name, uint32_t protocol_flag){
    fl_debug_log("RSclient------------>close_file");
    CommBuf *cbp = create_close_file_request(name,protocol_flag);

    send_message_async(&rs_client->conn_manager, cbp, handler_easy, FL_COMM_DEFAULT_TIMEOUT);
    taw_free(cbp);
    return 0;
}

//关闭rs
int close_rs(RootServerClient *rs_client, uint32_t flag){
    fl_debug_log("RSclient------------>close_rs");
    CommBuf *cbp = create_close_rs_request(flag);

    CommBuf *cbp_cb = send_message_sync(&rs_client->conn_manager, cbp, handler_easy, FL_COMM_DEFAULT_TIMEOUT);
    taw_free(cbp);
    taw_free(cbp_cb);
    return 0;
}

int rename_file(RootServerClient *rs_client, const char* old_name, const char* new_name, uint32_t protocol_flag){
     fl_debug_log("RSclient------------>rename_file");

    CommBuf *cbp = create_rename_file_request(old_name, new_name, protocol_flag);
    CommBuf *cbp_cb = send_message_sync(&rs_client->conn_manager, cbp, handler_easy, FL_COMM_DEFAULT_TIMEOUT);
    if(cbp_cb==NULL)
    {
        taw_free(cbp);
        taw_free(cbp_cb);
        return FL_ERROR;
    }
    size_t remain= cbp_cb->len;
    int reply_num = decode_i32((const uint8_t**)&cbp_cb->data_ptr, &remain);
    fl_debug_log("rename_file reply: %d ", reply_num);

    taw_free(cbp);
    taw_free(cbp_cb);
    return reply_num;
}

//获得一个block的所有ns位置信息。
ZYList* get_block_locations(RootServerClient *rs_client, const char *name, uint64_t offset, uint32_t protocol_flag){
     fl_debug_log("RSclient------------>get_block_locations");

    CommBuf *cbp = create_get_block_locations_request(name, offset, protocol_flag);
    CommBuf *cbp_cb = send_message_sync(&rs_client->conn_manager, cbp, handler_easy, FL_COMM_DEFAULT_TIMEOUT);
    if(cbp_cb==NULL)
     {
        taw_free(cbp);
        taw_free(cbp_cb);
        return NULL;
    }
     taw_free(cbp);
    size_t remain = cbp_cb->len;
    int reply_num = decode_i32((const uint8_t**)&cbp_cb->data_ptr, &remain);
    fl_debug_log("reply: %d ns locations", reply_num);

    if(reply_num){
        ZYList *ns_locations = zyload_zylist_ptr(cbp_cb->data_ptr,cbp_cb->len-4);
        /*
        ZYElem* melement = NULL;
        ZYLIST_FOR_EACH(ns_locations,melement)
        {

            char *location = zyelem_get_str(melement,NULL);
            fl_debug_log("get_block_locations get ns locations %s",location);

        }
        */
        taw_free(cbp_cb);

        return ns_locations;
    }
    else{
        taw_free(cbp_cb);
         return NULL;
    }


}

//返回文件的具体信息,第一个node是ZYList，文件信息，接着是ZYMap，block信息。
ZYMap *get_fileinfo(RootServerClient *rs_client, const char* name, uint32_t protocol_flag)
{
    fl_debug_log("RSclient------------>get_fileinfo");

    CommBuf *cbp = create_get_fileinfo_request(name,protocol_flag);
    CommBuf *cbp_cb = send_message_sync(&rs_client->conn_manager, cbp, handler_easy, FL_COMM_DEFAULT_TIMEOUT);
    if(cbp_cb==NULL)
    {
        taw_free(cbp);
        taw_free(cbp_cb);
        return NULL;
    }
    fl_debug_log("get_fileinfo zyload_zylist_ptr len=%d,data=%p",cbp_cb->len,cbp_cb->data_ptr);

    ZYMap  *block_map = zyload_zymap_ptr(cbp_cb->data_ptr,cbp_cb->len);
    fl_debug_log("get_fileinfo block_map =%p",block_map);
    taw_free(cbp);
    if(!block_map)
    {
        taw_free(cbp_cb);
        taw_free(cbp_cb);
        return NULL;
    }
    /*
    ZYElem* melement = NULL;
    void* key = NULL;
    int key_len = 0;
    ZYMAP_FOR_EACH(block_map,key,key_len,melement)
    {
        ZYList* block_info = zyelem_get_zylist(melement,NULL);
        fl_debug_log("get_fileinfo key=%s,ken_len=%d",(char*)key,key_len);
        uint32_t ns_id = zylist_get_int32(block_info,0);
        const char* file_path = zylist_get_str(block_info,1);
        uint64_t file_offset = zylist_get_int64(block_info,2);
        uint64_t length = zylist_get_int64(block_info,3);

        fl_debug_log("get block info return  ns_id=%d,file_path=%s,file_offset=%lld,length=%lld",
                 ns_id,file_path,file_offset,length);
    }
    */
    taw_free(cbp_cb);
    return block_map;
}

//返回一个block的具体信息
ZYList* get_blockinfo(RootServerClient *rs_client, const char* name,  uint64_t offset, uint32_t protocol_flag)
{
     fl_debug_log("RSclient------------>get_blockinfo");

    CommBuf *cbp = create_get_blockinfo_request(name, offset, protocol_flag);
    CommBuf *cbp_cb = send_message_sync(&rs_client->conn_manager, cbp, handler_easy, FL_COMM_DEFAULT_TIMEOUT);
    if(cbp_cb==NULL){
        taw_free(cbp);
        taw_free(cbp_cb);
        return NULL;
    }

    size_t remain = cbp_cb->len;
    int reply_num = decode_i32((const uint8_t**)&cbp_cb->data_ptr, &remain);
    fl_debug_log("reply: %d", reply_num);

    taw_free(cbp);
    if(reply_num){
        ZYList *block_info = zyload_zylist_ptr(cbp_cb->data_ptr,cbp_cb->len-4);
       // const char* ns_addr = zylist_get_str(block_info,0);
       // const char* file_path = zylist_get_str(block_info,1);
        //uint64_t file_offset = zylist_get_int64(block_info,2);
       // uint64_t length = zylist_get_int64(block_info,3);
        //fl_debug_log("get block info return  ns_addr=%s,file_path=%s,file_offset=%lld,length=%lld",
         //        ns_addr,file_path,file_offset,length);
        taw_free(cbp_cb);
        return block_info;
    }
    else{
        taw_free(cbp_cb);
        return NULL;
    }

}

//写完一个block后报告给RS，更新元数据
int block_report(RootServerClient *rs_client, const char* name, uint64_t offset, ZYList *block_info, uint32_t protocol_flag){
    fl_debug_log("RSclient------------>block_report");

    CommBuf *cbp = create_block_report_request(name, offset, block_info, protocol_flag);
    send_message_async(&rs_client->conn_manager, cbp, handler_easy, FL_COMM_DEFAULT_TIMEOUT);
    taw_free(cbp);
    return 0;
}

int block_report_sync(RootServerClient *rs_client, const char* name, uint64_t offset, ZYList *block_info, uint32_t protocol_flag){
    fl_debug_log("RSclient------------>block_report_sync offset=%lld",offset);

    CommBuf *cbp = create_block_report_request(name, offset, block_info, protocol_flag);
    CommBuf *cbp_cb = send_message_sync(&rs_client->conn_manager, cbp, handler_easy, FL_COMM_DEFAULT_TIMEOUT);
     fl_debug_log("RSclient...........block_report_sync reply offset=%lld",offset);
     taw_free(cbp);
     taw_free(cbp_cb);
    return 0;
}

//收到block（未写入磁盘，可从内存读）后报告给RS，更新元数据
int block_received(RootServerClient *rs_client, const char* name, uint64_t offset, uint32_t ns_id, uint32_t protocol_flag,void* md5ctx){
    fl_debug_log("RSclient------------>block_received offset=%lld",offset);

    CommBuf *cbp = create_block_received_request(name, offset, ns_id, protocol_flag,md5ctx);
    CommBuf *cbp_cb = send_message_sync(&rs_client->conn_manager, cbp, handler_easy, FL_COMM_DEFAULT_TIMEOUT);
    taw_free(cbp);
    fl_debug_log("RSclient...........block_received reply offset=%lld",offset);
    taw_free(cbp_cb);
    return 0;
}

//node server注册到RS，分配一个ns id
int ns_register(RootServerClient *rs_client, const char* location, uint64_t max_size){
    fl_debug_log("RSclient------------>ns_register");

    char client_name[128];
    gethostname(client_name, sizeof(client_name));

    CommBuf *cbp = create_ns_register_request(location, max_size);
    CommBuf *cbp_cb = send_message_sync(&rs_client->conn_manager, cbp, handler_easy, FL_COMM_DEFAULT_TIMEOUT);
    if(cbp_cb==NULL)
    {
        taw_free(cbp);
        taw_free(cbp_cb);
        return 0;
    }
    size_t remain = cbp_cb->len;
    fl_debug_log("ns_register data_ptr:%p data=%d remain=%d",cbp_cb->data_ptr, *(int*)cbp_cb->data_ptr,remain);
    int ns_id = decode_i32((const uint8_t**)&cbp_cb->data_ptr, &remain);
    fl_debug_log("ns_register ns_id: %d ", ns_id);

    taw_free(cbp);
    taw_free(cbp_cb);
    return ns_id;
}

ZYList* get_ns_server_list(RootServerClient *rs_client)
{
    fl_debug_log("RSclient------------>get_ns_server_list");

    CommBuf *cbp = create_get_ns_server_list_request();

    CommBuf *cbp_cb = send_message_sync(&rs_client->conn_manager, cbp, handler_easy, FL_COMM_DEFAULT_TIMEOUT);
    if(cbp_cb==NULL)
    {
        taw_free(cbp);
        taw_free(cbp_cb);
        return NULL;
    }

    size_t remain = cbp_cb->len;
    int reply_num = decode_i32((const uint8_t**)&cbp_cb->data_ptr, &remain);
    fl_debug_log("reply: %d", reply_num);

    taw_free(cbp);
    if(reply_num){
        ZYList* ns_list = zyload_zylist_ptr(cbp_cb->data_ptr,cbp_cb->len-4);
        taw_free(cbp_cb);
        return ns_list;
    }

    else{
        taw_free(cbp_cb);
        return NULL;
    }

}



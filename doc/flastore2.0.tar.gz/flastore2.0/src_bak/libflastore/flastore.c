/**
 * @brief
 *
 * @file  flastore.c
 * @version  1.0
 * @date  2014年08月21日 17时07分35秒
 * @author  ZHANG Fengyu (张凤羽), zhang_fengyu@topsec.com.cn
 * @pre
 * @warning
 * @bug
 */
#include "flastore.h"
#include <sys/stat.h>
#include <stdlib.h>
#include <string.h>
#include <sys/errno.h>
#include "fl_define.h"
#include <stdarg.h>
#include <time.h>
#include <sys/vfs.h>

int fl_make_multi_dir(char *path, int permission)
{
    int i = 0;
    int iRet;
    int iLen;
    char* path_str;

    if(NULL == path)
    {
        return 0;
    }

    path_str = strdup(path);
    iLen = strlen(path_str);

    for (i = 1; i < iLen; i++)
    {
        if (path_str[i] == '\\' || path_str[i] == '/')
        {
            path_str[i] = '\0';

            iRet = access(path_str,0);
            if (iRet != 0)
            {
                iRet = mkdir(path_str, permission);
                if (iRet != 0)
                {
                    return -1;
                }
            }

            path_str[i] = '/';
        }
    }

    iRet = mkdir(path_str, permission);
    free(path_str);
    return iRet;
}

int fl_mkdir_p(char* path, int permission)
{
    int i, rc=0;

    if (path == NULL)
	return -1;

    char* p = path;
    for (i=1; path[i] != '\0'; i++)
    {
	if (path[i] == '/')
	{
	    path[i] = '\0';
	    rc = mkdir(path, permission);
	    if ((rc != 0 )&& (errno != EEXIST))
	    {
            fl_error_log("Make directory failed:%d,%s\n", errno, strerror(errno));
            path[i] = '/';
            return -1;
	    }
	    path[i] = '/';
	}
    }
    mkdir(p, permission);
    if ((rc != 0 )&& (errno != EEXIST))
    {
        fl_error_log("Make directory failed:%d,%s\n", errno, strerror(errno));
        return -1;
    }
    return 0;
}

/*
http.get   HTTP下载
http.post  HTTP上传
smtp      发送邮件
pop3      接收邮件
ftp        ftp下载、上传
pcap      数据采集
*/
const char* protocol_flag_to_str(uint32_t flag)
{
    switch(flag){
        case FL_HTTP_GET: return "http.get";
        case FL_HTTP_POST: return "http.post";
        case FL_SMTP: return "smtp";
        case FL_POP3: return "pop3";
        case FL_FTP: return "ftp";
        case FL_PCAP: return "pcap";
        default: return "";
    }
}

char* get_date_dir(char* datastr)
{
    time_t now = time(NULL);
    struct tm tm;
    localtime_r(&now,&tm);
    strftime(datastr,9,"%y/%m/%d",&tm);

}

char* get_date_dir_by_time(char* datastr, time_t time)
{

    struct tm tm;
    localtime_r(&time,&tm);
    strftime(datastr,9,"%y/%m/%d",&tm);

    //sprintf(datastr,"14/11/%d",10);//DEBUG
}

uint64_t get_maxsize(char* dir)
{
    struct statfs diskInfo;
    statfs(dir, &diskInfo);
    return diskInfo.f_bfree*diskInfo.f_bsize;
}



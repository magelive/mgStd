#include <ngtawstd/mem.h>
#include "comm_buf.h"
#include "serialization.h"
#include "comm_packet.h"


extern  void *comm_decode(ac_message_t *m);
extern  int comm_encode(ac_request_t *r, void *data);

extern void encode_i32(uint8_t **bufp, uint32_t val);

CommBuf *commbuf_new(int header, int data_len){

    CommBuf               *cbf;
    //if ((cbf = ac_session_packet_create(CommBuf, s, 4 + data_len)) == NULL)
   if ((cbf = (CommBuf*)taw_malloc("CommBuf", sizeof(CommBuf)+ 4 + data_len, 0)) == NULL)
        return NULL;

    cbf->data_ptr = &cbf->data[0];
    cbf->len = 4 + data_len;

    encode_i32(&cbf->data_ptr, header);

    return cbf;
}

//��ʼ������
int init_comm(ConnManager *conn_manager)
{
  // zytypes_use_slab=0;
   conn_manager->io_thread_count=1;
   conn_manager->comm=NULL;
   if ((conn_manager->comm = ac_acio_create(conn_manager->comm, conn_manager->io_thread_count)) == NULL) {
        return 1;
    }

    // Ϊ�����˿����ô���������������һ�������˿�
    memset( &conn_manager->handler, 0, sizeof(conn_manager->handler));
    conn_manager->handler.decode = comm_decode;
    conn_manager->handler.encode = comm_encode;
    conn_manager->handler.process = handler_easy;
    //conn_manager->handler.new_packet = echo_new_packet;
   // conn_manager->handler.on_disconnect = echo_disconnect;
    //conn_manager->handler.user_data = (void *)(long)cp.request_size;

    if (ac_acio_start(conn_manager->comm))
        return 1;


    if (ac_connect(conn_manager->comm, conn_manager->addr, &conn_manager->handler, 0, NULL, 0) != AC_OK) {
        return 1;
    }
    return 0;

}


void disconnect(ConnManager *conn_manager)
{
    ac_acio_stop(conn_manager->comm);

}

void wait_and_destory(ConnManager *conn_manager)
{
    ac_acio_wait(conn_manager->comm);
    ac_acio_destroy(conn_manager->comm);
}

//������Ϣ��ͬ��
CommBuf  *send_message_sync(ConnManager *conn_manager, CommBuf *cbp, ac_io_process_pt *handler, int timeout)
{

    ac_session_t      *session;
    CommBuf* packet = ac_session_packet_create(CommBuf, session, cbp->len);
    packet->data_ptr = &packet->data[0];
    memcpy(packet->data_ptr, cbp->data_ptr, cbp->len);
    packet->len = cbp->len;

    int tmout;
    if(timeout>0)
        tmout = timeout;
    else
        tmout = conn_manager->timeout;

    ac_session_set_request(session, packet, tmout, NULL);
    session->process = handler;

    //send and wait for reply
    CommBuf  *reply = (CommBuf *)ac_client_send(conn_manager->comm, conn_manager->addr, session);

    if (reply == NULL) {
        fl_error_log("reply is null.");
    }
    //reply��s->r.ipacket��Ҳ����decode�е�packet����Ҫ�ͷ�
    ac_session_destroy(session);//�ͷ�ac_session_packet_create�е�session
    return reply;

}

//������Ϣ���첽
int send_message_async(ConnManager *conn_manager, CommBuf *cbp, ac_io_process_pt *handler, int timeout)
{
    ac_session_t      *session;
    CommBuf* packet = ac_session_packet_create(CommBuf, session, cbp->len);
    packet->data_ptr = &packet->data[0];
    memcpy(packet->data_ptr, cbp->data_ptr, cbp->len);
    packet->len = cbp->len;

    int tmout;
    if(timeout>0)
        tmout = timeout;
    else
        tmout = conn_manager->timeout;

    ac_session_set_request(session, packet, tmout, NULL);
    session->process = handler;

    //send
    int ret = ac_client_send_request(conn_manager->comm, conn_manager->addr, session);
    taw_free(session->r.ipacket);//�ͷ�decode�е�packet
    ac_session_destroy(session);//�ͷ�ac_session_packet_create�е�session
    return ret;
}

int handler_easy(ac_request_t *r)
{
    //���������ط���
     CommBuf           *reply;
     reply = (CommBuf *) r->ipacket;
     if(reply){

        if(reply->len == 4){
            int replay_num = *((int*)reply->data_ptr);
            fl_debug_log("handler_easy reply: %d", replay_num);
            switch(replay_num){
                case FL_OK: return AC_OK;
                case FL_ERROR: return AC_OK;
                case FL_CLOSED:
                    fl_error_log("Server is NOT STARTED.");
                    return AC_OK;
                case FL_SAFE_MODE:
                    fl_error_log("Server is in SAFE MODE.");
                    return AC_OK;
                default:
                    return AC_OK;
            }
        }
        else{
     //       fl_debug_log("handler_easy reply: %p", reply->data_ptr);
        }

     }

     return AC_OK;
}


int response_ok(ac_request_t *r)
{
     return response_i32(r, FL_OK);
}

int response_error(ac_request_t *r)
{
     return response_i32(r, FL_ERROR);
}

int response_i32(ac_request_t *r, uint32_t num)
{
     int len = sizeof(CommBuf) + 4;
     CommBuf * cbf_cb = (CommBuf *) taw_malloc("CommBuf", len, 0);
     cbf_cb->data_ptr = &cbf_cb->data[0];
     fl_debug_log("response_i32 num=%d",num);
     encode_i32(&cbf_cb->data_ptr, num);
     cbf_cb->len = 4;
     cbf_cb->data_ptr = &cbf_cb->data[0];
     r->opacket = (void* )cbf_cb;
    // r->opacket = r->ipacket;
     taw_free(r->ipacket);
     return FL_OK;
}

int response_zylist(ac_request_t *r, ZYList *list)
{

     int len,dump_size;
     void * dump = zylist_dump_ptr(list, &dump_size);
     len = sizeof(CommBuf) + dump_size + 4;
     CommBuf * cbf_cb = (CommBuf *) taw_malloc("CommBuf", len, 0);
     cbf_cb->data_ptr = &cbf_cb->data[0];


     cbf_cb->len = dump_size+4;
     cbf_cb->data_ptr = &cbf_cb->data[0];
     int num = _ZLLen(list);
     fl_debug_log("response_zylist len=%d dump_size=%d num=%d",len,dump_size,num);

     encode_i32(&cbf_cb->data_ptr, num);
     memcpy(cbf_cb->data_ptr, dump, dump_size);
     //memcpy(r->ipacket, cbf_cb, len);
     cbf_cb->data_ptr = &cbf_cb->data[0];
     r->opacket = (void* )cbf_cb;

     //zylist_free(list);
     taw_free(dump);
     taw_free(r->ipacket);
     return FL_OK;
}

int response_zymap(ac_request_t *r, ZYMap *zymap)
{

     int len,dump_size;

     void * dump = zymap_dump_ptr(zymap, &dump_size);
     len = sizeof(CommBuf) + dump_size;
     CommBuf * cbf_cb = (CommBuf *) taw_malloc("CommBuf", len, 0);
     cbf_cb->data_ptr = &cbf_cb->data[0];

     fl_debug_log("response_zymap len=%d dump_size=%d map=%p dump=%p",len,dump_size,zymap,dump);

     cbf_cb->len = dump_size;
     cbf_cb->data_ptr = &cbf_cb->data[0];
     memcpy(cbf_cb->data_ptr, dump, dump_size);
     //memcpy(r->ipacket, cbf_cb, len);
     r->opacket = (void* )cbf_cb;

    // zymap_free(zymap);
     taw_free(dump);   //�������⡣
     taw_free(r->ipacket);
     return FL_OK;
}

int response_zybuffer(ac_request_t *r, ZYBuffer *buffer)
{

     int len,dump_size;

     void * dump = zybuffer_dump_ptr(buffer, &dump_size);
     len = sizeof(CommBuf) + dump_size;
     CommBuf * cbf_cb = (CommBuf *) taw_malloc("CommBuf", len, 0);
     cbf_cb->data_ptr = &cbf_cb->data[0];

    fl_debug_log("response_zybuffer len=%d dump_size=%d buffer=%p dump=%p",len,dump_size,buffer,dump);

     cbf_cb->len = dump_size;
     cbf_cb->data_ptr = &cbf_cb->data[0];
     memcpy(cbf_cb->data_ptr, dump, dump_size);
     //memcpy(r->ipacket, cbf_cb, len);
     r->opacket = (void* )cbf_cb;

    // zybuffer_free(buffer);
     taw_free(dump);   //�������⡣
     taw_free(r->ipacket);
     return FL_OK;
}


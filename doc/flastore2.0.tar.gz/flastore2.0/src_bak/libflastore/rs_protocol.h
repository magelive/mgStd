#ifndef RS_PROTOCOL_H
#define RS_PROTOCOL_H

#include "comm_buf.h"

#define FL_COMMAND_CREATE                0 //创建文件
#define FL_COMMAND_APPEND                1 //追加文件
#define FL_COMMAND_CLOSE                 2 //关闭文件
#define FL_COMMAND_RENAME                3 //改名文件
#define FL_COMMAND_DELETE                4 //删除文件
#define FL_COMMAND_GET_BLOCK_INFO        5 //获得文件的block信息
#define FL_COMMAND_GET_LISTING           6 //显示文件
#define FL_COMMAND_GET_FILE_INFO         7 //显示文件信息
#define FL_COMMAND_GET_BLOCK_LOCATIONS   8 //获得block位置
#define FL_COMMAND_MAKE_DIR              9 //建立目录
#define FL_COMMAND_SAFE_MODE             10//安全模式
#define FL_COMMAND_ADD_BLOCK             11//增加block
#define FL_COMMAND_WRITE                 12//写文件
#define FL_COMMAND_GET_NS_SERVER_LIST    13//获得所有ns的地址

#define FL_COMMAND_BLOCK_REPORT          14//NS写完数据文件
#define FL_COMMAND_BLOCK_RECEIVE         15//NS收到数据文件
#define FL_COMMAND_NS_REGISTER           16//NS注册到RS

#define FL_COMMAND_CLOSE_RS              17//关闭RS

#define FL_COMMAND_MAX                   26


CommBuf *create_create_file_request(const char* name, const char *client_name, uint64_t block_len, uint32_t protocol_flag);//新建一个文件block，返回NS地址,flag={FL_OVER_WRITE,FL_SINGLE,FL_REPLICATIONS}

CommBuf *create_rename_file_request(const char* old_name, const char* new_name, uint32_t protocol_flag);//文件更名

CommBuf *create_close_file_request(const char* name, uint32_t protocol_flag);//关闭文件，zmq发布消息通知外界文件写完。

CommBuf *create_delete_file_request(const char* name, uint32_t protocol_flag);//删除文件

CommBuf *create_mkdir_request(const char* name, int masked);//建立目录

CommBuf *create_append_file_request(const char* name, uint32_t protocol_flag);//追加文件，返回NS地址

CommBuf *create_write_file_request(const char* name, uint64_t offset, int flag);//写文件，返回NS地址（暂不支持随机写）

CommBuf *create_get_block_locations_request(const char* name, uint64_t offset, uint32_t protocol_flag);//返回指定block的NS地址

CommBuf *create_set_replications_request(const char* name, int replications);//设定副本数

CommBuf *create_add_block_request(const char* name);//给文件增加block，返回NS地址

CommBuf *create_get_listing_request(const char* name);//返回文件或目录的概要信息

CommBuf *create_set_safemode_request(int flag);//设置为安全模式，可读不可写。

CommBuf *create_get_fileinfo_request(const char* name, uint32_t protocol_flag);//返回文件的具体信息

CommBuf *create_block_report_request(const char* name, uint64_t offset, ZYList *block_info, uint32_t protocol_flag);

CommBuf *create_block_received_request(const char* name, uint64_t offset, uint32_t ns_id, uint32_t protocol_flag,void* md5ctx);

CommBuf *create_ns_register_request(const char* location, uint64_t max_size);

CommBuf *create_get_blockinfo_request(const char *name,uint64_t offset, uint32_t protocol_flag);

CommBuf *create_get_ns_server_list_request();

CommBuf *create_close_rs_request(uint32_t flag);//关闭RS

#endif // RS_PROTOCOL_H

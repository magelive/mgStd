#ifndef ROOTSERVER_CLIENT_H
#define ROOTSERVER_CLIENT_H

#include <ac.h>
#include "comm_buf.h"
#include "fl_define.h"


typedef struct _RootServerClient{
    ConnManager           conn_manager;

}RootServerClient;

//如果文件不存在，那么建立文件信息，返回可用NS。如果文件存在，直接返回可用NS。
//返回的list最后一个元素是uint64_t,表示文件大小，文件不存在时，文件大小为0.
//flag={FL_OVER_WRITE,FL_SINGLE,FL_REPLICATIONS}
ZYList* create_file(RootServerClient *rs_client, const char* name, uint64_t block_len, uint32_t protocol_flag);

int rename_file(RootServerClient *rs_client, const char* old_name, const char* new_name, uint32_t protocol_flag);//文件更名

int close_file(RootServerClient *rs_client, const char* name, uint32_t protocol_flag);//关闭文件，zmq发布消息通知外界文件写完。

int delete_file(RootServerClient *rs_client, const char* name, uint32_t protocol_flag);//删除文件

int fl_mkdir(RootServerClient *rs_client, const char* name, int masked);//建立目录

ZYList* append_file(RootServerClient *rs_client, const char* name, uint32_t protocol_flag);//追加文件，返回NS地址

ZYList* write_file(RootServerClient *rs_client, const char* name, uint64_t offset, int flag);//写文件，返回NS地址（暂不支持随机写）

ZYList* get_block_locations(RootServerClient *rs_client, const char* name, uint64_t offset, uint32_t protocol_flag);//返回指定block的NS地址

int set_replications(RootServerClient *rs_client, const char* name, int replications);//设定副本数

ZYList* add_block(RootServerClient *rs_client, const char* name);//给文件增加block，返回NS地址

ZYList* get_listing(RootServerClient *rs_client, const char* name);//返回文件或目录的概要信息

int set_safemode(RootServerClient *rs_client, int flag);//设置为安全模式，可读不可写。

ZYMap* get_fileinfo(RootServerClient *rs_client, const char* name, uint32_t protocol_flag);//返回文件的具体信息,对应所以block信息。

ZYList* get_blockinfo(RootServerClient *rs_client, const char* name,  uint64_t offset, uint32_t protocol_flag);//返回block信息。

ZYList* get_ns_server_list(RootServerClient *rs_client);//返回所有NS地址

int ns_register(RootServerClient *rs_client, const char* location, uint64_t max_size);//NS注册到RS

int block_received(RootServerClient *rs_client, const char* name, uint64_t offset, uint32_t ns_id, uint32_t protocol_flag, void* md5ctx);//NS收到数据，报告RS。

int block_report(RootServerClient *rs_client, const char* name, uint64_t offset, ZYList *block_info, uint32_t protocol_flag);//NS将数据写入磁盘，报告RS。

int block_report_sync(RootServerClient *rs_client, const char* name, uint64_t offset, ZYList *block_info, uint32_t protocol_flag);

int close_rs(RootServerClient *rs_client, uint32_t flag);//关闭rs
#endif // ROOTSERVER_CLIENT_H

#include "rs_protocol.h"
#include "serialization.h"
#include <ngtawutils/md5.h>


//与rs的通信协议
CommBuf *create_create_file_request(const char *name, const char *client_name, uint64_t block_size, uint32_t protocol_flag){

    CommBuf *cbuf = commbuf_new(FL_COMMAND_CREATE, encoded_length_str16(name) +  encoded_length_str16(client_name) + 8 + 4);

    encode_str16(&cbuf->data_ptr, name,strlen(name));
    encode_str16(&cbuf->data_ptr, client_name,strlen(client_name));
	encode_i64(&cbuf->data_ptr, block_size);
    encode_i32(&cbuf->data_ptr, protocol_flag);
    cbuf->data_ptr = &cbuf->data[0];

    return cbuf;
}

CommBuf *create_get_fileinfo_request(const char *name, uint32_t protocol_flag){

    CommBuf *cbuf = commbuf_new(FL_COMMAND_GET_FILE_INFO, encoded_length_str16(name)+4);

    encode_str16(&cbuf->data_ptr, name,strlen(name));
    encode_i32(&cbuf->data_ptr, protocol_flag);
    cbuf->data_ptr = &cbuf->data[0];

    return cbuf;
}

CommBuf *create_append_file_request(const char *name, uint32_t protocol_flag){

    CommBuf *cbuf = commbuf_new(FL_COMMAND_APPEND, encoded_length_str16(name)+4);

    encode_str16(&cbuf->data_ptr, name,strlen(name));
    encode_i32(&cbuf->data_ptr, protocol_flag);
    cbuf->data_ptr = &cbuf->data[0];

    return cbuf;
}

CommBuf *create_close_file_request(const char *name, uint32_t protocol_flag){

    CommBuf *cbuf = commbuf_new(FL_COMMAND_CLOSE, encoded_length_str16(name)+4);

    encode_str16(&cbuf->data_ptr, name,strlen(name));
    encode_i32(&cbuf->data_ptr, protocol_flag);
    cbuf->data_ptr = &cbuf->data[0];

    return cbuf;
}

CommBuf *create_close_rs_request(uint32_t flag){

    CommBuf *cbuf = commbuf_new(FL_COMMAND_CLOSE_RS, 4);
    encode_i32(&cbuf->data_ptr, flag);
    cbuf->data_ptr = &cbuf->data[0];

    return cbuf;
}

CommBuf *create_rename_file_request(const char* old_name, const char* new_name, uint32_t protocol_flag){

    CommBuf *cbuf = commbuf_new(FL_COMMAND_RENAME, encoded_length_str16(old_name)+encoded_length_str16(new_name)+4);
    encode_str16(&cbuf->data_ptr, old_name,strlen(old_name));
    encode_str16(&cbuf->data_ptr, new_name,strlen(new_name));
    encode_i32(&cbuf->data_ptr, protocol_flag);
    cbuf->data_ptr = &cbuf->data[0];

    return cbuf;
}

CommBuf *create_get_block_locations_request(const char *name,uint64_t offset, uint32_t protocol_flag){
    CommBuf *cbuf = commbuf_new(FL_COMMAND_GET_BLOCK_LOCATIONS, encoded_length_str16(name)+8+4);

    encode_str16(&cbuf->data_ptr, name,strlen(name));
    encode_i64(&cbuf->data_ptr, offset);
    encode_i32(&cbuf->data_ptr, protocol_flag);

    cbuf->data_ptr = &cbuf->data[0];

    return cbuf;
}

CommBuf *create_get_blockinfo_request(const char *name,uint64_t offset, uint32_t protocol_flag){
    CommBuf *cbuf = commbuf_new(FL_COMMAND_GET_BLOCK_INFO, encoded_length_str16(name)+8+4);

    encode_str16(&cbuf->data_ptr, name,strlen(name));
    encode_i64(&cbuf->data_ptr, offset);
    encode_i32(&cbuf->data_ptr, protocol_flag);

    cbuf->data_ptr = &cbuf->data[0];

    return cbuf;
}

CommBuf *create_get_ns_server_list_request(){

     CommBuf *cbuf = commbuf_new(FL_COMMAND_GET_NS_SERVER_LIST, 0);
     cbuf->data_ptr = &cbuf->data[0];
     return cbuf;
}

CommBuf *create_block_report_request(const char* name, uint64_t offset, ZYList *block_info, uint32_t protocol_flag){
    int dump_size;
    void* dump = zylist_dump_ptr(block_info, &dump_size);
    CommBuf *cbuf = commbuf_new(FL_COMMAND_BLOCK_REPORT, encoded_length_str16(name) + 8 + 4 + 4 + dump_size);

    encode_str16(&cbuf->data_ptr, name,strlen(name));
    encode_i64(&cbuf->data_ptr, offset);
    encode_i32(&cbuf->data_ptr, dump_size);
    memcpy(cbuf->data_ptr,dump,dump_size);
    cbuf->data_ptr+=dump_size;
    encode_i32(&cbuf->data_ptr, protocol_flag);
    cbuf->data_ptr = &cbuf->data[0];

    taw_free(dump);

    return cbuf;
}


CommBuf *create_block_received_request(const char* name, uint64_t offset, uint32_t ns_id, uint32_t protocol_flag,void* md5ctx){
    CommBuf *cbuf = commbuf_new(FL_COMMAND_BLOCK_RECEIVE, encoded_length_str16(name) + 8 + 4 + 4 + sizeof(md5_t)+16);

    fl_debug_log("create_block_received_request sizeof(md5_t)=%d ",sizeof(md5_t));

    encode_str16(&cbuf->data_ptr, name,strlen(name));
    encode_i64(&cbuf->data_ptr, offset);
    encode_i32(&cbuf->data_ptr, ns_id);
    encode_i32(&cbuf->data_ptr, protocol_flag);
    memcpy(cbuf->data_ptr,md5ctx,sizeof(md5_t)+16);
    cbuf->data_ptr = &cbuf->data[0];

    return cbuf;
}

CommBuf *create_ns_register_request(const char* location, uint64_t max_size){
    CommBuf *cbuf = commbuf_new(FL_COMMAND_NS_REGISTER, encoded_length_str16(location) + 8);

    encode_str16(&cbuf->data_ptr, location,strlen(location));
    encode_i64(&cbuf->data_ptr, max_size);
    cbuf->data_ptr = &cbuf->data[0];

    return cbuf;
}

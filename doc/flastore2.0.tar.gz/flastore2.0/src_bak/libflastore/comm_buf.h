#ifndef FL_COMM_BUF_H
#define FL_COMM_BUF_H

#define FL_COMM_DEFAULT_TIMEOUT 3000

#include <ac.h>

typedef struct _CommBuf{
    uint8_t          *data_ptr;  //数据指针
    int              len;        //数据总长度
    char             data[0];
}CommBuf;

typedef struct _ConnManager{
	//int                   conn_stat; //连接状态
    ac_io_t               *comm; //用于网络通信
    ac_handler_pt         handler; //回调函数，处理发送失败重发等。
    uint64_t              timeout; //超时时间
    int                   io_thread_count;//io线程数
    int                   worker_thread_count;//worker线程数
    char                  *addr;//地址和端口tcp://::1:55555
    ac_thread_pool_t      *threads;//worker线程池
}ConnManager;



CommBuf* commbuf_new(int header, int data_len);

CommBuf* send_message_sync(ConnManager *conn_manager, CommBuf *cbp, ac_io_process_pt *handler, int timeout);

//发送消息，异步
int send_message_async(ConnManager *conn_manager, CommBuf *cbp, ac_io_process_pt *handler, int timeout);

int init_comm(ConnManager *conn_manager);

void disconnect(ConnManager *conn_manager);

void wait_and_destory(ConnManager *conn_manager);

int handler_easy(ac_request_t *r);

int response_ok(ac_request_t *r);

int response_error(ac_request_t *r);

int response_i32(ac_request_t *r, uint32_t num);

int response_zylist(ac_request_t *r, ZYList *list);

int response_zymap(ac_request_t *r, ZYMap *zymap);

int response_zybuffer(ac_request_t *r, ZYBuffer *buffer);


#endif // FL_COMM_BUF_H

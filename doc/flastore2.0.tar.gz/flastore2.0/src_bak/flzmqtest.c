#include <zmq.h>
#include <stdio.h>
#include <string.h>

//测试程序，zmq 订阅 Root Server close file消息。
int main(int argc ,char** argv)
{
    int pid=15; //DEBUG
    void *context = zmq_init(1);
    char addr[100] = "";
    memset(addr, 0, 100);
    snprintf(addr, 100, "ipc:///home/czl/flastore/ipc/root_server%d.ipc", pid, ".ipc");
    printf("zmq connect addr=%s\n",addr);
    void* subscriber = zmq_socket(context,ZMQ_SUB);
    printf("zmq connect subscriber=%p\n",subscriber);
    zmq_setsockopt(subscriber,ZMQ_SUBSCRIBE,"",0);
    printf("zmq connect zmq_setsockopt subscriber ZMQ_SUBSCRIBE\n");
    zmq_connect(subscriber, addr);
    printf("zmq connect addr=%s\n",addr);

    zmq_msg_t msg;
    zmq_msg_init(&msg);
    printf("zmq connect zmq_recvmsg...\n");
	if (zmq_recvmsg(subscriber, &msg, 0) != -1)
	{
	    int data_len = zmq_msg_size(&msg);
	    char* data = (void *)zmq_msg_data(&msg);
	    printf("get DATA from RS:data=%s,data_len=%d\n", data, data_len);

	}
    printf("zmq_close...\n");
	zmq_msg_close(&msg);
	zmq_close(subscriber);
    zmq_term(context);

    return 0;
}

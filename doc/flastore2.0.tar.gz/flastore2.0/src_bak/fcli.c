#include <ngtawstd/zytypes.h>
#include  "libflastore/rs_client.h"
#include  "libflastore/ns_client.h"
#include <libconfig.h>

//开机关机的Client。读取配置文件获得RS地址，建立RS客户端
//先关闭所有在线NS，再关闭RS。

int main()
{
    tawstd_init(0,NULL);
    char *conffile = NULL;
    if (conffile == NULL)
        conffile = FL_DEFAULT_CONF_FILE;
    config_t conf;
    config_init(&conf);

    char addr_rs[128];
    int ns_port=5001;

    RootServerClient rs_client;
    rs_client.conn_manager.addr = "tcp://127.0.0.1:5000";
    if(config_read_file(&conf, conffile) == CONFIG_TRUE)
    {

        const char *addr_ip = "127.0.0.1";
        if(config_lookup_string(&conf, "rs.addr_ip",&addr_ip) != CONFIG_TRUE)
        {
            fl_error_log("read configuration error : rs.addr_ip");
        }
        const char *addr_flag = "tcp";
        if(config_lookup_string(&conf, "rs.addr_flag",&addr_flag) != CONFIG_TRUE)
        {
            fl_error_log("read configuration error : rs.addr_flag");
        }
        int addr_port = 5000;
        if(config_lookup_int(&conf, "rs.addr_port",&addr_port) != CONFIG_TRUE)
        {
            fl_error_log("read configuration error : rs.addr_port");
        }
       /*  int addr_port_ns = 5001;
        if(config_lookup_int(&conf, "ns.addr_port",&addr_port_ns) != CONFIG_TRUE)
        {
            fl_error_log("read configuration error : ns.addr_port");
        }
        ns_port = addr_port_ns;*/

        sprintf(addr_rs,"%s://%s:%d",addr_flag, addr_ip, addr_port);
        rs_client.conn_manager.addr = addr_rs;
    }
     config_destroy(&conf);

    init_comm(&rs_client.conn_manager);

   /* ZYList *ns_list = get_ns_server_list(&rs_client);
    if(ns_list){
        ZYElem *melement = NULL;
        ZYLIST_FOR_EACH(ns_list,melement){
            char addr[128];
            char* ns_addr = zyelem_get_str(melement,NULL);
            sprintf(addr,"tcp://%s:%d", ns_addr, ns_port);

            fl_debug_log("Close ns locations=%s",addr);

            NodeServerClient ns_client;
            ns_client.conn_manager.addr = addr;
            init_comm(&ns_client.conn_manager);
            close_ns(&ns_client,0);
        }
        zylist_free(ns_list);
    }*/


    fl_debug_log("Close rs locations=%s",addr_rs);
    close_rs(&rs_client,0);


}


#include "client.h"
#include <poll.h>
#include <libconfig.h>

//打开flastore，初始化参数和连接
flastore_client* flastore_open(const char* rs_addr){
    //通过RS获得所有NS的位置，全部建立连接，保存在flastore_client中
    fl_debug_log("flastore_open rs_addr=%s",rs_addr);
    tawstd_init(0,NULL);

    flastore_client* fcli = (flastore_client*)taw_malloc("flastore_client",sizeof(flastore_client),0);
    if(!fcli)
        goto ret;

    fcli->rs_client.conn_manager.addr = (char*)rs_addr;
    char *conffile = NULL;
    if (conffile == NULL)
        conffile = FL_DEFAULT_CONF_FILE;
    config_t conf;
    config_init(&conf);

    char addr_rs[128];
    int ns_port=5001;

    if(config_read_file(&conf, conffile) == CONFIG_TRUE)
    {
        if(!rs_addr){
            const char *addr_ip = "127.0.0.1";
            if(config_lookup_string(&conf, "rs.addr_ip",&addr_ip) != CONFIG_TRUE)
            {
                fl_error_log("read configuration error : rs.addr_ip");
            }
            const char *addr_flag = "tcp";
            if(config_lookup_string(&conf, "rs.addr_flag",&addr_flag) != CONFIG_TRUE)
            {
                fl_error_log("read configuration error : rs.addr_flag");
            }
            int addr_port = 5000;
            if(config_lookup_int(&conf, "rs.addr_port",&addr_port) != CONFIG_TRUE)
            {
                fl_error_log("read configuration error : rs.addr_port");
            }

            sprintf(addr_rs,"%s://%s:%d",addr_flag, addr_ip, addr_port);
            fcli->rs_client.conn_manager.addr = addr_rs;
        }

        int ns_addr_port=5001;
        if(config_lookup_int(&conf, "ns.addr_port",&ns_addr_port) != CONFIG_TRUE)
        {
            fl_error_log("read configuration error : ns.addr_port");
        }
        ns_port = ns_addr_port;


        long long int block_size=4096L;
        if(config_lookup_int64(&conf, "rs.block_len",&block_size) != CONFIG_TRUE)
        {
            fl_error_log("read configuration error : rs.block_len");
        }
        fcli->block_size = (uint64_t)block_size;
    }
    config_destroy(&conf);

    init_comm(&fcli->rs_client.conn_manager);

    fcli->ns_client_map = zymap();

    ZYList *ns_list = get_ns_server_list(&fcli->rs_client);
    if(!ns_list)
        goto ret;

    ZYElem *melement = NULL;
    ZYLIST_FOR_EACH(ns_list,melement){
        char *addr = (char*)taw_malloc("char",128,0);
        char* ns_addr = zyelem_get_str(melement,NULL);
        sprintf(addr,"tcp://%s:%d", ns_addr, ns_port);

        fl_debug_log("flastore_open get ns locations=%s",addr);

        NodeServerClient *ns_client = (NodeServerClient*)taw_malloc("NodeServerClient",sizeof(NodeServerClient),0);
        ns_client->conn_manager.addr = addr;
        init_comm(&ns_client->conn_manager);
        zymap_put_ptr(fcli->ns_client_map, _K(ns_addr), ns_client);
    }
    zylist_free(ns_list);

    return fcli;

    ret:
        if(fcli)
            taw_free(fcli);

        fl_error_log("flastore_open error.");
        return NULL;

}

//关闭flastore,析构和断开连接
int flastore_close(flastore_client* fcli)
{
    fl_debug_log("flastore_close fcli =%p",fcli);
    poll(0,0,200);
    disconnect(&fcli->rs_client.conn_manager);
    wait_and_destory(&fcli->rs_client.conn_manager);

    ZYElem* melement = NULL;
    void* key = NULL;
    int key_len = 0;
    if(fcli->ns_client_map){
        ZYMAP_FOR_EACH(fcli->ns_client_map,key,key_len,melement)
        {
            fl_debug_log("flastore_close ns connect ns=%s",(char*)key);
            NodeServerClient *ns_client = (NodeServerClient *)zyelem_get_ptr(melement,NULL);
            disconnect(&ns_client->conn_manager);
            wait_and_destory(&ns_client->conn_manager);
            taw_free(ns_client->conn_manager.addr);
            taw_free(ns_client);
        }
        zymap_free(fcli->ns_client_map);
    }

    taw_free(fcli);
    return FL_OK;
}

//追加数据,返回写入的长度
uint64_t flastore_write(flastore_client* fcli, const char* file_name, uint32_t protocol_flag, void* data, uint64_t data_len)
{
    //根据ns_addr从map中取出ns_client
    int i,ret,cnt;
    uint64_t send_size_tmp,send_size;
    send_size_tmp = data_len;
    cnt = data_len%fcli->block_size==0 ? data_len/fcli->block_size : (data_len/fcli->block_size)+1;
    for(i=0; i<cnt; i++){
        send_size_tmp -= fcli->block_size;
        send_size = send_size_tmp<0 ? send_size_tmp+fcli->block_size : fcli->block_size; //最后一个block可能不足4K

        uint64_t file_offset=0;
        ZYBuffer *file_info_ex=NULL;
        char* ns_addr = NULL;
        ZYList *ns_loctions = create_file(&fcli->rs_client, file_name, 0, protocol_flag);
        if(ns_loctions){
            ZYElem *melement = NULL;
            ZYLIST_FOR_EACH(ns_loctions,melement){
                if(melement->type==ZYT_INT64)
                    file_offset = zyelem_get_int64(melement,NULL);
                else if(!ns_addr)
                    ns_addr = zyelem_get_str(melement,NULL);

            }
            file_info_ex=(ZYBuffer*)zylist_get_zybuffer(ns_loctions,_ZLLen(ns_loctions)-1);
        }
        else{
            fl_error_log("File %s flag %d has been closed or there are no nodeservers.",file_name,protocol_flag);
            return FL_ERROR;
        }
        fl_debug_log("flastore_write ns_addr=%s file_offset=%lld",ns_addr,file_offset);
        NodeServerClient *ns_client = (NodeServerClient *)zymap_get_ptr(fcli->ns_client_map, _K(ns_addr));
        if(ns_client){

             ret = write_ns_file(ns_client, file_name, file_offset, send_size, protocol_flag, data+i*fcli->block_size,file_info_ex);
             zylist_free(ns_loctions);
        }
        else{
           zylist_free(ns_loctions);
           fl_error_log("flastore_write error,fail to get ns client.");
           return FL_ERROR;
        }


    }

}

//读取数据，返回数据data
ZYBuffer * flastore_read(flastore_client* fcli, const char* file_name, uint64_t offset, uint32_t protocol_flag)
{
    ZYBuffer *buffer = NULL;
    int retry = 0;
    while(!buffer && ++retry <= FL_READ_RETRY_TIMES){
        ZYList* block_info = get_blockinfo(&fcli->rs_client, file_name, offset,protocol_flag);//查询某block元信息，然后向该节点发起读请求。
        char* ns_addr=NULL;
        char* file_path=NULL;
        uint64_t file_offset;
        uint64_t length;
        if(block_info){
            ns_addr = (char*)zylist_get_str(block_info,0);
            file_path = (char*)zylist_get_str(block_info,1);
            file_offset = zylist_get_int64(block_info,2);
            length = zylist_get_int64(block_info,3);

            fl_debug_log("flastore_read get block info ns_addr=%s,file_path=%s,file_offset=%lld,length=%lld",
                     ns_addr,file_path,file_offset,length);
        }

        NodeServerClient *ns_client = (NodeServerClient *)zymap_get_ptr(fcli->ns_client_map, _K(ns_addr));


        if(!block_info || !ns_addr || !ns_client)
        {
            fl_error_log("flastore_read error,fail to get block info.");
            return NULL;
        }
        /**file_path为空仍然可以查询，表示数据在NS内存中，还未写入磁盘，并报告给RS。
           如果正好在收到空file_path后，NS写入磁盘并清除内存，那么会读失败。需要重新
           从RS获得包含NS文件路径和偏移位置的元数据*/

        buffer = read_ns_file(ns_client,file_name, offset,protocol_flag,(char*)file_path, file_offset, length);
        zylist_free(block_info);
    }

    return buffer;
}

//关闭文件，发布消息，关闭之后可读不可写
int flastore_close_file(flastore_client* fcli, const char* file_name, uint32_t protocol_flag)
{
    return close_file(&fcli->rs_client,file_name,protocol_flag);
}

//创建文件
int flastore_create_file(flastore_client* fcli, const char* file_name, uint32_t protocol_flag, ZYMap *file_info_map)
{
    //return close_file(&fcli->rs_client,file_name,protocol_flag);
    return FL_OK;
}

//获得文件元数据
ZYMap *flastore_get_fileinfo(flastore_client* fcli, const char* file_name, uint32_t protocol_flag)
{
    //return close_file(&fcli->rs_client,file_name,protocol_flag);
    return NULL;
}

//更名文件，发布消息
int flastore_rename_file(flastore_client* fcli, const char* old_name, const char* new_name, uint32_t protocol_flag)
{
    return rename_file(&fcli->rs_client,old_name,new_name, protocol_flag);
}

#ifndef _FLASTORE_CLIENT_H
#define _FLASTORE_CLIENT_H

#include "../libflastore/rs_client.h"
#include "../libflastore/ns_client.h"
#include "../libflastore/fl_define.h"
#include <ngtawstd/zytypes.h>

typedef struct _flastore_client{
    RootServerClient rs_client;
    uint64_t         block_size;
    ZYMap            *ns_client_map;

}flastore_client;

/**
 * 打开flastore，初始化参数和连接
 *
 * @param rs_addr
 *   需要连接的Root Server地址。如果设置为NULL，将读取默认配置文件的Root Server地址。
 * @return
 *   如果成功，返回flastore_client的指针，失败返回NULL
 */
flastore_client* flastore_open(const char* rs_addr);

/**
 * 关闭flastore,析构和断开连接
 *
 * @param fcli
 *   flastore_client的指针
 * @return
 *   如果成功，返回FL_OK，失败返回FL_ERROR
 */
int flastore_close(flastore_client* fcli);

/**
 * 创建一个文件
 *
 * @param fcli
 *   flastore_client的指针
 * @param file_name
 *   文件的名字
  * @param protocol_flag
 *   定义的协议类型，可供选择的类型有：
 *    -FL_HTTP_GET    : HTTP下载
 *    -FL_HTTP_POST   : HTTP上传
 *    -FL_SMTP        : 发送邮件
 *    -FL_POP3        : 接收邮件
 *    -FL_FTP         : ftp下载、上传
 *    -FL_PCAP        : 数据采集
 * @param file_info_map
 *    需要存入文件元数据表的文件信息
 * @return
 *   如果成功，返回FL_OK，失败返回FL_ERROR
 */
int flastore_create_file(flastore_client* fcli, const char* file_name, uint32_t protocol_flag, ZYMap *file_info_map);

/**
 * 获取文件元数据信息
 *
 * @param fcli
 *   flastore_client的指针
 * @param file_name
 *   文件的名字
  * @param protocol_flag
 *   定义的协议类型，可供选择的类型有：
 *    -FL_HTTP_GET    : HTTP下载
 *    -FL_HTTP_POST   : HTTP上传
 *    -FL_SMTP        : 发送邮件
 *    -FL_POP3        : 接收邮件
 *    -FL_FTP         : ftp下载、上传
 *    -FL_PCAP        : 数据采集
 * @return
 *    文件元数据信息
 */
ZYMap *flastore_get_fileinfo(flastore_client* fcli, const char* file_name, uint32_t protocol_flag);

/**
 * 写入数据（追加方式）
 *
 * @param fcli
 *   flastore_client的指针
 * @param file_name
 *   写入文件的名字,文件名字需要携带创建时间信息。如201411071619-A3Z5
 * @param protocol_flag
 *   定义的协议类型，可供选择的类型有：
 *    -FL_HTTP_GET    : HTTP下载
 *    -FL_HTTP_POST   : HTTP上传
 *    -FL_SMTP        : 发送邮件
 *    -FL_POP3        : 接收邮件
 *    -FL_FTP         : ftp下载、上传
 *    -FL_PCAP        : 数据采集
 * @param data
 *   需要发送的数据
  * @param data_len
 *   需要发送的数据的长度
 * @return
 *   如果成功，返回写入的长度，失败返回0
 */
uint64_t flastore_write(flastore_client* fcli, const char* file_name, uint32_t protocol_flag, void* data, uint64_t data_len);

/**
 * 读取数据
 *
 * @param fcli
 *   flastore_client的指针
 * @param file_name
 *   读取文件的名字
 * @param offset
 *   数据相对于文件头的偏移位置
 * @param protocol_flag
 *   定义的协议类型，可供选择的类型有：
 *    -FL_HTTP_GET    : HTTP下载
 *    -FL_HTTP_POST   : HTTP上传
 *    -FL_SMTP        : 发送邮件
 *    -FL_POP3        : 接收邮件
 *    -FL_FTP         : ftp下载、上传
 *    -FL_PCAP        : 数据采集
 * @return
 *   如果成功，返回数据的ZYBuffer指针，失败返回NULL
 */
ZYBuffer* flastore_read(flastore_client* fcli, const char* file_name, uint64_t offset, uint32_t protocol_flag);

/**
 * 关闭文件，发布消息
 *
 * @param fcli
 *   flastore_client的指针
 * @param file_name
 *   关闭文件的名字
  * @param protocol_flag
 *   定义的协议类型，可供选择的类型有：
 *    -FL_HTTP_GET    : HTTP下载
 *    -FL_HTTP_POST   : HTTP上传
 *    -FL_SMTP        : 发送邮件
 *    -FL_POP3        : 接收邮件
 *    -FL_FTP         : ftp下载、上传
 *    -FL_PCAP        : 数据采集
 * @return
 *   如果成功，返回FL_OK，失败返回FL_ERROR
 */
int flastore_close_file(flastore_client* fcli, const char* file_name, uint32_t protocol_flag);

/**
 * 更名文件
 *
 * @param fcli
 *   flastore_client的指针
 * @param old_name
 *   旧的文件的名字
 * @param new_name
 *   新的文件的名字
 * @param protocol_flag
 *   定义的协议类型，可供选择的类型有：
 *    -FL_HTTP_GET    : HTTP下载
 *    -FL_HTTP_POST   : HTTP上传
 *    -FL_SMTP        : 发送邮件
 *    -FL_POP3        : 接收邮件
 *    -FL_FTP         : ftp下载、上传
 *    -FL_PCAP        : 数据采集
 * @return
 *   如果成功，返回FL_OK，失败返回FL_ERROR
 */
int flastore_rename_file(flastore_client* fcli, const char* old_name, const char* new_name, uint32_t protocol_flag);

#endif // _FLASTORE_CLIENT_H



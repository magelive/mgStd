//ns的主要操作函数。通过aio读写文件，向其他ns同步数据，向rs汇报block信息。
#include "ns.h"
#include "../libflastore/comm_packet.h"
#include "ns_request.h"
#include "ns_request.c"
#include "../libflastore/flastore.h"

#include <libconfig.h>
#include <ngtawutils/md5.h>
#include <poll.h>

#include <openssl/md5.h>

extern void *comm_decode(ac_message_t *m);
extern  int comm_encode(ac_request_t *r, void *data);

NodeServer* ns_init(char* conffile){
    NodeServer *ns = taw_malloc("NodeServer",sizeof(NodeServer),0);
    ns->rs_client = taw_malloc("RootServerClient",sizeof(RootServerClient),0);

    if (conffile == NULL)
    {
        //using default configure file
        conffile = FL_DEFAULT_CONF_FILE;
    }
    config_t conf;
    config_init(&conf);
    if(config_read_file(&conf, conffile) == CONFIG_FALSE)
    {
        ns->data_top_dir = strdup("/home/czl/flastore/data");
        ns->rs_client->conn_manager.addr = strdup("tcp://127.0.0.1:5000");
        ns->conn_manager.worker_thread_count = 5;
        ns->conn_manager.io_thread_count = 5;
        ns->conn_manager.addr = strdup("tcp://127.0.0.1:5001");
        ns->cache_size=41943040L; //DEBUG 40M

    }
    else{
        const char *addr_ip = "127.0.0.1";
        if(config_lookup_string(&conf, "ns.addr_ip",&addr_ip) != CONFIG_TRUE)
        {
            fl_error_log("read configuration error : ns.addr_ip");
        }
        const char *addr_flag = "tcp";
        if(config_lookup_string(&conf, "ns.addr_flag",&addr_flag) != CONFIG_TRUE)
        {
            fl_error_log("read configuration error : ns.addr_flag");
        }
        int addr_port = 5001;
        if(config_lookup_int(&conf, "ns.addr_port",&addr_port) != CONFIG_TRUE)
        {
            fl_error_log("read configuration error : ns.addr_port");
        }
        char* addr= (char*)malloc(100);
        sprintf(addr,"%s://%s:%d",addr_flag, addr_ip, addr_port);
        ns->conn_manager.addr = addr;

        const char *rs_addr_ip = "127.0.0.1";
        if(config_lookup_string(&conf, "rs.addr_ip",&rs_addr_ip) != CONFIG_TRUE)
        {
            fl_error_log("read configuration error : rs.addr_ip");
        }
        const char *rs_addr_flag = "tcp";
        if(config_lookup_string(&conf, "rs.addr_flag",&rs_addr_flag) != CONFIG_TRUE)
        {
            fl_error_log("read configuration error : rs.addr_flag");
        }
        int rs_addr_port = 5000;
        if(config_lookup_int(&conf, "rs.addr_port",&rs_addr_port) != CONFIG_TRUE)
        {
            fl_error_log("read configuration error : rs.addr_port");
        }
        char* rsaddr= (char*)malloc(100);
        sprintf(rsaddr,"%s://%s:%d",rs_addr_flag, rs_addr_ip, rs_addr_port);
        ns->rs_client->conn_manager.addr = rsaddr;

        const char *data_top_dir = "/home/czl/flastore/data";
        if(config_lookup_string(&conf, "ns.data_top_dir",&data_top_dir) != CONFIG_TRUE)
        {
            fl_error_log("read configuration error : ns.data_top_dir");
        }
        ns->data_top_dir = strdup(data_top_dir);

        int worker_thread_count = 5;
        if(config_lookup_int(&conf, "ns.worker_thread_count",&worker_thread_count) != CONFIG_TRUE)
        {
            fl_error_log("read configuration error : ns.worker_thread_count");
        }
        ns->conn_manager.worker_thread_count = worker_thread_count;

        int io_thread_count = 5;
        if(config_lookup_int(&conf, "ns.io_thread_count",&io_thread_count) != CONFIG_TRUE)
        {
            fl_error_log("read configuration error : ns.io_thread_count");
        }
        ns->conn_manager.io_thread_count = io_thread_count;

        long long int cache_size = 41943040L;
        if(config_lookup_int64(&conf, "ns.cache_size",&cache_size) != CONFIG_TRUE)
        {
            fl_error_log("read configuration error : ns.cache_size");
        }
        ns->cache_size = (uint64_t)cache_size;

    }
    config_destroy(&conf);


    ns->block_map = zymap();

    ns->conn_manager.comm = NULL;
    init_comm(&ns->rs_client->conn_manager);
    ns->max_size = get_maxsize("/");//DEBUG 主目录不一定是根目录

    ns->ns_id = ns_register(ns->rs_client, "127.0.0.1",ns->max_size);//重启时需要向RS报告自己的block信息。

    fl_debug_log("ns_register get ns_id=%d maxsize=%lld",ns->ns_id, ns->max_size);
    pthread_mutex_init(&ns->mutex_x,NULL);
    pthread_mutex_init(&ns->write_lock,NULL);

    ns->writer = ns_writer_init();
    ns->writer->data_path = ns->data_top_dir;
    ns->cache_ok = 1;
    ns->flushing = 0;
    ns->safe_mode = 0;
    ns->started = 1;

    return ns;
}

int ns_close(NodeServer* ns){

    fl_debug_log("ns_close...");

    zymap_free(ns->block_map);
    //写log文件，如果需要重启报告RS自己的block信息，那么需要在log中保存维护的block的元数据信息。
    ns_writer_close(ns->writer);

    free(ns->data_top_dir);
    free(ns->rs_client->conn_manager.addr);
    free(ns->conn_manager.addr);

    taw_free(ns->rs_client);
    taw_free(ns);
}

//listen accept等待client发起读写请求。 读写中报告RS。每个Client连接开一个线程，读一个协议，判断读还是写。
// 如果是写。那么先写入Cache，并返回Client。定时根据协议中的put get ftp和时间等，建立目录，写入对应的文件中。报告给rs。
//如果是读，解析出参数，优先读取Cache，Cache没有则读对应目录文件。

int ns_run(NodeServer* ns){

    if ((ns->conn_manager.comm = ac_acio_create(ns->conn_manager.comm, ns->conn_manager.io_thread_count))==NULL) {
        fl_error_log("ac_io_init error.\n");
        return FL_ERROR;
    }

    memset(&ns->conn_manager.handler, 0, sizeof(ns->conn_manager.handler));
    ns->conn_manager.handler.decode = comm_decode;
    ns->conn_manager.handler.encode = comm_encode;
    ns->conn_manager.handler.user_data = (void *)ns;

    //io_handler.on_connect = comm_connect;

    ns->conn_manager.handler.process = ns_handle;//主要数据处理函数
    if(ns->conn_manager.worker_thread_count)

        ns->conn_manager.threads = ac_work_thread_pool_create(ns->conn_manager.comm,
                                            ns->conn_manager.worker_thread_count,
                                            ns_worker_handle, NULL);


    if ((ac_listen(ns->conn_manager.comm, ns->conn_manager.addr, &ns->conn_manager.handler)) == NULL) {
        fl_error_log("ac_io_add_listen error, addr: %s, %s\n",
                       ns->conn_manager.addr, strerror(errno));
        return FL_ERROR;
    } else {
        fl_error_log("listen start, addr = %s\n", ns->conn_manager.addr);
    }

    // 起线程并开始
    if (ac_acio_start(ns->conn_manager.comm)) {
        fl_error_log("ac_io_start error.\n");
        return FL_ERROR;
    }

    uv_loop_t *loop=uv_loop_new();
    ns->timer_req.data = ns;
    uv_timer_init(loop, &ns->timer_req);
    uv_timer_start(&ns->timer_req,ns_time_handler,1000,NS_TIMER_INTERVEL);
    uv_run(loop, UV_RUN_DEFAULT);

    fl_debug_log("wait_and_destory rs_client acio=%p",ns->conn_manager.comm);
    // 等待线程退出
    ac_acio_wait(ns->conn_manager.comm);
    ac_acio_destroy(ns->conn_manager.comm);
    return FL_OK;
}

unsigned char* ns_cache_key(unsigned char* md,const char* name, uint64_t offset, uint32_t protocol_flag)
{
    memset(md,0,100);

    //char key[100];
    sprintf(md,"%s%lld%d",name,offset,protocol_flag);

   // md5_t ctx;
    //md5_init(&ctx);
   // md5_update(&ctx,key,strlen(key));
   // md5_final(md,&ctx);

    return md;
}
int locale_write_ns(NodeServer *ns, const char* name, uint64_t offset, uint64_t length, uint32_t protocol_flag, void* data, void *context)
{

    fl_debug_log("locale_write_ns name=%s,offset=%lld,length=%lld,flag=%d,data=%s",
                 name, offset, length, protocol_flag, (char*)data);

    md5_t *md5ctx = (md5_t *)context;

    uint64_t write_align_length = ns_align(length);

    if(ns->max_size - ns->used_size < write_align_length)
    {
         fl_error_log("locale_write_ns ERROR. data max=%lld, used_size=%lld",ns->max_size,ns->used_size);
         ns->max_size = get_maxsize("/");//重新获得大小
         if(ns->max_size - ns->used_size < write_align_length)
             return ns->max_size - ns->used_size;
    }

    void *buffer = NULL;

    offset = ns_align(offset);

    posix_memalign(&buffer, NS_ALIGN_SIZE, write_align_length);
    fl_debug_log("locale_write_ns write_align_length=%lld",write_align_length);
    if(!buffer){
        fl_debug_log("locale_write_ns error");
        return 0;
    }
    memcpy(buffer,data,length);
    DataInfo *data_info = (DataInfo *)taw_malloc("DataInfo",sizeof(DataInfo),0);
    if(!data_info)
    {
        free(buffer);
        fl_debug_log("locale_write_ns error");
        return 0;
    }
    data_info->name = strdup(name);
    data_info->offset = offset;
    data_info->length = length;
    data_info->protocol_flag = protocol_flag;
    data_info->data = buffer;


    while(ns->started){
        if(ns->cache_ok==0){
            fl_info_log("wait cache for ok...");
            poll(0,0,100);
            continue;
        }
        else{
             unsigned char cache_key[100];
             ns_cache_key(cache_key,name,offset,protocol_flag);
             //pthread_mutex_lock(&ns->write_lock);

            //DEBUG:测试数据是否正确
           // char data_tmp[4096];
           // memset(data_tmp,97,4096);
           // if(memcmp(data_info->data,data_tmp,2048)){
           //      fl_error_log("data error2: data_info=%s",(char*)data_info->data);
           // }


             zymap_put_ptr(ns->block_map,_K(cache_key),data_info);
             //pthread_mutex_unlock(&ns->write_lock);
             break;
        }

    }

    ns->used_size += write_align_length;
    ns->cache_used_size += write_align_length;


    md5_update(md5ctx,buffer,length);

    void *buf = taw_malloc("void",sizeof(md5_t)+16,0);
    memcpy(buf,md5ctx,sizeof(md5_t));
    unsigned char md[16];
    md5_final(md,md5ctx);
    memcpy(buf+sizeof(md5_t),md,16);

   // fl_debug_log("md5=%0X%0X%0X%0X%0X%0X%0X%0X%0X%0X%0X%0X%0X%0X%0X%0X",md[0],md[1],md[2],md[3],md[4],md[5],md[6],md[7],md[8],md[9],md[10],md[11],md[12],md[13],md[14],md[15]);

    block_received(ns->rs_client, name, offset, ns->ns_id, protocol_flag, (void*)buf);//向RS报告收到数据。

    taw_free(buf);

    return write_align_length;
}

//file_name是NS本地文件的路径，Client查询RS获得的。
ZYBuffer* locale_read_ns(NodeServer *ns, const char* name, uint64_t offset, uint32_t protocol_flag, const char* file_name, uint64_t file_offset, uint64_t length)
{

    fl_debug_log("locale_read_ns name=%s offset=%lld flag=%d file_name=%s,file_offset=%lld,length=%lld",
                 name, offset, protocol_flag, file_name, file_offset, length);
    void *buffer = NULL;
    uint64_t ret = 0;

   // pthread_mutex_lock(&ns->mutex_x);
    unsigned char cache_key[100];
    ns_cache_key(cache_key,name,offset,protocol_flag);
    DataInfo *data_info = (DataInfo *)zymap_get_ptr(ns->block_map,_K(cache_key));
   // pthread_mutex_unlock(&ns->mutex_x);

    if(data_info)
        length = data_info->length;

    uint64_t read_align_length = ns_align(length);


    posix_memalign(&buffer, NS_ALIGN_SIZE, read_align_length);

    fl_debug_log("locale_read_ns read_align_length=%lld",read_align_length);
    if(!buffer)
    {
        fl_debug_log("locale_read_ns error");
        return NULL;
    }
    memset(buffer,0,read_align_length);

   // ns_writer_open_read(ns->writer,file_name);
    if(!data_info)
        ret = ns_read(ns->writer,ns,file_name,buffer,file_offset,read_align_length);
    else
        memcpy(buffer,data_info->data,read_align_length);

    fl_debug_log("locale_read_ns length=%lld read=%s",read_align_length, (char*)buffer);

    /*char buftmp[read_align_length];
    memset(buftmp,0,read_align_length);
    if(memcmp(buffer,buftmp,read_align_length)==0)
    {
        fl_debug_log("locale_read_ns read NULL.");
        return NULL;
    }*/

    ZYBuffer* zybuf = zybuffer_new( buffer,read_align_length,0,ZYBUFFER_DEFAULT_FLAG);

    free(buffer);//不能在这里释放

    return zybuf;
}

int freeze_cache(NodeServer* ns)
{
    pthread_mutex_lock(&ns->write_lock);
    ns->cache_ok=0;
    ns->block_map_tmp = ns->block_map;
    ns->block_map = zymap();
    ns->cache_ok=1;
    pthread_mutex_unlock(&ns->write_lock);
}

//sync非0则同步写，写完一条，RS返回才能写下一条。关闭NS需要同步写。
//sync为0则异步写，提交给AIO，则返回。缓存满写入磁盘，用异步写。

//错误处理，写失败了，重写，保证内存释放

//上次还没写完，下次不能再刷
int ns_write_and_free_cache(NodeServer* ns,int sync)
{
    if(ns->flushing)
    {
        fl_error_log("ns->block_map_tmp is flushing wait for next one.");
        return FL_ERROR;
    }
    ns->flushing=1;
    freeze_cache(ns);
    ZYElem* melement = NULL;
    void* key = NULL;
    int key_len = 0;

    ZYMAP_FOR_EACH(ns->block_map_tmp,key,key_len,melement)
    {
        fl_debug_log("ns_write_and_free_cache map len=%d block_map=%p map_tmp=%p",_ZMLen(ns->block_map_tmp),ns->block_map,ns->block_map_tmp);
        DataInfo *data_info = (DataInfo *)zyelem_get_ptr(melement,NULL);
        if(!data_info){
            fl_debug_log("data_info==NULL");
            continue;
        }

        const char* protocol_str = protocol_flag_to_str(data_info->protocol_flag);


        BlockReportInfo *report_info = (BlockReportInfo *)taw_malloc("BlockReportInfo",sizeof(BlockReportInfo),0);
        if(!report_info){
             fl_error_log("taw_malloc error.");
             ns->flushing=0;
             return 0;
        }
        memset(report_info,0,sizeof(BlockReportInfo));

        report_info->rs_client = ns->rs_client;
        report_info->name = data_info->name;
        report_info->offset = data_info->offset;
        report_info->nsid = ns->ns_id;
        report_info->filename = ns_writer_open_recent(ns->writer,data_info->name,protocol_str);
        report_info->length = data_info->length;
        report_info->protocol_flag = data_info->protocol_flag;

        fl_debug_log("ns_write_and_free_cache report_info->rs_client=%p,name=%s,offset=%lld,nsid=%d,filename=%s,len=%lld,flag=%d",
                     report_info->rs_client,report_info->name,report_info->offset,report_info->nsid,report_info->filename,
                     report_info->length,report_info->protocol_flag);

        //DEBUG:测试数据是否正确
        //char data_tmp[4096];
        //memset(data_tmp,97,4096);
       // if(memcmp(data_info->data,data_tmp,2048)){
       //      fl_error_log("data error: data_info=%s",(char*)data_info->data);
       // }

        uint64_t ret=0;
        int retry=0;
        while(ret==0 && retry++<2){
            if(sync)
                ret = ns_write_sync(ns->writer,report_info,protocol_str,data_info->data,ns_align(data_info->length));
            else
                ret = ns_write(ns->writer,report_info,protocol_str,data_info->data,ns_align(data_info->length));

        }

        if(ret==0){
            free(report_info->name);
            free(report_info->filename);
            taw_free(report_info);
            free(data_info->data);
        }

        taw_free(data_info);

    }

    zymap_free(ns->block_map_tmp);
    ns->block_map_tmp=NULL;
    ns->cache_used_size = 0;
    ns->flushing=0;
    return FL_OK;

}

//关闭NS的请求处理
int locale_close_ns(NodeServer *ns, uint32_t flag)
{

    fl_debug_log("locale_close_ns  flag=%d",flag);

    ns->started = 0;

    //由于libuv的缺陷，需要等到下次timer唤醒时才能结束loop
    uv_timer_stop(&ns->timer_req);
    uv_stop(ns->timer_req.loop);

    ns_write_and_free_cache(ns,1);//把cache中的数据写入磁盘，并报告RS

    ac_connection_disconnect(ns->rs_client->conn_manager.comm,ns->rs_client->conn_manager.addr);

    ac_acio_stop(ns->rs_client->conn_manager.comm);

    fl_debug_log("wait_and_destory rs_client acio=%p",ns->rs_client->conn_manager.comm);

    wait_and_destory(&ns->rs_client->conn_manager);

    ac_acio_stop(ns->conn_manager.comm);

    return FL_OK;
}

//删除数据请求处理
int locale_delete_ns_file(NodeServer *ns, uint32_t flag, uint64_t time)
{
    char command[100];
    char datastr[9];
    get_date_dir_by_time(datastr,time);
    sprintf(command, "rm -rf %s/%s/%s", ns->data_top_dir,protocol_flag_to_str(flag),datastr);
    fl_debug_log("delete_file command=%s",command);
    system(command);
    return FL_OK;
}


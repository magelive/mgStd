//收到请求后，根据协议头调用不同request函数，解析出参数，分别调用rs.c的函数

#include "ns.h"
#include "ns_request.h"
#include "../libflastore/ns_protocol.h"
#include "../libflastore/fl_define.h"
#include "../libflastore/serialization.h"


int ns_handle(ac_request_t *r)
{
    CommBuf           *cbf;
    CommBuf           *cbf_cb;
    int               cb_size;

    cbf = (CommBuf *) r->ipacket;
    if (!cbf)
        return 1;
    ac_message_t *m = (ac_message_t *)r->ms;
    ac_handler_pt *achandler = m->c->handler;
    NodeServer *ns = (NodeServer*)((achandler->user_data));

    const uint8_t *decode_ptr = cbf->data_ptr;
    size_t decode_remain = cbf->len;

    int header;
    header = decode_i32(&decode_ptr,&decode_remain);

    switch(header){
    //长任务push到线程中ac_thread_pool_push  ac_thread_pool_push(cp.threads, r, ac_hash_key((uint64_t)(long)r));
        case FL_REQUEST_WRITE: {
             fl_debug_log("Receive Request------------>FL_REQUEST_WRITE decode_ptr=%p",decode_ptr);
             ac_thread_pool_push(ns->conn_manager.threads, r, ac_hash_key((uint64_t)(long)r));
             r->opacket = NULL;
             return AC_AGAIN;

        }
        case FL_REQUEST_READ: {
             fl_debug_log("Receive Request------------>FL_REQUEST_READ decode_ptr=%p",decode_ptr);
             ac_thread_pool_push(ns->conn_manager.threads, r, ac_hash_key((uint64_t)(long)r));
             r->opacket = NULL;
             return AC_AGAIN;
        }
        case FL_COMMAND_CLOSE_NS: {
              fl_debug_log("Receive Request------------> FL_COMMAND_CLOSE_NS");
              uint32_t flag = decode_i32(&decode_ptr,&decode_remain);
              int ret = locale_close_ns(ns, flag);
              response_i32(r, ret);
              break;
        }
        case FL_COMMAND_DELETE_NS_FILE: {
              fl_debug_log("Receive Request------------> FL_COMMAND_DELETE_NS_FILE");
              uint32_t flag = decode_i32(&decode_ptr,&decode_remain);
              uint64_t time = decode_i64(&decode_ptr,&decode_remain);
              int ret = locale_delete_ns_file(ns, flag, time);
              response_i32(r, ret);
              break;
        }
        case FL_COMMAND_FLUSH_NS_CACHE: {
              fl_debug_log("Receive Request------------> FL_COMMAND_FLUSH_NS_CACHE");
              uint32_t flag = decode_i32(&decode_ptr,&decode_remain);
              int ret = ns_write_and_free_cache(ns, flag);
              response_i32(r, ret);
              break;
        }

        default:{
            fl_error_log("unknown header.");
            r->opacket=NULL;
        }

    }
    return AC_OK;
}

int ns_worker_handle(ac_request_t *r, void *args)
{

    CommBuf           *cbf;
    CommBuf           *cbf_cb;
    int               cb_size;

    cbf = (CommBuf *) r->ipacket;
    if (!cbf)
        return 1;
    ac_message_t *m = (ac_message_t *)r->ms;
    ac_handler_pt *achandler = m->c->handler;
    NodeServer *ns = (NodeServer*)((achandler->user_data));


    const uint8_t *decode_ptr = cbf->data_ptr;
    size_t decode_remain = cbf->len;

    int header;
    header = decode_i32(&decode_ptr,&decode_remain);

    switch(header){
        case FL_REQUEST_WRITE: {
             fl_debug_log("ns_worker_handle FL_REQUEST_WRITE decode_ptr=%p",decode_ptr);
             const char* name = decode_str16(&decode_ptr,&decode_remain);
             uint64_t offset = decode_i64(&decode_ptr,&decode_remain);
             uint64_t length = decode_i64(&decode_ptr,&decode_remain);
             int protocol_flag = decode_i32(&decode_ptr,&decode_remain);
             int ret = locale_write_ns(ns, name, offset, length, protocol_flag, (void*)decode_ptr,(void*)decode_ptr+length);
             response_i32(r, ret);
             break;
        }
        case FL_REQUEST_READ: {
             fl_debug_log("ns_worker_handle FL_REQUEST_READ decode_ptr=%p",decode_ptr);
             const char* name = decode_str16(&decode_ptr,&decode_remain);
             uint64_t offset = decode_i64(&decode_ptr,&decode_remain);
             int protocol_flag = decode_i32(&decode_ptr,&decode_remain);
             const char* file_name = decode_str16(&decode_ptr,&decode_remain);
             uint64_t file_offset = decode_i64(&decode_ptr,&decode_remain);
             uint64_t length = decode_i64(&decode_ptr,&decode_remain);
             ZYBuffer *buffer = locale_read_ns(ns, name, offset, protocol_flag, file_name, file_offset, length);
             response_zybuffer(r, buffer);
             break;
        }
        default:{
             fl_error_log("unknown header.");
             r->opacket=NULL;
        }

    }
    return AC_OK;
}

void ns_time_handler(uv_timer_t* handle){

    NodeServer *ns = (NodeServer*)((handle->data));

    fl_debug_log("ns_time_handler ns=%p nsid=%d cache_used_size=%lld",ns,ns->ns_id,ns->cache_used_size );

    if(!ns->started || ns->conn_manager.comm->stoped)
    {
       uv_timer_stop(handle);
       //ns_close(ns);
    }

    if(ns->cache_used_size >= ns->cache_size){
        fl_debug_log("NS Cache max,execute write.len=%lld",ns->cache_used_size );
        ns_write_and_free_cache(ns,0);
    }

}

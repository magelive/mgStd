//ns 读写本地文件，aio epoll
#ifndef FL_NS_WRITER_H
#define FL_NS_WRITER_H

#include <sys/eventfd.h>
#include <sys/epoll.h>
#include <libaio.h>


#define NS_MAX_WRITE_IO_OPTS 8192
#define NS_FILE_MAX_SIZE (2*1024*1024*1024LL)


typedef struct NodeServerWriter{
    int32_t is_running:8;
    int32_t is_align:8;
    io_context_t ctx;
    int epoll_fd;
    int event_fd;
    uint64_t file_size_now;

    char* data_path;
    char  now_file[100];
    char  file_name[50];
    char  protocol_str[12];
    int data_fd;
    uint32_t max_fileid;

    pthread_mutex_t write_mutex;
    pthread_t event_thread;
}NodeServerWriter;

typedef struct AioData{//扩展aio event.data，携带用户数据。
    void*   callback;
    void*   user_data;
    int     sync;
}AioData;

typedef struct AioReadCond{
    pthread_mutex_t   mutex;
    pthread_cond_t    cond;
    int               waiting;
}AioReadCond;

typedef struct AioWriteData{
    AioReadCond*   aio_cond;
    void*         user_data;
}AioWriteData;


NodeServerWriter * ns_writer_init();

void* ns_event_hander(void* arg);//epoll处理结果的线程

void ns_aio_callback(io_context_t ctx, struct iocb *iocb, long res, long res2);//aio回调函数

char* ns_writer_open_recent(NodeServerWriter *writer, const char* name, const char* protocol_str);//打开需要写的文件和目录

char* ns_writer_open_new(NodeServerWriter *writer, const char* name, const char* protocol_str);//打开新目录和新文件

uint64_t ns_write(NodeServerWriter *writer,  void* block_info, const char* protocol_str, void* buffer, uint64_t buffer_len);//追加方式写入数据，超过2G开启新文件.长度必须为512倍数

uint64_t ns_read(NodeServerWriter *writer,  void* ns,const char* file_path,void* buffer,uint64_t offset, uint64_t buffer_len);//随机读取数据，长度必须为512倍数

int ns_writer_open_read(NodeServerWriter *writer,const char* file_path);//打开指定文件

void ns_writer_close(NodeServerWriter *writer);


#endif //FL_NS_WRITER_H

//收到请求后，根据协议头调用不同request函数，解析出参数，分别调用rs.c的函数
#ifndef RS_REQUEST_H
#define RS_REQUEST_H

#include <ac.h>

int ns_handle(ac_request_t *r);

int ns_worker_handle(ac_request_t *r, void *args);

void ns_time_handler(uv_timer_t* handle);
#endif //RS_REQUEST_H

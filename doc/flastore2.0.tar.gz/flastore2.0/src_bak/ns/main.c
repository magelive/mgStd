#include "ns.h"

int main(int argc ,char** argv)
{

    int                   ret;
    NodeServer            *ns;

    tawstd_init(0,NULL);
    ns = ns_init("/etc/flastore2.conf");
    ret = ns_run(ns);

    ns_close(ns);

    return ret;

}

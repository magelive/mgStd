#include <sys/stat.h>

#include <sys/epoll.h>
#include <sys/eventfd.h>
#include <errno.h>
#include <time.h>
#include <dirent.h>
#include <sys/types.h>

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif // _GNU_SOURCE

#ifndef __USE_GNU
#define __USE_GNU
#endif // __USE_GNU

#include <fcntl.h>
#include "ns.h"
#include "../libflastore/comm_packet.h"
#include "../libflastore/flastore.h"
#include "ns_writer.h"
#include <poll.h>
int ns_writer_open_read(NodeServerWriter *writer,const char* file_path)
{

    if( access(file_path,F_OK) !=0)
    {
        fl_error_log("file %s not exist",file_path);
        return 1;
    }

    writer->data_fd = open(file_path, O_RDONLY| O_CREAT |O_DIRECT, S_IRUSR| S_IWUSR |S_IWGRP|S_IRGRP);
     fl_debug_log("NS writer::open_read file_path=%s,fd=%d",file_path,writer->data_fd);

    return 0;
}


char* ns_writer_open_new(NodeServerWriter *writer, const char* name, const char* protocol_str)
{
    if(strlen(name)<=8){
         fl_error_log("ns_writer_open_recent error,file name %s too short.",name);
         return NULL;
    }
    char datastr[9];
    sprintf(datastr,"%c%c/%c%c/%c%c",name[2],name[3],name[4],name[5],name[6],name[7]);
    char newpath[1024];
    sprintf(newpath,"%s/%s/%s",writer->data_path,protocol_str,datastr);

    if( access(newpath,F_OK) !=0)
    {
         fl_make_multi_dir(newpath, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
    }

    sprintf(newpath,"%s/%s/%s/%d.dat",writer->data_path,protocol_str,datastr,writer->max_fileid);
    writer->data_fd = open(newpath, O_WRONLY| O_CREAT |O_DIRECT, S_IRUSR| S_IWUSR |S_IWGRP|S_IRGRP);
    strcpy(writer->now_file,newpath);
    strcpy(writer->file_name,name);
    strcpy(writer->protocol_str,protocol_str);
    return strdup(newpath);;
}

char* ns_writer_open_recent(NodeServerWriter *writer, const char* name, const char* protocol_str)
{
    if(strlen(name)<=8){
         fl_error_log("ns_writer_open_recent error,file name %s too short.",name);
         return NULL;
    }
    //是上次使用的fd，则直接返回文件名。
    if(writer->data_fd > 0 && strcmp(writer->file_name,name)==0 && strcmp(writer->protocol_str,protocol_str)==0){
        return strdup(writer->now_file);
    }
    char str[32];
    char datastr[9];
    sprintf(datastr,"%c%c/%c%c/%c%c",name[2],name[3],name[4],name[5],name[6],name[7]);
    char newpath[100];
    sprintf(newpath,"%s/%s/%s",writer->data_path,protocol_str,datastr);

    fl_debug_log("ns_writer_open_recent newpath=%s",newpath);

    DIR* d = opendir(newpath);

    fl_debug_log("ns_writer_open_recent d=%p",d);
    if(d == NULL)//no such dir
    {
        writer->max_fileid = 1; //开一个新目录，文件id从1开始。
        return ns_writer_open_new(writer,name,protocol_str);
    }

    char*  pos;
    struct dirent files;
    struct dirent* pfiles;
    int ret=0;
    int i=0;
    int max=0;
    do //找本目录最大文件id
    {
        ret = readdir_r(d,&files,&pfiles);

        if(ret != 0||pfiles ==NULL)
            break;
        if(files.d_type == DT_LNK || files.d_type == DT_REG || files.d_type == DT_UNKNOWN)
        {
            if(strcmp(files.d_name+strlen(files.d_name)-strlen(".dat"),".dat")==0)
            {
                memset(str,0,32);
                strncpy(str,files.d_name,strlen(files.d_name)-strlen(".dat"));
                i = atoi(str);
                max = i>max?i:max;
            }
        }
    }while(pfiles&&ret ==0);
    writer->max_fileid = max;

    if(writer->max_fileid > 0)//打开需要写的文件
    {
        if(writer->file_size_now >= NS_FILE_MAX_SIZE)//如果大于2G，需要新开一个文件。
        {
            writer->file_size_now = 0;
            (writer->max_fileid)++;
        }

        sprintf(newpath,"%s/%d.dat",newpath,writer->max_fileid);
            //reopen for aio
        close(writer->data_fd);
        writer->data_fd = open(newpath,O_WRONLY|O_CREAT|O_DIRECT , S_IRUSR| S_IWUSR |S_IWGRP|S_IRGRP);
        strcpy(writer->now_file,newpath);
        goto ret;

    }
    //文件不可访问,或新目录
    writer->max_fileid = 1;
    ns_writer_open_new(writer,name,protocol_str);
ret:
    fl_debug_log("ns_writer_open_recent close dir =%s max fd=%d",newpath,writer->data_fd);
    closedir(d);
    return strdup(newpath);
}

void ns_aio_callback(io_context_t ctx, struct iocb *iocb, long res, long res2)
{

    fl_debug_log("DATA request_type: %s, offset: %lld, length: %lu, res: %ld, res2: %ld\n",
                 (iocb->aio_lio_opcode == IO_CMD_PREAD) ? "READ" : "WRITE", iocb->u.c.offset, iocb->u.c.nbytes, res, res2);
    AioData* aio_data = (AioData*)iocb->data;
    if(iocb->aio_lio_opcode == IO_CMD_PWRITE)
    {
       if(!aio_data->sync){
            BlockReportInfo* block_info = (BlockReportInfo*)(aio_data->user_data);
           //if(block_info.length+512 <= iocb->u.c.nbytes)
           //    block_info.length = iocb->u.c.offset;

            fl_debug_log("ns_aio_callback write ok,report to RS name=%s,offset=%lld,filename=%s,protocol_flag=%d",
                block_info->name,iocb->u.c.offset,block_info->filename, block_info->protocol_flag);

           ZYList *blk_info_list=zylist();
           zylist_append_int32(blk_info_list,block_info->nsid);
           zylist_append_str(blk_info_list,block_info->filename);
           zylist_append_int64(blk_info_list,iocb->u.c.offset);
           zylist_append_int64(blk_info_list,block_info->length);
          //文件名，offset，NSid，NS文件路径，NS文件offset，长度。


           block_report_sync(block_info->rs_client,
                        block_info->name,
                        block_info->offset,
                        blk_info_list,
                        block_info->protocol_flag);

           zylist_free(blk_info_list);
           free(block_info->name);
           free(block_info->filename);
           taw_free(block_info);
       }
       else{
            AioWriteData* aio_wdata = (AioWriteData*)(aio_data->user_data);
            BlockReportInfo* block_info = (BlockReportInfo*)(aio_wdata->user_data);
           //if(block_info.length+512 <= iocb->u.c.nbytes)
           //    block_info.length = iocb->u.c.offset;

            fl_debug_log("ns_aio_callback write ok,report to RS name=%s,offset=%lld,filename=%s,protocol_flag=%d",
                block_info->name,iocb->u.c.offset,block_info->filename, block_info->protocol_flag);

           ZYList *blk_info_list=zylist();
           zylist_append_int32(blk_info_list,block_info->nsid);
           zylist_append_str(blk_info_list,block_info->filename);
           zylist_append_int64(blk_info_list,iocb->u.c.offset);
           zylist_append_int64(blk_info_list,block_info->length);
          //文件名，offset，NSid，NS文件路径，NS文件offset，长度。


           block_report_sync(block_info->rs_client,
                        block_info->name,
                        block_info->offset,
                        blk_info_list,
                        block_info->protocol_flag);

           zylist_free(blk_info_list);
           free(block_info->name);
           free(block_info->filename);
           taw_free(block_info);

           AioReadCond* write_cond = (AioReadCond*)(aio_wdata->aio_cond);
           if(write_cond->waiting==0){
              poll(0,0,1);
           }
           pthread_mutex_lock(&(write_cond->mutex));
           fl_debug_log("ns_aio_callback write pthread_cond_signal cond=%p,mutex=%p",&(write_cond->cond),&(write_cond->mutex));
           pthread_cond_signal(&(write_cond->cond));
           pthread_mutex_unlock(&(write_cond->mutex));


       }
           //DEBUG:测试数据是否正确
           // char data_tmp[4096];
           // memset(data_tmp,97,4096);
           // if(memcmp(iocb->u.c.buf,data_tmp,2048)){
          //       fl_error_log("data error2: data_info=%s",(char*)iocb->u.c.buf);
         //  }
       free(iocb->u.c.buf);
    }
    else{
        AioReadCond* read_cond = (AioReadCond*)(aio_data->user_data);
        if(read_cond->waiting==0){
            poll(0,0,1);
        }
        pthread_mutex_lock(&(read_cond->mutex));
        char *buf=iocb->u.c.buf;
        // fl_debug_log("ns_aio_callback read pthread_cond_signal buf=%p %c%c%c%c%c",iocb->u.c.buf,buf[0],buf[1],buf[2],buf[3],buf[4]);
        pthread_cond_signal(&(read_cond->cond));
        pthread_mutex_unlock(&(read_cond->mutex));
    }
    taw_free(aio_data);
    free(iocb);
}

void* ns_event_hander(void* arg)
{
    fl_debug_log("ns_event_hander ");
    NodeServerWriter* writer = (NodeServerWriter*)arg;
    //struct cds_wfq_node* node = cds_wfq_dequeue_blocking(&(writer->queue));
    //NodeServerWriter_cb* cb = container_of(node,NodeServerWriter_cb,next);
    struct io_event events[NS_MAX_WRITE_IO_OPTS];

    struct epoll_event epevent;
    uint64_t finished_aio;
    int i =0;
    int r =0;
    struct timespec tms;
    while (writer->is_running) {
         fl_debug_log("NS writer::is_running");
        if (epoll_wait(writer->epoll_fd, &epevent, 1, -1) != 1) {
            fl_error_log("NS writer::epoll_wait");
            if(errno != 4) // in gdb debug
                return (void*)-1;
        }

        if (read(writer->event_fd, &finished_aio, sizeof(finished_aio)) != sizeof(finished_aio)) {
            fl_error_log("NS writer::read event_fd error");
            return (void*)-2;
        }

        //处理完成的写入事件
        while (finished_aio > 0) {
            tms.tv_sec = 0;
            tms.tv_nsec = 0;
            r = io_getevents(writer->ctx, 1, NS_MAX_WRITE_IO_OPTS, events, &tms);
            if (r > 0) {
                for (i = 0; i < r; ++i) {
                    // res 实际完成字节数，res2,0表示成功
                     AioData* aio_data =  (AioData*)events[i].data;
                    ((io_callback_t)(aio_data->callback))(writer->ctx, events[i].obj, events[i].res, events[i].res2);
                }
                finished_aio -= r;
            }
        }
    }

    return NULL;
}

NodeServerWriter * ns_writer_init()
{
     fl_debug_log("NS writer::ns_writer_init");
    NodeServerWriter *writer=(NodeServerWriter *)taw_malloc("NodeServerWriter",sizeof(NodeServerWriter),0);
    if(!writer){
         fl_error_log("NS writer::taw_malloc writer error");
         return NULL;
    }
    memset(writer,0,sizeof(NodeServerWriter));

    if(io_setup(NS_MAX_WRITE_IO_OPTS, &(writer->ctx)))
    {
        fl_error_log("NS writer::io_setup error");
    }

    writer->epoll_fd = epoll_create(1);
    if (writer->epoll_fd== -1) {
        fl_error_log("NS writer::epoll_create");
    }
    pthread_mutex_init(&(writer->write_mutex),NULL);
    writer->is_running = 1;


    writer->event_fd= eventfd(0, EFD_NONBLOCK | EFD_CLOEXEC);
    if (writer->event_fd== -1) {
        fl_error_log("NS writer::eventfd");
    }

    struct epoll_event epevent;

    epevent.events = EPOLLIN | EPOLLET;
    epevent.data.ptr = NULL;

    if(epoll_ctl(writer->epoll_fd, EPOLL_CTL_ADD, writer->event_fd, &(epevent))) {
         fl_error_log("NS writer::epoll_ctl add");
    }
    writer->max_fileid = 1;
    writer->file_size_now = 0;
    pthread_create(&(writer->event_thread),NULL,ns_event_hander,writer);
    return writer;
}

void ns_writer_close(NodeServerWriter *writer)
{
    close(writer->data_fd);
    writer->is_running = 0;
    taw_free(writer);
}

uint64_t ns_write(NodeServerWriter *writer, void* block_info, const char* protocol_str, void* buffer, uint64_t buffer_len)
{
    fl_debug_log("NS writer::ns_write protocol_str=%s,len=%lld",protocol_str,buffer_len);
    if(writer->file_size_now+buffer_len >= NS_FILE_MAX_SIZE)//大于2G，新开一个文件。
    {
        close(writer->data_fd);
        (writer->max_fileid)++;
         ns_writer_open_new(writer, ((BlockReportInfo*)block_info)->name, protocol_str);
    }

    struct iocb *iocbps[1];
    struct iocb *data_iocbp;//temp pointer
    errno=0;
    data_iocbp = calloc(1,sizeof(struct iocb));
    iocbps[0] = data_iocbp;

    AioData* aio_data =  (AioData*)taw_malloc("AioData",sizeof(AioData),0);
    aio_data->user_data = block_info;
    aio_data->callback = ns_aio_callback;
    aio_data->sync = 0;

    pthread_mutex_lock(&(writer->write_mutex));
    if(writer->data_fd<=0)
    {
         ns_writer_open_new(writer, ((BlockReportInfo*)block_info)->name, protocol_str);
    }
    uint64_t offset = lseek(writer->data_fd, 0, SEEK_END);
    fl_debug_log("io_context=%p,fd==========%d",&writer->ctx,writer->data_fd);
    io_prep_pwrite(data_iocbp,writer->data_fd,buffer,buffer_len,offset);
    io_set_eventfd(data_iocbp, writer->event_fd);
    data_iocbp->data = aio_data;
    //io_set_callback(data_iocbp, ns_aio_callback);
    int ret =  io_submit(writer->ctx,1,iocbps);
    writer->file_size_now+=buffer_len;
    pthread_mutex_unlock(&(writer->write_mutex));

    if( ret < 0)
    {
        errno=-ret;
        fl_error_log("NS writer::io_submit data error");
        return 0;
    }
    return buffer_len;
}

uint64_t ns_read(NodeServerWriter *writer, void* ns,const char* file_path, void* buffer,uint64_t offset, uint64_t buffer_len)
{

    fl_debug_log("NS writer::ns_read len=%lld offset=%lld",buffer_len,offset);
    struct iocb *iocbps[1];
    struct iocb *data_iocbp;//temp pointer
    errno=0;
    data_iocbp = calloc(1,sizeof(struct iocb));
    data_iocbp->data = ns;

    iocbps[0] = data_iocbp;

    AioData* aio_data = (AioData*)taw_malloc("AioData",sizeof(AioData),0);
    AioReadCond* read_cond = (AioReadCond*)taw_malloc("AioReadCond",sizeof(AioReadCond),0);
    pthread_mutex_init(&(read_cond->mutex),NULL);
    pthread_cond_init(&(read_cond->cond),NULL);
    read_cond->waiting=0;
    aio_data->user_data = read_cond;
    aio_data->callback = ns_aio_callback;

    pthread_mutex_lock(&(writer->write_mutex));
    int fd = open(file_path, O_RDONLY | O_CREAT | O_DIRECT, 0644);//多线程读一个文件，造成打开失败 fd=-1;
    fl_debug_log("io_context=%p,fd==========%d",&writer->ctx,fd);
    io_prep_pread(data_iocbp,fd,buffer,buffer_len,offset);
    io_set_eventfd(data_iocbp, writer->event_fd);
    data_iocbp->data = aio_data;
   // io_set_callback(data_iocbp, ns_aio_callback);
    int ret =  io_submit(writer->ctx,1,iocbps);
    pthread_mutex_unlock(&(writer->write_mutex));

    if(ret < 0)
    {
        errno=-ret;
        fl_error_log("NS READ::io_submit data error %s",strerror(errno));
        return 0;
    }
    //等待读完返回。条件锁。
    pthread_mutex_lock(&(read_cond->mutex));
    read_cond->waiting=1;
    pthread_cond_wait(&(read_cond->cond),&(read_cond->mutex));
    pthread_mutex_unlock(&(read_cond->mutex));
    taw_free(read_cond);
    close(fd);
    return buffer_len;
}

uint64_t ns_write_sync(NodeServerWriter *writer, void* block_info, const char* protocol_str, void* buffer, uint64_t buffer_len)
{
    fl_debug_log("NS writer::ns_write protocol_str=%s,len=%lld",protocol_str,buffer_len);
    if(writer->file_size_now+buffer_len >= NS_FILE_MAX_SIZE)//大于2G，新开一个文件。
    {
         fl_debug_log("NS writer open new file.");
        close(writer->data_fd);
        (writer->max_fileid)++;
        ns_writer_open_new(writer, ((BlockReportInfo*)block_info)->name, protocol_str);
    }

    struct iocb *iocbps[1];
    struct iocb *data_iocbp;//temp pointer
    errno=0;
    data_iocbp = calloc(1,sizeof(struct iocb));
    iocbps[0] = data_iocbp;

    fl_debug_log("io_context=%p,fd==========%d",&writer->ctx,writer->data_fd);

    AioData* aio_data =  (AioData*)taw_malloc("AioData",sizeof(AioData),0);
    AioWriteData* aio_wdata =  (AioWriteData*)taw_malloc("AioWriteData",sizeof(AioWriteData),0);
    AioReadCond* write_cond = (AioReadCond*)taw_malloc("AioReadCond",sizeof(AioReadCond),0);
    pthread_mutex_init(&(write_cond->mutex),NULL);
    pthread_cond_init(&(write_cond->cond),NULL);
    write_cond->waiting=0;
    aio_wdata->user_data = block_info;
    aio_wdata->aio_cond = write_cond;
    aio_data->user_data = aio_wdata;
    aio_data->callback = ns_aio_callback;
    aio_data->sync = 1;

    uint64_t offset = lseek(writer->data_fd, 0, SEEK_END);

    pthread_mutex_lock(&(writer->write_mutex));
    io_prep_pwrite(data_iocbp,writer->data_fd,buffer,buffer_len,offset);
    io_set_eventfd(data_iocbp, writer->event_fd);
    data_iocbp->data = aio_data;
    //io_set_callback(data_iocbp, ns_aio_callback);
     fl_debug_log("io_submit begin");
    int ret =  io_submit(writer->ctx,1,iocbps);
    writer->file_size_now+=buffer_len;
     fl_debug_log("io_submit over");
    pthread_mutex_unlock(&(writer->write_mutex));
    fl_debug_log("io_submit over pthread_mutex_unlock");

    //等待返回。条件锁。
    pthread_mutex_lock(&(write_cond->mutex));
    fl_debug_log("wait for  cond=%p,mutex=%p",&(write_cond->cond),&(write_cond->mutex));
    write_cond->waiting=1;
    pthread_cond_wait(&(write_cond->cond),&(write_cond->mutex));
    pthread_mutex_unlock(&(write_cond->mutex));


    taw_free(aio_wdata);
    taw_free(write_cond);
    if( ret < 0)
    {
        errno=-ret;
        fl_error_log("NS writer::io_submit data error");
        return 0;
    }
     fl_debug_log("wait for cond ok");
    return buffer_len;
}

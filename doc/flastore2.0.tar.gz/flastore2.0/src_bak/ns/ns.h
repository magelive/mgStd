//ns的主要操作函数。读写文件，多副本
#ifndef FL_NODESERVER_H
#define FL_NODESERVER_H
#include <stdint.h>
#include "../libflastore/fl_define.h"
#include "../libflastore/comm_buf.h"
#include "../libflastore/rs_client.h"
#include "ns_writer.h"
#include <ngtawstd/cache.h>

typedef struct NodeServer
{
    ZYMap 		      *block_map;            //数据缓存，收到文件先缓存。可供读
    ZYMap		      *block_map_tmp;        //数据下盘时的替换cache
    ConnManager       conn_manager;          //连接管理，地址等信息
    NodeServerWriter  *writer;               //用于本地文件读写，aio
    uint32_t          ns_id;                 //ns_id以注册时的顺序分配id。重启时从RS查询id
    RootServerClient  *rs_client;            //与RS进行通信
    uv_timer_t        timer_req;             //定时任务

    char              *data_top_dir;         //用户数据存储主目录
    pthread_mutex_t   mutex_x;               //锁
    pthread_mutex_t   write_lock;            //写锁
    uint64_t	      max_size;              //ns总容量
    uint64_t	      used_size;             //ns已使用容量
    uint64_t	      cache_size;            //cache最大值
    uint64_t          cache_used_size;       //cache已使用大小

    uint32_t          started:1;             //是否运行
    uint32_t          cache_ok:1;            //cache是否可写
    uint32_t          flushing:1;            //正在刷新缓存
	uint32_t          safe_mode:1;           //是否安全模式,安全模式只可读
    uint32_t          is_primary:1;          //是否是主NS

}NodeServer;

typedef struct _BlockReportInfo{

    RootServerClient    *rs_client;
    char                *name;
    uint64_t            offset;
    uint32_t            nsid;
    char                *filename;
  //  uint64_t            file_offset;
    uint64_t            length;
    uint32_t            protocol_flag;

}BlockReportInfo;

typedef struct _DataInfo{

    char                *name;
    uint64_t            offset;
    uint64_t            length;
    uint32_t            protocol_flag;
    void                *data;

}DataInfo;

//#################################################################util
NodeServer* ns_init(char* conffile);//ns初始化

int ns_run(NodeServer* ns);//开始ns的server，RPC循环

int ns_close(NodeServer* ns);//关闭和析构工作

int freeze_cache(NodeServer* ns);//block_cache不可以写，new一个tmp Cache替换blockcache，切换过程加锁

int thaw_cache(NodeServer* ns);

int ns_write_and_free_cache(NodeServer* ns,int sync);

unsigned char* ns_cache_key(unsigned char* md,const char* name, uint64_t offset, uint32_t protocol_flag);

//#################################################################Client 调用

int locale_write_ns(NodeServer *ns, const char* name, uint64_t offset, uint64_t length, uint32_t protocol_flag, void* data, void *context);//把data写文件，并报告RS

ZYBuffer* locale_read_ns(NodeServer *ns, const char* name, uint64_t offset, uint32_t protocol_flag, const char* file_name, uint64_t file_offset, uint64_t length);//读文件，将data返回。

int locale_close_ns(NodeServer *ns, uint32_t flag);//关闭NS的请求处理

int locale_delete_ns_file(NodeServer *ns, uint32_t flag, uint64_t time);//删除数据请求处理

//#################################################################RootServer调用

#endif //FL_NODESERVER_H

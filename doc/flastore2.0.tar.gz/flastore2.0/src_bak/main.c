#include "client/client.h"
#include <time.h>
#include <sys/time.h>
#include <unistd.h>

double difftimeval(const struct timeval *tv1, const struct timeval *tv2)
{
        double d;
        time_t s;
        suseconds_t u;

        s = tv1->tv_sec - tv2->tv_sec;
        u = tv1->tv_usec - tv2->tv_usec;
        if (u < 0){
            --s;
            u = tv1->tv_usec + 1000000.0  - tv2->tv_usec;
        }

        d = s;
        d *= 1000000.0;
        d += u;

        return d;
}

//客户端测试程序
int main(int argc, char** argv){
    int ret;
    flastore_client *fcli = flastore_open("tcp://127.0.0.1:5000");
    if(!fcli)
        return -1;

    char *test_data_http="<<BEGIN-HTTPaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
    int blk_len=1024*4;
    char *test_data_post=malloc(blk_len+1);
    memset(test_data_post,97,blk_len);
    test_data_post[blk_len]=0;
    int cnt_w,cnt_r,i;
    char filename[50];
    char *filename_p;
    if(argc >=3){
        cnt_w = atoi(argv[1]);
        cnt_r = atoi(argv[2]);
        filename_p = argv[3];
    }
    else{
        cnt_w = 2;
        cnt_r = 1;
        filename_p = "201411191014test_file";
    }

    //写入多条数据
    i=cnt_w;
    struct timeval start_time,end_time,end_time2;
    gettimeofday(&start_time,NULL);
    while(i--){
        sprintf(filename,"%s%d",filename_p,i);
        flastore_write(fcli,filename,FL_HTTP_POST,test_data_post,strlen(test_data_post));
    }
    free(test_data_post);

    gettimeofday(&end_time,NULL);
    double tm_w = difftimeval(&end_time, &start_time);

    //读取多条数据
    i=cnt_r;
    while(i--){
        sprintf(filename,"%s%d",filename_p,i);
        ZYBuffer *buffer = flastore_read(fcli,filename,0,FL_HTTP_POST);
        if(buffer){
            char *cb=(char*)buffer->data;
            fl_warn_log("flastore_read len=%d data=%c%c%c\n\n",strlen(cb),cb[0],cb[1],cb[4096-1]);
            zybuffer_free(buffer);
        }
    }
    fl_debug_log("read over");
    gettimeofday(&end_time2,NULL);
    double tm_r = difftimeval(&end_time2, &end_time);


   // ret = flastore_close_file(fcli,filename,FL_HTTP_GET);
   // fl_debug_log("flastore_close_file ret=%d",ret);

    ret = flastore_close(fcli);
    fl_debug_log("flastore_close over");
    fl_error_log("Write %d Counts, %.lf Counts/s, %.2lf KB/s. Read %d Counts, %.lf Counts/s, %.2lf KB/s."
                 , (cnt_w)
                 , (cnt_w)/(tm_w/1000000.0)
                 ,(cnt_w*blk_len)/(tm_w/1000000.0)/1000
                 , cnt_r
                 , cnt_r/(tm_r/1000000.0)
                 ,(cnt_r*blk_len)/(tm_r/1000000.0)/1000);

}

//收到请求后，根据协议头调用不同request函数，解析出参数，分别调用rs.c的函数
#ifndef RS_REQUEST_H
#define RS_REQUEST_H

#include <ac.h>
#include "../libflastore/rs_protocol.h"
#include "../libflastore/fl_define.h"
#include "../libflastore/serialization.h"
//root server解析出参数，调用rs的函数
int rs_handle(ac_request_t *r);

int rs_worker_handle(ac_request_t *r, void *args);

void rs_time_handler(uv_timer_t* handle);
#endif // RS_REQUEST_H


//rs的主要操作函数。读写bkdb
#ifndef FL_ROOTSERVER_H
#define FL_ROOTSERVER_H

#include <stdint.h>
#include "../libflastore/fl_define.h"
#include "rs_bkdb.h"
#include "../libflastore/comm_buf.h"
#include <pthread.h>
#include <ngtawstd/cache.h>
#include <ngtawutils/md5.h>

typedef struct RootServer
{
    BKDBManager *file_table;          //操作bkdb 写文件信息。
    BKDBManager *block_table;         //操作bkdb 写block信息。
    ConnManager conn_manager;         //连接管理，地址等信息
    TSCache*      cache;              //缓存打开文件的元数据（文件名为key，元数据为data）
    uint32_t      replica_num;        //副本数
    uint32_t      ns_num;             //node server数（也是ns_id最大值）
    uint64_t      block_len;          //一个block大小
    ZYList        *node_server_list;  //node server列表
    ZYMap         *ns_name_map;       //Node Server IP与id对应关系
    char*         bkdb_top_dir;       //元数据存储主目录
    char*         data_top_dir;       //用户数据存储主目录
    pthread_mutex_t mutex_x;          //cache锁
   // pthread_mutex_t mutex_db;          //db锁
    uv_timer_t    timer_req;          //定时任务
    uint32_t      dayofmonth;         //今日的日期，用于切换bkdb
    uint32_t      del_interval[FL_PROTOCOL_MAX];   //每种协议对应数据的保存天数
    uint32_t      ns_port;            //NS端口

    void          *publisher;         //zmq发送消息
    void          *context;           //zmq上下文

    uint32_t      started:1;          //是否运行
    uint32_t      table_ok:1;         //固定bkdb是否可用
    uint32_t      safe_mode:1;        //是否安全模式

}RootServer;

typedef struct FileInfo
{
    uint64_t    create_time;
    uint64_t    close_time;
    char*       file_name;
    char*       owner;
    uint64_t    size;
    md5_t     md5ctx;
    unsigned char md5[16];

}FileInfo;

typedef struct MetaInfo
{
    FileInfo    file_info;
    ZYMap       *block_info;

}MetaInfo;

//#################################################################util
RootServer *rs_init(char* conffile);

int rs_close(RootServer *rs);

int rs_run(RootServer *rs);

void rs_cache_free_cb(void* data);

DB* get_proper_db(RootServer *rs, BKDBManager *dbconf, const char* name,uint32_t protocol_flag);

unsigned char *file_name_to_id(const char *name);

uint32_t ns_name_to_id(RootServer *rs, const char *name);

const char *ns_id_to_name(RootServer *rs, uint32_t id);

int rs_init_ns_name_map(RootServer *rs);

ZYList* get_random_ns_locations(RootServer *rs);

int write_file_table(RootServer *rs, DB* dbp, FileInfo * file_info, uint32_t protocol_flag, int write_cache);

int write_file_cache(RootServer *rs, FileInfo * file_info, uint32_t protocol_flag);

FileInfo *read_file_table(RootServer *rs, DB* dbp,const char *name, uint32_t protocol_flag, FileInfo *file_info);

FileInfo *read_file_cache(RootServer *rs, const char *name, uint32_t protocol_flag, FileInfo *file_info);

uint32_t offset_to_block_id(RootServer *rs, uint64_t offset);

ZYMap *read_block_map(RootServer *rs, DB* dbp, const char *name, uint32_t protocol_flag, int* should_free);

ZYMap *read_block_map_cache(RootServer *rs, const char *name, uint32_t protocol_flag);

int write_block_table_r(RootServer *rs, DB* dbp, const char* name, uint64_t offset, ZYList *block_info, uint32_t protocol_flag);

int write_block_table(RootServer *rs, DB* dbp, const char* name, uint64_t offset, ZYList *block_info, uint32_t protocol_flag);

int write_block_list_cache_r(RootServer *rs, const char* name, uint64_t offset, ZYList *block_info, uint32_t protocol_flag);

int write_block_list_cache(RootServer *rs, const char* name, uint64_t offset, ZYList *block_info, uint32_t protocol_flag);

int write_block_cache(RootServer *rs, const char* name, uint32_t protocol_flag, ZYMap* block_info_map);

ZYList *read_block_table(RootServer *rs, DB* dbp, const char* name, uint64_t offset,ZYMap **block_map, uint32_t protocol_flag, int* should_free);

ZYMap *read_block_map_dbonly(RootServer *rs, DB* dbp, const char *name, uint32_t protocol_flag);

int delete_file(RootServer *rs, time_t time);

int flush_cache(RootServer *rs);

int save_sys_log(RootServer *rs);

int load_sys_log(RootServer *rs);

char* get_file_key(RootServer *rs, char* cache_key, uint32_t flag, const char* name);
//#####################################################################Client调用

ZYList* locale_create_file(RootServer *rs, const char* name, const char* client_name, uint64_t block_len, uint32_t protocol_flag);//新建一个文件block，返回NS地址,flag={FL_OVER_WRITE,FL_SINGLE,FL_REPLICATIONS}

int locale_rename_file(RootServer *rs, const char* old_name, const char* new_name, uint32_t protocol_flag);//文件更名

int locale_close_file(RootServer *rs, const char* name, uint32_t protocol_flag);//关闭文件，zmq发布消息通知外界文件写完。

int locale_delete_file(RootServer *rs, const char* name, uint32_t protocol_flag);//删除文件

int locale_mkdir(RootServer *rs, const char* name, int masked);//创建目录

ZYList* locale_append_file(RootServer *rs, const char* name, uint32_t protocol_flag);//追加文件，返回NS地址

ZYList* locale_write_file(RootServer *rs, const char* name, uint64_t offset, int flag);//写文件，返回NS地址（暂不支持随机写）

ZYList* locale_get_block_locations(RootServer *rs, const char* name, uint64_t offset, uint32_t protocol_flag);//返回指定block的NS地址

int locale_set_replications(RootServer *rs, const char* name, int replications, uint32_t protocol_flag);//设定副本数

ZYList* locale_add_block(RootServer *rs, const char* name, uint32_t protocol_flag);//给文件增加block，返回NS地址

ZYList* locale_get_listing(RootServer *rs, const char* name, uint32_t protocol_flag);//返回文件或目录的概要信息

int locale_set_safemode(RootServer *rs, int flag);//设置为安全模式，可读不可写。

ZYMap* locale_get_fileinfo(RootServer *rs, const char* name, uint32_t protocol_flag);//返回文件的具体信息

ZYList* locale_get_ns_server_list(RootServer *rs);//返回所有ns地址

//#######################################################################NS调用

//NS注册到RS，重启NS需要把现有block信息告知RS（暂时不支持重启，假设都是第一次注册）
int locale_ns_register(RootServer *rs, const char* location, uint64_t max_size, ZYList* block_info);

//NS收到一个block,已写入磁盘时，报告给RS（ns地址，文件名，offset，file_path, file_offset, length）
int locale_block_report(RootServer *rs, const char* name, uint64_t offset, ZYList *block_info, uint32_t protocol_flag);

int locale_block_received(RootServer *rs,const char* name, uint64_t offset, uint32_t ns_id, uint32_t protocol_flag, void* context);//NS收到一个block时，写入缓存时，报告给RS(ns 地址，文件名，offset)

ZYList* locale_get_block_info(RootServer *rs, const char* name, uint64_t offset, uint32_t protocol_flag);//获得一个block的位置信息

#endif // FL_ROOTSERVER_H

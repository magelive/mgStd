#include "../libflastore/fl_define.h"
#include "rs_bkdb.h"
#include "../libflastore/flastore.h"


#include <string.h>
#include <stdarg.h>
#include <ngtawstd/mem.h>




int rs_bkdb_free(BKDBManager* dbconf)
{
    if(!dbconf)
        return -1;
    dbconf->db_env->close(dbconf->db_env, 0);
    free(dbconf->top_dir);
    free(dbconf->name);
    taw_free(dbconf);
    return 0;
}

BKDBManager* rs_bkdb_parse_conf(char* top_dir)
{
    fl_debug_log("rs_bkdb_parse_conf");
    BKDBManager* dbconf = NULL;
    int ret;

    dbconf = (BKDBManager*)taw_malloc("rs_bkdb_parse_conf",sizeof(BKDBManager),0);
    if(!dbconf)
    {
        return NULL;
    }
    db_env_create(&dbconf->db_env, 0);

    dbconf->top_dir = strdup(top_dir);
    if(top_dir == NULL)
    {
        dbconf->top_dir = strdup(RS_BKDB_DEFAULT_TOPDIR);
    }

    char sub_dir[100];
    uint32_t index=0;
    char datastr[9];
    get_date_dir(datastr);
    while(index < FL_PROTOCOL_MAX)
    {
        sprintf(sub_dir, "%s/%s/%s", dbconf->top_dir,protocol_flag_to_str(index),datastr);
        fl_mkdir_p(sub_dir,0755);
        index++;
    }

    ret = dbconf->db_env->open(dbconf->db_env, dbconf->top_dir, DB_CREATE|DB_INIT_MPOOL, 0664);

    return dbconf;
}

int rs_bkdb_init_dbt(DBT* key,DBT* data)
{
    if(!key || !data)
        return -1;

    memset(key,0,sizeof(DBT));
    memset(data,0,sizeof(DBT));
    return 0;
}

/*
 * open失败，返回非0，否则，返回0
 */
int rs_bkdb_open(BKDBManager* dbconf, uint32_t index)
{
    if(!dbconf)
        return FL_ERROR;
    if(index>=FL_PROTOCOL_MAX)
    {
        fl_error_log("rs_bkdb_open error ,index=%d",index);
        return FL_ERROR;
    }

    int ret = 0;
    char dbname[50];
    char datastr[9];
    get_date_dir(datastr);

	sprintf(dbname, "%s/%s/%s", protocol_flag_to_str(index),datastr, dbconf->name);

    char subdir[100];//建目录
    sprintf(subdir, "%s/%s/%s", dbconf->top_dir,protocol_flag_to_str(index),datastr);
    fl_mkdir_p(subdir,0755);

    fl_debug_log("rs_bkdb_open %s\n", dbname);

    ret = db_create(&(dbconf->dbp[index]), dbconf->db_env, 0);
    if(ret != 0)
    {
        fl_error_log("Create dbp failed\n",db_strerror(ret));
        return ret;
    }
    ret = (dbconf->dbp[index])->open(dbconf->dbp[index], NULL, dbname, NULL, DB_BTREE, dbconf->open_flag, 0);
    if(ret !=0)
    {
        fl_error_log("Open db %s failed,%s\n",dbname,db_strerror(ret));
    }
    return ret;
}

/*
 * open失败，返回非0，否则，返回0
 */
int rs_bkdb_open_all(BKDBManager* dbconf)
{
    if(!dbconf)
        return FL_ERROR;
    uint32_t index=0;
    int ret = 0;

    char dbname[50];
    char subdir[100];//建目录
    char datastr[9];
    get_date_dir(datastr);
    while(index <FL_PROTOCOL_MAX)
    {

        sprintf(subdir, "%s/%s/%s", dbconf->top_dir,protocol_flag_to_str(index),datastr);
        fl_mkdir_p(subdir,0755);

        sprintf(dbname, "%s/%s/%s", protocol_flag_to_str(index), datastr, dbconf->name);

        fl_debug_log("rs_bkdb_open %s\n", dbname);

        ret = db_create(&(dbconf->dbp[index]), dbconf->db_env, 0);
        if(ret != 0)
        {
            fl_error_log("Create dbp failed\n",db_strerror(ret));
            return ret;
        }
        ret = (dbconf->dbp[index])->open(dbconf->dbp[index], NULL, dbname, NULL, DB_BTREE, dbconf->open_flag, 0);
        if(ret !=0)
        {
            fl_error_log("Open db %s failed,%s\n",dbname,db_strerror(ret));
        }
        index++;
    }

    return ret;
}

int rs_bkdb_close(BKDBManager* dbconf, uint32_t index)
{
    if(!dbconf)
        return FL_ERROR;
    if(index>=FL_PROTOCOL_MAX)
    {
        fl_error_log("rs_bkdb_close error ,index=%d",index);
        return FL_ERROR;
    }
    if(!dbconf->dbp[index])
        return -1;

    (dbconf->dbp[index])->close(dbconf->dbp[index],0);
    //taw_free(dbconf);
    return 0;
}

int rs_bkdb_close_all(BKDBManager* dbconf)
{
    if(!dbconf)
        return FL_ERROR;

    uint32_t index = 0;
    while(index < FL_PROTOCOL_MAX)
    {
        if(dbconf->dbp[index])
            (dbconf->dbp[index])->close(dbconf->dbp[index],0);
        index++;
    }
    //taw_free(dbconf);
    return 0;
}

int rs_bkdb_put_data(DB* dbp, const char* file_id, void* data, int size, int write_flag)
{
    fl_debug_log("rs_bkdb_put_data");
    if(!dbp || !file_id)
    {
        fl_error_log("dbp or key is NULL");
        return -1;
    }
    DBT key,value;
    int ret = 0;

    rs_bkdb_init_dbt(&key,&value);
    rs_bkdb_set_dbkey(&key,file_id);
    value.data = data;
    value.size = size;

    ret = dbp->put(dbp,NULL,&key,&value, write_flag);
    free(key.data);
    if(ret != 0)
    {
        fl_error_log("%s\n",db_strerror(ret));
        return -1;
    }
    if(value.data)
        taw_free(value.data);

    return 0;
}

void* rs_bkdb_get_data(DB* dbp, const char* file_id, int* size)
{
        DBT key,data;
        memset(&key,0,sizeof(DBT));
        memset(&data,0,sizeof(DBT));
        rs_bkdb_set_dbkey(&key,file_id);
        //fl_debug_log("rs_bkdb_get_data dbp=%p",dbp);

        int ret = dbp->get(dbp,NULL,&key,&data,0);

        //DBC *dbc;
        //dbp->cursor(dbp, NULL, &dbc, 0);
       // int ret = dbc->c_get(dbc, &key, &data, DB_SET);
        //dbc->close(dbc);
        free(key.data);

        if(ret != 0)
        {
            fl_error_log("%s\n",db_strerror(ret));
            return NULL;
        }
        if(size)
            *size = data.size;

        return data.data;
}


int rs_bkdb_set_dbkey(DBT* key, const char* file_id)
{
    //uint32_t* value = (uint32_t*)taw_malloc("uint32_t",strlen(file_id),0);
   // if(!value)
   //     return -1;
   // memcpy(value,file_id,4);
    key->data = strdup(file_id);
    key->size = strlen(file_id);
    return 0;
}

int rs_bkdb_delete_data(DB* dbp, const char* file_id)
{
    if(!dbp)
        return -1;

    int ret = 0;

    if(file_id)
    {
        DBT key;
        memset(&key,0,sizeof(DBT));
        rs_bkdb_set_dbkey(&key,file_id);
        ret = dbp->del(dbp,NULL,&key,0);
        free(key.data);
        if(ret != 0)
        {
            fl_error_log("%s\n",db_strerror(ret));
            return ret;
        }
    }
    else
    {
        int count = 0;
        ret = dbp->truncate(dbp,NULL,&count,0);
        if(ret != 0)
        {
            fl_error_log("%s\n",db_strerror(ret));
            return ret;
        }
        else
        {
            fl_error_log("%d record be deleted\n",count);
        }
    }
    return 0;
}

//收到请求后，根据协议头调用不同request函数，解析出参数，分别调用rs.c的函数

#include "rs_request.h"
#include "rs.h"


int rs_handle(ac_request_t *r)
{

    CommBuf           *cbf;
    CommBuf           *cbf_cb;
    int               cb_size;

    cbf = (CommBuf *) r->ipacket;

    if (!cbf)
        return 1;
    ac_message_t *m = (ac_message_t *)r->ms;
    ac_handler_pt *achandler = m->c->handler;
    RootServer *rs = (RootServer*)((achandler->user_data));


    if(rs->safe_mode){
       response_i32(r,FL_SAFE_MODE);
       return AC_OK;
    }


    const uint8_t *decode_ptr = cbf->data_ptr;
    size_t decode_remain = cbf->len;

    int header;
    header = decode_i32(&decode_ptr,&decode_remain);

    if(rs->started==0 && header!=FL_COMMAND_BLOCK_REPORT)//正在关闭，只接受block report请求
    {
       response_i32(r,FL_CLOSED);
       return AC_OK;
    }

    switch(header){
    //长任务push到线程中ac_thread_pool_push  ac_thread_pool_push(cp.threads, r, ac_hash_key((uint64_t)(long)r));
        case FL_COMMAND_CREATE: {
             fl_debug_log("Receive Request------------> FL_COMMAND_CREATE decode_ptr=%p",decode_ptr);
             const char* name = decode_str16(&decode_ptr,&decode_remain);
             const char* client_name = decode_str16(&decode_ptr,&decode_remain);
             uint64_t block_len = decode_i64(&decode_ptr,&decode_remain);
             uint32_t flag = decode_i32(&decode_ptr,&decode_remain);
             ZYList *list = locale_create_file(rs, name, client_name, block_len, flag);
             if(list)
                 response_zylist(r,list);
             else
                 response_i32(r,0);

             break;
        }
         case FL_COMMAND_APPEND: {
              fl_debug_log("Receive Request------------> FL_COMMAND_APPEND");

              const char* name = decode_str16(&decode_ptr, &decode_remain);
              uint32_t flag = decode_i32(&decode_ptr,&decode_remain);
              ZYList *list = locale_append_file(rs, name, flag);
              if(list)
                   response_zylist(r,list);
              else
                   response_i32(r,0);
              break;
          }
          case FL_COMMAND_CLOSE: {
              fl_debug_log("Receive Request------------> FL_COMMAND_CLOSE");
              const char* name = decode_str16(&decode_ptr, &decode_remain);
              uint32_t flag = decode_i32(&decode_ptr,&decode_remain);
              int ret = locale_close_file(rs, name, flag);
              response_i32(r, ret);
              break;
          }
          case FL_COMMAND_RENAME: {
              fl_debug_log("Receive Request------------> FL_COMMAND_RENAME");

              const char* old_name = decode_str16(&decode_ptr, &decode_remain);
              const char* new_name = decode_str16(&decode_ptr, &decode_remain);
              uint32_t flag = decode_i32(&decode_ptr,&decode_remain);
              int ret = locale_rename_file(rs, old_name,new_name,flag);
              response_i32(r, ret);
              break;
          }
          case FL_COMMAND_DELETE: {
              fl_debug_log("Receive Request------------> FL_COMMAND_DELETE");

              const char* name = decode_str16(&decode_ptr, &decode_remain);
              uint32_t flag = decode_i32(&decode_ptr,&decode_remain);
              int ret = locale_delete_file(rs, name, flag);
              response_i32(r, ret);
              break;
          }
          case FL_COMMAND_CLOSE_RS: {
              fl_debug_log("Receive Request------------> FL_COMMAND_CLOSE_RS");
              uint32_t flag = decode_i32(&decode_ptr,&decode_remain);
              int ret = locale_close_rs(rs, flag);
              response_i32(r, ret);
              break;
          }
         case FL_COMMAND_GET_BLOCK_LOCATIONS: {
              fl_debug_log("Receive Request------------> FL_COMMAND_GET_BLOCK_LOCATIONS");

              const char* name = decode_str16(&decode_ptr, &decode_remain);
              uint64_t offset = decode_i64(&decode_ptr, &decode_remain);
              uint32_t flag = decode_i32(&decode_ptr,&decode_remain);
              ZYList *list = locale_get_block_locations(rs, name, offset, flag);

              if(list)
                    response_zylist(r,list);
                else
                    response_i32(r,0);
              break;
          }
          case FL_COMMAND_GET_BLOCK_INFO: {
              fl_debug_log("Receive Request------------> FL_COMMAND_GET_BLOCK_INFO");

              const char* name = decode_str16(&decode_ptr, &decode_remain);
              uint64_t offset = decode_i64(&decode_ptr, &decode_remain);
              uint32_t flag = decode_i32(&decode_ptr,&decode_remain);
              ZYList *list = locale_get_block_info(rs, name, offset, flag);

              if(list)
                    response_zylist(r,list);
                else
                    response_i32(r,0);
              break;
          }
          case FL_COMMAND_GET_FILE_INFO: {
               fl_debug_log("Receive Request------------> FL_COMMAND_GET_FILE_INFO");
                const char* name = decode_str16(&decode_ptr, &decode_remain);
                uint32_t flag = decode_i32(&decode_ptr,&decode_remain);
                ZYMap *blk_map = locale_get_fileinfo(rs, name, flag);

                if(blk_map)
                    response_zymap(r, blk_map);
                else
                    response_error(r);

                break;
          }
          case FL_COMMAND_BLOCK_REPORT:{
               fl_debug_log("Receive Request------------> FL_COMMAND_BLOCK_REPORT");

                const char* name = decode_str16(&decode_ptr, &decode_remain);
                uint64_t offset = decode_i64(&decode_ptr, &decode_remain);
                uint32_t dump_size = decode_i32(&decode_ptr, &decode_remain);
                ZYList *block_info = zyload_zylist_ptr((void*)decode_ptr,dump_size);
                decode_ptr += dump_size;
                uint32_t flag = decode_i32(&decode_ptr,&decode_remain);
                int ret = locale_block_report(rs,name,offset,block_info,flag);
                response_i32(r, ret);

                break;

          }
          case FL_COMMAND_BLOCK_RECEIVE:{
               fl_debug_log("Receive Request------------> FL_COMMAND_BLOCK_RECEIVE");

                const char* name = decode_str16(&decode_ptr, &decode_remain);
                uint64_t offset = decode_i64(&decode_ptr, &decode_remain);
                uint32_t ns_id = decode_i32(&decode_ptr, &decode_remain);
                uint32_t flag = decode_i32(&decode_ptr,&decode_remain);
                int ret = locale_block_received(rs,name,offset,ns_id,flag,(void*)decode_ptr);
                response_i32(r, ret);

                break;

          }
          case FL_COMMAND_NS_REGISTER:{
               fl_debug_log("Receive Request------------> FL_COMMAND_NS_REGISTER");

                const char* name = decode_str16(&decode_ptr, &decode_remain);
                uint64_t max_size = decode_i64(&decode_ptr, &decode_remain);
                int ret = locale_ns_register(rs,name,max_size,NULL);
                response_i32(r, ret);

                break;

          }
          case FL_COMMAND_GET_NS_SERVER_LIST:{
                fl_debug_log("Receive Request------------> FL_COMMAND_GET_NS_SERVER_LIST");
                ZYList *list = locale_get_ns_server_list(rs);

                if(list)
                    response_zylist(r,list);
                else
                    response_i32(r,0);

                break;

          }

        default:{
            fl_error_log("unknown header.");
            r->opacket=NULL;
        }
    }

    return AC_OK;
}


int rs_worker_handle(ac_request_t *r, void *args)
{

    fl_debug_log("rs_worker_handle");
    CommBuf           *cbf;
    CommBuf           *cbf_cb;
    int               cb_size;

    cbf = (CommBuf *) r->ipacket;

    if (!cbf)
        return 1;
    ac_message_t *m = (ac_message_t *)r->ms;
    ac_handler_pt *achandler = m->c->handler;
    RootServer *rs = (RootServer*)((achandler->user_data));
    fl_debug_log("rs_worker_handle achandler =%p user_data=%p\n",achandler,achandler->user_data);

    const uint8_t *decode_ptr = cbf->data_ptr;
    size_t decode_remain = cbf->len;

    int header;
    header = decode_i32(&decode_ptr,&decode_remain);
    fl_debug_log("rs_worker_handle header =%d\n",header);
    switch(header){
        case 1:
        default:{
            fl_error_log("unknown header.");
            r->opacket=NULL;
        }
    }
    return AC_OK;
}

void rs_time_handler(uv_timer_t* handle){

    RootServer *rs = (RootServer*)((handle->data));

    if(!rs->started || rs->conn_manager.comm->stoped)
    {
       uv_timer_stop(handle);
     //  rs_close(rs);
    }

    time_t timep = time(0);
    struct tm *p;
    p = gmtime(&timep);

    fl_debug_log("rs_time_handler rs=%p,rs->dayofmonth=%d,tm_mday=%d",rs,rs->dayofmonth,p->tm_mday);

    //跨天
    if(p->tm_mday != rs->dayofmonth)
    {
        /**向所有NS发出刷内存的命令*/
        flush_cache(rs);

        /**定时任务用于bkdb切换，每天有若干固定的db对象，负责每天元数据读写。到0:00触发db对象的切换，
       由于定时任务30秒一次，所以每天0:00之后可能有30秒时间全部使用临时db。临时db在get_proper_db
       函数中判断和获取。*/
        fl_debug_log("Happy to a new day! Get new file tables and block tables, and close old ones");
        rs->table_ok = 0;
        rs_bkdb_close_all(rs->file_table);
        rs_bkdb_close_all(rs->block_table);
        rs_bkdb_open_all(rs->file_table);
        rs_bkdb_open_all(rs->block_table);
        rs->table_ok = 1;
        rs->dayofmonth = p->tm_mday;


        /**定时删除数据，比如保留30天的数据，那么每天删除往前数第31天的数据。
        先删除元数据，再通知对应的NS删除用户数据*/
        delete_file(rs, timep);

    }

}

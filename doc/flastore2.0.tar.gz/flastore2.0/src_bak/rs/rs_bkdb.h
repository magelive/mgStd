#ifndef RS_BKDB_H_
#define RS_BKDB_H_

#include <db.h>

#define RS_BKDB_DEFAULT_TOPDIR "/var/lib/flastore"

typedef struct BKDBManager
{
    DB	             *dbp[FL_PROTOCOL_MAX];
	DB_ENV           *db_env;
	char*            name;       //db名字和目录
	char*            top_dir;
	int              dump_size;
	int              write_flag; //DB_NOOVERWRITE
    int              open_flag;
}BKDBManager;

int rs_bkdb_open_all(BKDBManager* dbconf);//打开所有bkdb

int rs_bkdb_open(BKDBManager* dbconf, uint32_t index);//打开序号为index的bkdb数据库

int rs_bkdb_close(BKDBManager* dbconf, uint32_t index);//关闭序号为index的bkdb

int rs_bkdb_close_all(BKDBManager* dbconf);//关闭所有bkdb，并释放dbconf

int rs_bkdb_init_dbt(DBT* key,DBT* data);//初始化key data为0

int rs_bkdb_free(BKDBManager* dbconf);//析构dbconf

int rs_bkdb_set_dbkey(DBT* key,const char* file_id);//设置key为文件id

BKDBManager* rs_bkdb_parse_conf(char* top_dir);//分配conf，并赋值

int rs_bkdb_put_data(DB* dbp, const char* file_id, void* data, int size, int write_flag);//往bkdb插入数据 key/data对, DB_NOOVERWRITE

void* rs_bkdb_get_data(DB* dbp, const char* file_id, int* size);//从bkdb读取数据 key/data对

int rs_bkdb_delete_data(DB* dbp,const char* file_id);//删除文件id对应的数据,file_id为0,那么删除所有。


#endif //RS_BKDB_H_

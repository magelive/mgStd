#include <ngtawstd/zytypes.h>
#include "rs.h"

int main(int argc ,char** argv)
{

    RootServer            *rs;
    tawstd_init(0,NULL);

    rs = rs_init("/etc/flastore2.conf");

    rs_run(rs);

    rs_close(rs);

    return 0;

}


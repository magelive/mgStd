//rs的主要操作函数。读写bkdb
#include "rs.h"
#include <zmq.h>
#include <stdio.h>
#include <libconfig.h>
#include "../libflastore/ns_client.h"
#include <time.h>
#include <sys/types.h>
#include <dirent.h>
#include "rs_request.h"
#include "rs_request.c"
#include "../libflastore/comm_buf.h"
#include "../libflastore/comm_packet.h"
#include "../libflastore/fl_define.h"
#include <ac.h>
#include <openssl/md5.h>

nac_server_init(char *conf_name)
{
}

RootServer *rs_init(char* conffile)//rs参数赋值，打开bkdb，等待ns注册
{
   // zytypes_use_slab=0;
   // tawstd_init(0,NULL);
    RootServer *rs=taw_malloc("RootServer",sizeof(RootServer),0);

    if (conffile == NULL)
    {
        //using default configure file
        conffile = FL_DEFAULT_CONF_FILE;
    }
    config_t conf;
    config_init(&conf);
    char *ipc_file_path = strdup(RS_IPC_DEFAULT_FILE_PATH);
    if(config_read_file(&conf, conffile) == CONFIG_FALSE)
    {
        rs->bkdb_top_dir = strdup("/var/lib/flastore");
        rs->file_table = rs_bkdb_parse_conf(rs->bkdb_top_dir);
        rs->block_table = rs_bkdb_parse_conf(rs->bkdb_top_dir);
        rs->file_table->name = "file_table.db";
        rs->block_table->name = "blk_table.db";
        rs->block_len = 4*1024*1024; //DEBUG
        rs->replica_num = 1;  //DEBUG
        rs->conn_manager.addr=strdup("tcp://127.0.0.1:5000");
        rs->conn_manager.worker_thread_count = 20;
        rs->conn_manager.io_thread_count = 20;
        rs->ns_port = 5001;
        int index = FL_PROTOCOL_MAX;
        while(--index>=0){
            rs->del_interval[index] = 60; //DEBUG 60天
        }
    }
    else
    {
        const char *addr_ip = "127.0.0.1";
        if(config_lookup_string(&conf, "rs.addr_ip",&addr_ip) != CONFIG_TRUE)
        {
            fl_error_log("read configuration error : rs.addr_ip");
        }
        const char *addr_flag = "tcp";
        if(config_lookup_string(&conf, "rs.addr_flag",&addr_flag) != CONFIG_TRUE)
        {
            fl_error_log("read configuration error : rs.addr_flag");
        }
        int addr_port = 5000;
        if(config_lookup_int(&conf, "rs.addr_port",&addr_port) != CONFIG_TRUE)
        {
            fl_error_log("read configuration error : rs.addr_port");
        }
        char* addr= (char*)malloc(100);
        sprintf(addr,"%s://%s:%d",addr_flag, addr_ip, addr_port);
        rs->conn_manager.addr = addr;

        int ns_port = 5001;
        if(config_lookup_int(&conf, "ns.addr_port",&ns_port) != CONFIG_TRUE)
        {
            fl_error_log("read configuration error : ns.addr_port");
        }
        rs->ns_port = ns_port;

        const char *bkdb_top_dir = "/var/lib/flastore";
        if(config_lookup_string(&conf, "rs.bkdb_top_dir",&bkdb_top_dir) != CONFIG_TRUE)
        {
            fl_error_log("read configuration error : rs.bkdb_top_dir");
        }
        rs->bkdb_top_dir = strdup(bkdb_top_dir);

        rs->file_table = rs_bkdb_parse_conf(rs->bkdb_top_dir);
        rs->block_table = rs_bkdb_parse_conf(rs->bkdb_top_dir);

        const char *file_table_name = "file_table.db";
        if(config_lookup_string(&conf, "rs.file_table_name",&file_table_name) != CONFIG_TRUE)
        {
            fl_error_log("read configuration error : rs.file_table_name");
        }
        rs->file_table->name = strdup(file_table_name);

        const char *block_table_name = "blk_table.db";
        if(config_lookup_string(&conf, "rs.block_table_name",&block_table_name) != CONFIG_TRUE)
        {
            fl_error_log("read configuration error : rs.block_table_name");
        }
        rs->block_table->name = strdup(block_table_name);

        long long int block_len = 4*1024*1024L;
        if(config_lookup_int64(&conf, "rs.block_len",&block_len) != CONFIG_TRUE)
        {
            fl_error_log("read configuration error : rs.block_len");
        }
        rs->block_len = (uint64_t)block_len;

        int replica_num = 1;
        if(config_lookup_int(&conf, "rs.replica_num",&replica_num) != CONFIG_TRUE)
        {
            fl_error_log("read configuration error : rs.replica_num");
        }
        rs->replica_num = replica_num;

        int worker_thread_count = 20;
        if(config_lookup_int(&conf, "rs.worker_thread_count",&worker_thread_count) != CONFIG_TRUE)
        {
            fl_error_log("read configuration error : rs.worker_thread_count");
        }
        rs->conn_manager.worker_thread_count = worker_thread_count;

        int io_thread_count = 20;
        if(config_lookup_int(&conf, "rs.io_thread_count",&io_thread_count) != CONFIG_TRUE)
        {
            fl_error_log("read configuration error : rs.io_thread_count");
        }
        rs->conn_manager.io_thread_count = io_thread_count;

        const char *ipc_path = RS_IPC_DEFAULT_FILE_PATH;
        if(config_lookup_string(&conf, "rs.ipc_file_path",&ipc_path) != CONFIG_TRUE)
        {
            fl_error_log("read configuration error : rs.ipc_file_path");
        }
        ipc_file_path = strdup(ipc_path);

        int  http_get_delete_days = 60;
        if(config_lookup_int(&conf, "http_get_delete_days",&http_get_delete_days) != CONFIG_TRUE)
        {
            fl_error_log("read configuration error : http_get_delete_days");
        }
        rs->del_interval[0] = http_get_delete_days;

        int  http_post_delete_days = 60;
        if(config_lookup_int(&conf, "http_post_delete_days",&http_post_delete_days) != CONFIG_TRUE)
        {
            fl_error_log("read configuration error : http_post_delete_days");
        }
        rs->del_interval[1] = http_post_delete_days;

        int  smtp_delete_days = 60;
        if(config_lookup_int(&conf, "smtp_delete_days",&smtp_delete_days) != CONFIG_TRUE)
        {
            fl_error_log("read configuration error : smtp_delete_days");
        }
        rs->del_interval[2] = smtp_delete_days;

        int  pop3_delete_days = 60;
        if(config_lookup_int(&conf, "pop3_delete_days",&pop3_delete_days) != CONFIG_TRUE)
        {
            fl_error_log("read configuration error : pop3_delete_days");
        }
        rs->del_interval[3] = pop3_delete_days;

        int  ftp_delete_days = 60;
        if(config_lookup_int(&conf, "ftp_delete_days",&ftp_delete_days) != CONFIG_TRUE)
        {
            fl_error_log("read configuration error : ftp_delete_days");
        }
        rs->del_interval[4] = ftp_delete_days;

        int  pcap_delete_days = 60;
        if(config_lookup_int(&conf, "pcap_delete_days",&pcap_delete_days) != CONFIG_TRUE)
        {
            fl_error_log("read configuration error : pcap_delete_days");
        }
        rs->del_interval[5] = pcap_delete_days;

    }
    config_destroy(&conf);

    rs->conn_manager.comm=NULL;
    fl_debug_log("rs_init rs=%p,rs->file_table=%p,rs->block_table=%p",rs,rs->file_table,rs->block_table);
    rs->file_table->open_flag = DB_CREATE;//DB_RDONLY
    rs->block_table->open_flag = DB_CREATE;
    rs->file_table->write_flag = DB_AUTO_COMMIT;//DB_NOOVERWRITE
    rs->block_table->write_flag = DB_AUTO_COMMIT;

    pthread_mutex_init(&rs->mutex_x,NULL);
    //pthread_mutex_init(&rs->mutex_db,NULL);
    rs->ns_num = 0;   //DEBUG

    rs_init_ns_name_map(rs);
    rs_init_cache(rs);

    rs_bkdb_open_all(rs->file_table);
    rs_bkdb_open_all(rs->block_table);


    int pid = 15; //DEBUG  getpid();
    rs->context = zmq_init(1);
    char addr[100] = "";
    memset(addr, 0, 100);
    snprintf(addr, 100, "ipc://%s/root_server%d%s", ipc_file_path, pid, ".ipc");
    free(ipc_file_path);
    fl_debug_log("zmq publish addr=%s",addr);
    rs->publisher = zmq_socket(rs->context,ZMQ_PUSH);
    zmq_bind(rs->publisher, addr);

    time_t timep = time(0);
    struct tm *p = gmtime(&timep);
    rs->dayofmonth = p->tm_mday;

    rs->table_ok = 1;
    rs->started = 1;
    rs->safe_mode = 0;
    //DEBUG 测试block表的读写。模拟一个文件che，有两个block，每个block有3个副本。
/*
    ZYList * block_info= zylist();
    uint64_t block_offset = 1;
    uint32_t ns_id = 1;
    char* file_path = rs->data_top_dir;
    uint64_t file_offset = 1000000;
    uint64_t length = rs->block_len;
    zylist_append_int32(block_info,ns_id);
    zylist_append_str(block_info,file_path);
    zylist_append_int64(block_info,file_offset);
    zylist_append_int64(block_info,length);

    ZYList * block_info1= zylist();
    zylist_append_int32(block_info1,2);
    zylist_append_str(block_info1,file_path);
    zylist_append_int64(block_info1,file_offset+length);
    zylist_append_int64(block_info1,length);
    fl_debug_log("write block info  ns_id=%d,file_path=%s,file_offset=%lld,length=%lld",
                 ns_id,file_path,file_offset,length);

    write_block_table(rs,"che",block_offset,block_info);
    write_block_table(rs,"che",block_offset,block_info1);

    write_block_table(rs,"che",block_offset+rs->block_len,block_info);
    write_block_table(rs,"che",block_offset+rs->block_len,block_info1);

    zylist_append_str(rs->node_server_list,"192.168.79.21");
    zylist_append_str(rs->node_server_list,"192.168.79.22");
    zylist_append_str(rs->node_server_list,"192.168.79.23");
    zylist_append_str(rs->node_server_list,"192.168.79.24");
    zylist_append_str(rs->node_server_list,"192.168.79.25");
    */
    return rs;
}

int rs_close(RootServer *rs)
{
    fl_debug_log("rs_close...");
    //写ns_map到文件
    rs->started = 0;
    tscache_free(rs->cache); //出错。double free
    zmq_close(rs->publisher);
    zmq_term(rs->context);

    zylist_free(rs->node_server_list);
    zymap_free(rs->ns_name_map);

    rs_bkdb_close_all(rs->file_table);
    rs_bkdb_close_all(rs->block_table);
    rs_bkdb_free(rs->file_table);
    rs_bkdb_free(rs->block_table);

    free(rs->conn_manager.addr);
    free(rs->bkdb_top_dir);
    taw_free(rs);
    return FL_OK;

}

int rs_run(RootServer *rs)
{
    if ((rs->conn_manager.comm = ac_acio_create(rs->conn_manager.comm,  rs->conn_manager.io_thread_count))==NULL) {
        fl_error_log("ac_io_init error.\n");
        return FL_ERROR;
    }

    memset(&rs->conn_manager.handler, 0, sizeof(rs->conn_manager.handler));
    rs->conn_manager.handler.decode = comm_decode;
    rs->conn_manager.handler.encode = comm_encode;
    rs->conn_manager.handler.user_data = (void *)rs;
    //rs->conn_manager.handler.on_connect = comm_connect;

    rs->conn_manager.handler.process = rs_handle;//主要数据处理函数

    if(rs->conn_manager.worker_thread_count){
        rs->conn_manager.threads = ac_work_thread_pool_create(rs->conn_manager.comm,
                                            rs->conn_manager.worker_thread_count,
                                           rs_worker_handle, NULL);
    }


    if ((ac_listen(rs->conn_manager.comm, rs->conn_manager.addr, &rs->conn_manager.handler)) == NULL) {
        fl_error_log("ac_io_add_listen error, addr: %s, %s\n",
                       rs->conn_manager.addr, strerror(errno));
        return FL_ERROR;
    } else {
        fl_error_log("listen start, addr = %s\n", rs->conn_manager.addr);
    }

    // 起线程并开始
    if (ac_acio_start(rs->conn_manager.comm)) {
        fl_error_log("ac_io_start error.\n");
        return FL_ERROR;
    }

    uv_loop_t *loop=uv_loop_new();
    rs->timer_req.data = rs;
    uv_timer_init(loop, &rs->timer_req);
    uv_timer_start(&rs->timer_req,rs_time_handler,60000,RS_TIMER_INTERVEL);//定时任务
    uv_run(loop, UV_RUN_DEFAULT);

    // 等待线程退出
    ac_acio_wait(rs->conn_manager.comm);
    ac_acio_destroy(rs->conn_manager.comm);
    return FL_OK;
}

void rs_cache_free_cb(void* data)
{
    fl_debug_log("rs_cache_free_cb");
    MetaInfo *meta = (MetaInfo*)data;
    free(meta->file_info.file_name);
    free(meta->file_info.owner);

    zymap_free(meta->block_info);
    taw_free(meta);
}

//md5 = fc5e038d 38a57032 085441e7 fe7010b0
//file_id = fe0838fc
unsigned char* file_name_to_id(const char *name)
{
     unsigned char *md5;
    // uint32_t i, file_id=0;
     md5 = MD5(name,strlen(name),NULL);
    // for(i=0;i<16;i+=4)
     //   file_id += (md5[i]<<(i/4));
    // fl_debug_log("file_name_to_id name=%s, file_id=%d",name,file_id);
     //return file_id;
     return md5;
}


FileInfo *read_file_table(RootServer *rs, DB* dbp, const char *name, uint32_t protocol_flag, FileInfo *file_info){


      if(!file_info)
          return NULL;

      FileInfo* file_info_tmp;
      if((file_info_tmp = read_file_cache(rs,name,protocol_flag,file_info))!=NULL)
          return file_info_tmp;

       fl_debug_log("read_file_table name=%s ",name);

      int dump_size;
      if(protocol_flag>=FL_PROTOCOL_MAX){
          fl_debug_log("read_file_table ERROR protocol_flag=%d",protocol_flag);
          return NULL;
      }

      // pthread_mutex_lock(&rs->mutex_db);
    //  unsigned char* file_id = file_name_to_id(name);
      void * dump = rs_bkdb_get_data(dbp, name, &dump_size);
      // pthread_mutex_unlock(&rs->mutex_db);

      fl_debug_log("read_file_table dump=%p",dump);

      if(!dump){
          return NULL;
      }


      ZYList* file_info_list = zyload_zylist_ptr(dump,dump_size);

      if(!file_info_list)
          return NULL;

      file_info->file_name = (char*)name;
      file_info->create_time = zylist_get_int64(file_info_list,0);
      file_info->close_time = zylist_get_int64(file_info_list,1);
      file_info->owner = strdup(zylist_get_str(file_info_list,2));
      file_info->size = zylist_get_int64(file_info_list,3);
      const ZYBuffer *buf =  zylist_get_zybuffer(file_info_list,4);
      memcpy(&(file_info->md5ctx),buf->data,sizeof(md5_t));
      const char *md5 =  zylist_get_str(file_info_list,5);
      memcpy(file_info->md5,md5,16);
      //zybuffer_free(buf);

      fl_debug_log("read_file_table create_time=%lld,close_time=%lld,owner=%s",file_info->create_time,file_info->close_time,file_info->owner);

      zylist_free(file_info_list);


      return file_info;
}


FileInfo *read_file_cache(RootServer *rs, const char *name, uint32_t protocol_flag, FileInfo *file_info){

      fl_debug_log("read_file_cache name=%s",name);
      if(!rs->cache || !file_info)//  || !rs_is_today_file(name))
          return NULL;

      if(protocol_flag>=FL_PROTOCOL_MAX){
          fl_debug_log("read_file_cache ERROR protocol_flag=%d",protocol_flag);
          return NULL;
      }

      char cache_key[100];
      get_file_key(rs,cache_key,protocol_flag,name);
      pthread_mutex_lock(&rs->mutex_x);
      MetaInfo *meta = (MetaInfo *)tscache_get(rs->cache,cache_key,strlen(cache_key));

      if(!meta){
          pthread_mutex_unlock(&rs->mutex_x);
          return NULL;
      }


      file_info->file_name = (char*)name;
      file_info->create_time = meta->file_info.create_time;
      file_info->close_time = meta->file_info.close_time;
      file_info->owner = strdup(meta->file_info.owner);
      file_info->size = meta->file_info.size;
      memcpy(&(file_info->md5ctx),&(meta->file_info.md5ctx),sizeof(md5_t));
      memcpy(file_info->md5,meta->file_info.md5,16);

      fl_debug_log("read_file_cache create_time=%lld,owner=%s",file_info->create_time,file_info->owner);
      pthread_mutex_unlock(&rs->mutex_x);
      return file_info;
}

ZYMap *read_block_map_cache(RootServer *rs, const char *name, uint32_t protocol_flag){

      fl_debug_log("read_block_map_cache name=%s",name);
      if(!rs->cache)//  || !rs_is_today_file(name))
         return NULL;


      if(protocol_flag>=FL_PROTOCOL_MAX){
        fl_debug_log("read_block_map_cache ERROR protocol_flag=%d",protocol_flag);
        return NULL;
      }

      char cache_key[100];
      get_file_key(rs,cache_key,protocol_flag,name);
      pthread_mutex_lock(&rs->mutex_x);
      MetaInfo *meta = (MetaInfo *)tscache_get(rs->cache,cache_key,strlen(cache_key));
      pthread_mutex_unlock(&rs->mutex_x);
      if(!meta)
          return NULL;

      return meta->block_info;//一个个取出来插入新的map，很耗速度。
}

ZYMap *read_block_map(RootServer *rs, DB* dbp, const char *name, uint32_t protocol_flag, int* should_free)
{
      ZYMap* block_map=NULL;
      *should_free=0;
      if((block_map = read_block_map_cache(rs,name,protocol_flag))!=NULL)
          return block_map;

      fl_debug_log("read_block_map rs=%p,rs->block_table=%p",rs,rs->block_table);


      if(!dbp)
            return NULL;

      int dump_size;
      if(protocol_flag>=FL_PROTOCOL_MAX){
        fl_debug_log("read_block_map ERROR protocol_flag=%d",protocol_flag);
        return NULL;
      }

      void * dump = rs_bkdb_get_data(dbp,name,&dump_size);

      if(!dump){

        return NULL;
      }

      block_map = zyload_zymap_ptr(dump,dump_size);

      fl_debug_log("read_block_map map=%p dump=%p,dump_size=%d",block_map,dump,dump_size);


      *should_free=1;

      return block_map;
}

//写数据时的性能瓶颈
ZYMap *read_block_map_dbonly(RootServer *rs, DB* dbp, const char *name, uint32_t protocol_flag)
{
      ZYMap* block_map=NULL;

      if(!dbp)
            return NULL;

      int dump_size;
      if(protocol_flag>=FL_PROTOCOL_MAX){
        fl_debug_log("read_block_map ERROR protocol_flag=%d",protocol_flag);
        return NULL;
      }

      void * dump = rs_bkdb_get_data(dbp,name,&dump_size);

      if(!dump){
        return NULL;
      }

      fl_debug_log("read_block_map dump=%p,dump_size=%d",dump,dump_size);
      block_map = zyload_zymap_ptr(dump,dump_size);

      fl_debug_log("read_block_map map=%p dump=%p,dump_size=%d",block_map,dump,dump_size);

      return block_map;
}

//key是file_id，data是ZYList，链表中挨个文件信息。{create_time,close_time,owner,}
int write_file_table(RootServer *rs, DB* dbp, FileInfo *file_info, uint32_t protocol_flag, int write_cache){
    void *dump;
    if(protocol_flag>=FL_PROTOCOL_MAX){
        fl_debug_log("write_file_table ERROR protocol_flag=%d",protocol_flag);
        return FL_ERROR;
    }
    if(write_cache)
        write_file_cache(rs, file_info, protocol_flag);

    int  ret, dump_size=0;

    if(!dbp)
            return FL_ERROR;
    fl_debug_log("write_file_table name=%s create_time=%lld,close_time=%lld,owner=%s,protocol_flag=%d",
                 file_info->file_name,file_info->create_time,file_info->close_time,file_info->owner,protocol_flag);


    ZYList* file_info_list = zylist();

    zylist_append_int64(file_info_list,file_info->create_time);
    zylist_append_int64(file_info_list,file_info->close_time);
    zylist_append_str(file_info_list,file_info->owner);
    zylist_append_int64(file_info_list,file_info->size);

    ZYBuffer* zybuf = zybuffer_new(&(file_info->md5ctx),sizeof(md5_t),0,ZYBUFFER_DEFAULT_FLAG);
    zylist_append_zybuffer(file_info_list,zybuf);

    zylist_append_str(file_info_list,file_info->md5);


    dump = zylist_dump_ptr(file_info_list, &dump_size);

    //pthread_mutex_lock(&rs->mutex_x);
    //unsigned char* file_id = file_name_to_id(file_info->file_name);
    ret = rs_bkdb_put_data(dbp,file_info->file_name,dump,dump_size,rs->file_table->write_flag);//dump在里面析构
    //pthread_mutex_unlock(&rs->mutex_x);

    zylist_free(file_info_list);
    fl_debug_log("write_file_table OVER %d",protocol_flag);
    return ret;
}


int write_file_cache(RootServer *rs, FileInfo *file_info, uint32_t protocol_flag)
{
      fl_debug_log("write_file_cache name=%s",file_info->file_name);

      if(!rs->cache )//|| !rs_is_today_file(file_info->file_name))
         return FL_ERROR;

      char cache_key[100];
      get_file_key(rs,cache_key,protocol_flag,file_info->file_name);

      if(protocol_flag>=FL_PROTOCOL_MAX){
          fl_debug_log("write_file_cache ERROR protocol_flag=%d",protocol_flag);
          return FL_ERROR;
      }
      pthread_mutex_lock(&rs->mutex_x);
      MetaInfo *meta = (MetaInfo *)tscache_get(rs->cache,cache_key,strlen(cache_key));
      int need_put=0;

      if(!meta){
            meta =  (MetaInfo *)taw_malloc("MetaInfo", sizeof(MetaInfo), 0);
            if(!meta){
                pthread_mutex_unlock(&rs->mutex_x);
                return FL_ERROR;
            }

             meta->block_info = zymap();
             need_put=1;
      }

      meta->file_info.file_name = strdup(file_info->file_name);//
      meta->file_info.create_time = file_info->create_time;
      meta->file_info.close_time = file_info->close_time;
      meta->file_info.owner = strdup(file_info->owner);//
      meta->file_info.size = file_info->size;
      memcpy(&(meta->file_info.md5ctx), &(file_info->md5ctx),sizeof(md5_t));
      memcpy(meta->file_info.md5, file_info->md5, 16);
      fl_debug_log("tscache_put_data name=%s,owner=%s", meta->file_info.file_name,meta->file_info.owner);

      if(need_put)
          tscache_put_data(rs->cache,cache_key,strlen(cache_key),(void*)meta);
      pthread_mutex_unlock(&rs->mutex_x);

      return FL_OK;
}

int write_block_cache(RootServer *rs, const char* name, uint32_t protocol_flag, ZYMap* block_info_map)
{
      fl_debug_log("write_block_cache name=%s",name);
      if(!rs->cache)// || !rs_is_today_file(name))
         return FL_ERROR;

      char cache_key[100];
      get_file_key(rs,cache_key,protocol_flag,name);

      if(protocol_flag>=FL_PROTOCOL_MAX){
          fl_debug_log("write_block_cache ERROR protocol_flag=%d",protocol_flag);
          return FL_ERROR;
      }

      int need_put=0;
      pthread_mutex_lock(&rs->mutex_x);
      MetaInfo *meta = (MetaInfo *)tscache_get(rs->cache,cache_key,strlen(cache_key));

      if(!meta){
            meta =  (MetaInfo *)taw_malloc("MetaInfo", sizeof(MetaInfo), 0);
            if(!meta){
                 pthread_mutex_unlock(&rs->mutex_x);
                 return FL_ERROR;
            }

            need_put=1;

      }
      zymap_free(meta->block_info);

      meta->block_info = zymap_clone(block_info_map);

      if(need_put)
          tscache_put_data(rs->cache,cache_key,strlen(cache_key),(void*)meta);
      pthread_mutex_unlock(&rs->mutex_x);
      return FL_OK;
}

int rs_init_ns_name_map(RootServer *rs){

    if(load_sys_log(rs)==FL_ERROR){
        rs->ns_name_map = zymap();
        rs->node_server_list = zylist();
    }
}

/**遍历所有日期所有协议的db，检查元数据与NS报告元数据一致性(未开发)。
   同时将未关闭的元数据写入cache*/
int rs_init_cache(RootServer *rs){

    rs->cache = tscache_new(10000,0,0,rs_cache_free_cb);//只缓存打开文件的元数据，最好还有个上限控制

    if(!rs->file_table || !rs->block_table)
        return FL_ERROR;

    uint32_t index=0;
    int ret = 0;

    char dbname_file[50];
    char dbname_block[50];
    char subdir[100];//建目录
    char datastr[9];
    time_t time_now = time(0);
    DB* dbp_file,*dbp_block;
    while(index <FL_PROTOCOL_MAX) //循环每种协议
    {
        int i;
        for(i=0;i<rs->del_interval[index];i++){ //循环每个日期

            time_t last_time = time_now - i*86400;
            get_date_dir_by_time(datastr, last_time);
            sprintf(subdir, "%s/%s/%s", rs->file_table->top_dir,protocol_flag_to_str(index),datastr);

            DIR * dir = opendir(subdir);
            if(dir==NULL)
            {
                fl_debug_log("rs_init_cache %s not exist.",subdir);
                continue;
            }

            sprintf(dbname_file, "%s/%s/%s", protocol_flag_to_str(index), datastr, rs->file_table->name);
            sprintf(dbname_block, "%s/%s/%s", protocol_flag_to_str(index), datastr, rs->block_table->name);

            fl_debug_log("rs_bkdb_open %s %s\n", dbname_file, dbname_block);

            ret = db_create(&dbp_file, rs->file_table->db_env, 0);
            if(ret != 0)
            {
                fl_error_log("Create dbp failed\n",db_strerror(ret));
                continue;
            }
            ret = dbp_file->open(dbp_file, NULL, dbname_file, NULL, DB_BTREE, rs->file_table->open_flag, 0);
            if(ret !=0)
            {
                fl_error_log("Open db %s failed,%s\n",dbname_file,db_strerror(ret));
                continue;
            }
            ret = db_create(&dbp_block, rs->block_table->db_env, 0);
            if(ret != 0)
            {
                fl_error_log("Create dbp failed\n",db_strerror(ret));
                continue;
            }
            ret = dbp_block->open(dbp_block, NULL, dbname_block, NULL, DB_BTREE, rs->block_table->open_flag, 0);
            if(ret !=0)
            {
                fl_error_log("Open db %s failed,%s\n",dbname_block,db_strerror(ret));
                continue;
            }

            DBC *dbc;
            DBT key,data;
            memset(&key,0,sizeof(DBT));
            memset(&data,0,sizeof(DBT));
            dbp_file->cursor(dbp_file, NULL, &dbc, 0);
            //使用游标遍历数据库
            for (ret = dbc->get(dbc, &key, &data, DB_FIRST); ret == 0; ret = dbc->get(dbc, &key, &data, DB_NEXT)) {

                  ZYList* file_info_list = zyload_zylist_ptr(data.data,data.size);

                  if(!file_info_list)
                      continue;
                  uint64_t close_time = zylist_get_int64(file_info_list,1);

                  if(close_time == 0){//文件未关闭，需要读到cache中。

                      MetaInfo * meta =  (MetaInfo *)taw_malloc("MetaInfo", sizeof(MetaInfo), 0);
                      if(!meta){
                          return FL_ERROR;
                      }
                      char file_name[100];
                      memcpy(file_name,key.data,key.size);
                      file_name[key.size]=0;
                      meta->file_info.file_name = strdup(file_name);
                      meta->file_info.create_time = zylist_get_int64(file_info_list,0);
                      meta->file_info.close_time = close_time;
                      meta->file_info.owner = strdup(zylist_get_str(file_info_list,2));
                      meta->file_info.size =  zylist_get_int64(file_info_list,3);

                      fl_debug_log("rs_init_cache FILE_INFO: name=%s,owner=%s,size=%lld", file_name,meta->file_info.owner, meta->file_info.size);

                      int dump_size=0;
                      void *dump = rs_bkdb_get_data(dbp_block,file_name,&dump_size);
                      if(!dump){
                        continue;
                      }
                      meta->block_info = zyload_zymap_ptr(dump,dump_size);

                      {//DEBUG 输出看block info是否正确
                        ZYElem* melement = NULL;
                        void* key_m = NULL;
                        int key_len = 0;
                        ZYMAP_FOR_EACH(meta->block_info,key_m,key_len,melement)
                        {
                            ZYList* block_info = zyelem_get_zylist(melement,NULL);
                            uint32_t ns_id = zylist_get_int32(block_info,0);
                            const char* file_path = zylist_get_str(block_info,1);
                            uint64_t file_offset = zylist_get_int64(block_info,2);
                            uint64_t length = zylist_get_int64(block_info,3);

                            fl_debug_log("rs_init_cache BLOCK_INFO ns_id=%d,file_path=%s,file_offset=%lld,length=%lld",
                                     ns_id,file_path,file_offset,length);
                        }
                      }


                      char cache_key[100];
                      get_file_key(rs,cache_key,index,file_name);
                      fl_debug_log("rs_init_cache cache_key=%s",cache_key);

                      tscache_put_data(rs->cache,cache_key,strlen(cache_key),(void*)meta);//存入Cache


                 }
                 zylist_free(file_info_list);


            }//for db
            if (dbc != NULL)
                dbc->close(dbc);
            if (dbp_file != NULL)
                dbp_file->close(dbp_file,0);
            if (dbp_block != NULL)
                dbp_block->close(dbp_block,0);



        }//for 日期


        index++;
    }//while 协议


}


//从NS名字获取NS id
uint32_t ns_name_to_id(RootServer *rs, const char *name){
    //找rs->ns_name_map
    if(!name){
        fl_error_log("ns_name_to_id error name ");
        return 0;
    }
    return zymap_get_int32(rs->ns_name_map, _K(name), NULL);
}

//从NSid获取NS 名字
const char* ns_id_to_name(RootServer *rs, uint32_t id){
    //找rs->node_server_list
    if(id<=0 || id>rs->ns_num){
        fl_error_log("ns_id_to_name error id %d",id);
        return NULL;
    }

    const char* name = zylist_get_str(rs->node_server_list,id-1);
    return name;
}

//随机rs->replica_num个ns
//多NS需要修改，ns_num中不一定都可用。
ZYList* get_random_ns_locations(RootServer *rs)
{
   // fl_debug_log("get_random_ns_locations");
    if(rs->ns_num<=0){
        fl_error_log("there are no node servers.");
        return NULL;
    }

    uint32_t *ns_id_array;
    uint32_t i,j,tmp_id;

    ns_id_array = (uint32_t *)taw_malloc("uint32_t",sizeof(uint32_t)*rs->replica_num,0);
    if(!ns_id_array)
    {
        fl_error_log("get_random_ns_locations taw_malloc error");
        return NULL;
    }

    srand(time(0));
    for(i=0; i<rs->replica_num; i++){
        tmp_id = rand()%(rs->ns_num)+1;
        for(j=0;j<i;j++){
            while(tmp_id==ns_id_array[j])
                tmp_id = rand()%(rs->ns_num)+1;
        }
        ns_id_array[i] = tmp_id;
    }


    ZYList* ns_list = zylist();
    for(i=0; i<rs->replica_num; i++){
        fl_debug_log("locale_create_file %d=%d ",i,ns_id_array[i]);
        const char *ns_name = ns_id_to_name(rs, ns_id_array[i]);
        zylist_append_str(ns_list,ns_name);
    }

    taw_free(ns_id_array);
    return  ns_list;

}

uint32_t offset_to_block_id(RootServer *rs, uint64_t offset){
    return offset/rs->block_len + 1;
}


ZYList *read_block_table(RootServer *rs, DB* dbp, const char* name, uint64_t offset,ZYMap **block_map, uint32_t protocol_flag, int* should_free)
{

    int ret;
    char blk_id[12];

    sprintf(blk_id,"%d",offset_to_block_id(rs, offset));
    fl_debug_log("read_block_table name=%s,blk_id=%s",name,blk_id);

    *block_map = read_block_map(rs, dbp, name, protocol_flag, should_free);

    if(!(*block_map))
        return NULL;

    ZYList *block_info = zymap_get_zylist(*block_map, _K(blk_id));
    if(block_info==NULL){
         fl_debug_log("block_info = NULL. read_block_map_dbonly");
         if(*should_free)
            zymap_free(*block_map);

         *should_free=1;
         *block_map = read_block_map_dbonly(rs,dbp, name, protocol_flag);
         block_info = zymap_get_zylist(*block_map, _K(blk_id));
    }


    return block_info;
}

//替换掉Cache中的zymap中的block_info
int write_block_list_cache_r(RootServer *rs, const char* name, uint64_t offset, ZYList *block_info, uint32_t protocol_flag)
{
      fl_debug_log("write_block_list_cache_r name=%s",name);

      if(!rs->cache) // || !rs_is_today_file(name))
         return FL_ERROR;

      char cache_key[100];
      get_file_key(rs,cache_key,protocol_flag,name);

      if(protocol_flag>=FL_PROTOCOL_MAX){
          fl_debug_log("write_block_list_cache_r ERROR protocol_flag=%d",protocol_flag);
          return FL_ERROR;
      }
      int need_put=0;
      pthread_mutex_lock(&rs->mutex_x);
      MetaInfo *meta = (MetaInfo *)tscache_get(rs->cache,cache_key,strlen(cache_key));

      if(!meta){
            meta =  (MetaInfo *)taw_malloc("MetaInfo", sizeof(MetaInfo), 0);
            if(!meta){
                pthread_mutex_unlock(&rs->mutex_x);
                return FL_ERROR;
            }

             meta->block_info = zymap();
             need_put=1;
      }


      char blk_id[12];
      sprintf(blk_id,"%d",offset_to_block_id(rs, offset));

      zymap_put_zylist(meta->block_info, _K(blk_id), block_info);

      if(need_put)
          tscache_put_data(rs->cache,cache_key,strlen(cache_key),(void*)meta);
      pthread_mutex_unlock(&rs->mutex_x);

      return FL_OK;
}

char* get_file_key(RootServer *rs, char* cache_key, uint32_t flag, const char* name)
{
     // pthread_mutex_lock(&rs->mutex_x);
      //unsigned char* file_id = file_name_to_id(name);
      sprintf(cache_key,"%s%d",name,flag);

    //  memcpy(cache_key+16,&flag,4);
     // cache_key[20]=0;

}
//追加Cache中的zymap中的block_info
int write_block_list_cache(RootServer *rs, const char* name, uint64_t offset, ZYList *block_info, uint32_t protocol_flag)
{
      fl_debug_log("write_block_list_cache name=%s",name);

      if(!rs->cache )//|| !rs_is_today_file(name))
         return FL_ERROR;

      char cache_key[100];
      get_file_key(rs,cache_key,protocol_flag,name);

      if(protocol_flag>=FL_PROTOCOL_MAX){
          fl_debug_log("write_block_list_cache ERROR protocol_flag=%d",protocol_flag);
          return FL_ERROR;
      }

      int need_put=0;
      pthread_mutex_lock(&rs->mutex_x);
      MetaInfo *meta = (MetaInfo *)tscache_get(rs->cache,cache_key,strlen(cache_key));

      if(!meta){
            meta =  (MetaInfo *)taw_malloc("MetaInfo", sizeof(MetaInfo), 0);
            if(!meta){
                pthread_mutex_unlock(&rs->mutex_x);
                return FL_ERROR;
            }

            meta->block_info = zymap();
            need_put=1;
      }

      char blk_id[12];
      sprintf(blk_id,"%d",offset_to_block_id(rs, offset));

      ZYList *block_info_old = zymap_get_zylist(meta->block_info, _K(blk_id));

      ZYList *block_info_new = zylist_clone(block_info_old);
      block_info_new = zylist_merge(block_info_new,block_info);

      zymap_put_zylist(meta->block_info, _K(blk_id), block_info_new);


      if(need_put)
          tscache_put_data(rs->cache,cache_key,strlen(cache_key),(void*)meta);
      pthread_mutex_unlock(&rs->mutex_x);

      return FL_OK;
}
//如果文件id对应的block_map不存在，那么put一条文件信息。
//如果存在，那么修改对应block_map, map中对应的blk_id对应的block_info.
//file_id1 <.....> block_map
//                 blk_id 1 <.....>block_info (nsid1,nsfile_path1,file_offset1,length1),(nsid2...),()
//                 blk_id 2 <.....>block_info (nsid1,nsfile_path1,file_offset1,length1),(nsid2...),()
//file_id2 <.....> block_map
//追加
int write_block_table(RootServer *rs, DB* dbp, const char* name, uint64_t offset, ZYList *block_info, uint32_t protocol_flag){

    if(protocol_flag>=FL_PROTOCOL_MAX){
        fl_debug_log("write_block_table ERROR protocol_flag=%d",protocol_flag);
        return FL_ERROR;
    }

   // write_block_list_cache(rs,name,offset,block_info,protocol_flag);

    int ret,dump_size;
    char blk_id[12];
    ZYMap *block_map;
    void *dump;

    if(!dbp)
            return FL_ERROR;
    sprintf(blk_id,"%d",offset_to_block_id(rs, offset));

    int should_free;
    block_map = read_block_map(rs, dbp, name, protocol_flag, &should_free);
    if(!block_map){
        block_map = zymap();
        fl_debug_log("block_map null ,NEW block_map =%p",block_map);
    }

    fl_debug_log("write_block_table file name =%s,blk_id=%s",name,blk_id);

    ZYList *block_info_old = zymap_get_zylist(block_map, _K(blk_id));

    ZYList *block_info_new = zylist_clone(block_info_old);
    block_info_new = zylist_merge(block_info_new,block_info);

    zymap_put_zylist(block_map, _K(blk_id), block_info_new);

    dump = zymap_dump_ptr(block_map, &dump_size);

   // pthread_mutex_lock(&rs->mutex_x);
   // unsigned char *file_id = file_name_to_id(name);
    ret = rs_bkdb_put_data(dbp,name,dump,dump_size,rs->block_table->write_flag);
   // pthread_mutex_unlock(&rs->mutex_x);

    if(should_free)
        zymap_free(block_map);

    zylist_free(block_info);
    zylist_free(block_info_new);

    return ret;
}

//替换掉同一个NS报告的同一个block的block_info
int write_block_table_r(RootServer *rs, DB* dbp, const char* name, uint64_t offset, ZYList *block_info, uint32_t protocol_flag){

    if(protocol_flag>=FL_PROTOCOL_MAX){
        fl_debug_log("write_block_table_r ERROR protocol_flag=%d",protocol_flag);
        return FL_ERROR;
    }
    if(!dbp){
        return FL_ERROR;
    }
   // write_block_list_cache_r(rs,name,offset,block_info,protocol_flag);

    int ret,dump_size;
    char blk_id[12];
    ZYMap *block_map;
    void *dump;


    sprintf(blk_id,"%d",offset_to_block_id(rs, offset));

    int should_free=0;
    block_map = read_block_map(rs, dbp, name, protocol_flag, &should_free);


    if(!block_map){
        block_map = zymap();
        fl_debug_log("block_map null ,NEW block_map =%p",block_map);
    }

    fl_debug_log("write_block_table file name =%s,blk_id=%s",name,blk_id);

    zymap_put_zylist(block_map, _K(blk_id), block_info);

    dump = zymap_dump_ptr(block_map, &dump_size);

    fl_debug_log("write_block_table_r  over dump_size=%d",dump_size);

    ret = rs_bkdb_put_data(dbp,name,dump,dump_size,rs->block_table->write_flag);

    if(should_free)
        zymap_free(block_map);//释放会造成libac发送失败。

    return ret;
}

//查询file_table，如果没有该文件，写filetable。分配一个ns返回给client用于写block。
ZYList* locale_create_file(RootServer *rs, const char* name, const char* client_name, uint64_t block_len, uint32_t protocol_flag)
{
    fl_debug_log("locale_create_file %s",name);
    FileInfo file_info;
    FileInfo *file_info_p;
    uint64_t file_size=0;
    md5_t *md5ctx=NULL;

    DB* dbp = get_proper_db(rs, rs->file_table, name, protocol_flag);
    if(!dbp)
          return NULL;
    file_info_p = read_file_table(rs, dbp, name, protocol_flag,&file_info);
    if(!file_info_p){
        fl_debug_log("file not exist  %d",protocol_flag);
        file_info.file_name = (char*)name;
        file_info.owner = strdup(client_name);
        //file_info.owner = "127.0.0.1";
        file_info.create_time = time(0);
        file_info.close_time = 0;
        file_info.size = 0;
        md5_init(&file_info.md5ctx);
        md5ctx = &file_info.md5ctx;

        memset(file_info.md5,0,16);
        write_file_table(rs,dbp, &file_info, protocol_flag, 1);
        free(file_info.owner);

        //FileInfo *file_info_p2 = read_file_table(rs, name, protocol_flag);
        //fl_debug_log("locale_create_file read name=%s flag=%d ower=%s",name,protocol_flag,file_info_p2->owner);
        //free(file_info_p2->owner);
       // taw_free(file_info_p2);

    }
    else{
        fl_debug_log("file %s exist.create failed!",name);
        free(file_info_p->owner);

        if(file_info_p->close_time!=0)//文件已经关闭了， 不能再写
        {
             if(rs->file_table->dbp[protocol_flag]!=dbp)
                dbp->close(dbp,0);
             fl_error_log("file %s has been closed. can not write.",name);
             return NULL;
        }

        file_size = file_info_p->size;
        md5ctx = &file_info_p->md5ctx;

    }
    if(rs->file_table->dbp[protocol_flag]!=dbp)
        dbp->close(dbp,0);

     fl_debug_log("get_random_ns_locations %d",protocol_flag);
    ZYList* ns_list = get_random_ns_locations(rs);//返回多个ns


    if(ns_list)
    {
        zylist_append_int64(ns_list,file_size); //ZYList最后一个元素是size,size为0,表示文件不存在。

        ZYBuffer* zybuf = zybuffer_new(md5ctx,sizeof(md5_t),0,ZYBUFFER_DEFAULT_FLAG);
        zylist_append_zybuffer(ns_list,zybuf);
    }

    fl_debug_log("locale_create_file name = %s, block_len = %lld, flag=%d client_name=%s\n",name,block_len,protocol_flag,client_name);
    return ns_list;
}

ZYMap* locale_get_fileinfo(RootServer *rs, const char* name, uint32_t protocol_flag)
{
      fl_debug_log("locale_get_fileinfo name=%s protocol_flag=%d",name,protocol_flag);
     /* ZYList* file_blk_info = zylist();

      unsigned char* file_id = file_name_to_id(name);
      int dump_size;
      void * dump = rs_bkdb_get_data(rs->file_table,file_id,&dump_size);

      if(!dump)
          return NULL;

     ZYList* file_info_list = zyload_zylist_ptr(dump,dump_size);*/
      int should_free;
      DB* dbp = get_proper_db(rs, rs->block_table, name, protocol_flag);
      if(!dbp)
          return NULL;
      ZYMap * blk_map = read_block_map(rs, dbp ,name, protocol_flag,&should_free);
      fl_debug_log("locale_get_fileinfo blk_map=%p",blk_map);

      //zylist_append_zylist(file_blk_info,file_info_list);
      //zylist_append_zymap(file_blk_info,blk_map);
      if(rs->block_table->dbp[protocol_flag]!=dbp)
        dbp->close(dbp,0);

      return blk_map;
}

int locale_block_received(RootServer *rs,const char* name, uint64_t offset, uint32_t ns_id, uint32_t protocol_flag, void* context)
{

    FileInfo file_info;
    FileInfo *file_info_p;
    fl_debug_log("locale_block_received  name=%s ns_id=%d,offset=%lld,flag=%d",
                 name,ns_id,offset ,protocol_flag);
    DB* dbp = get_proper_db(rs, rs->file_table, name, protocol_flag);
    if(!dbp)
        return FL_ERROR;

    file_info_p = read_file_table(rs, dbp, name, protocol_flag,&file_info);

    if(file_info_p){

        fl_debug_log("locale_block_received name=%s create_time=%lld,owner=%s",file_info_p->file_name,file_info_p->create_time,file_info_p->owner);
        file_info_p->size = offset + rs->block_len;
        memcpy(&file_info_p->md5ctx,context,sizeof(md5_t));

        memcpy(file_info_p->md5,context+sizeof(md5_t),16);
        unsigned char* md = file_info_p->md5;
        //fl_debug_log("md5=%0X%0X%0X%0X%0X%0X%0X%0X%0X%0X%0X%0X%0X%0X%0X%0X",md[0],md[1],md[2],md[3],md[4],md[5],md[6],md[7],md[8],md[9],md[10],md[11],md[12],md[13],md[14],md[15]);

        write_file_table(rs, dbp, file_info_p, protocol_flag, 1);
        free(file_info_p->owner);
    }
    if(rs->file_table->dbp[protocol_flag]!=dbp)
        dbp->close(dbp,0);

    ZYList * block_info = zylist();

    char* file_path = "";
    uint64_t file_offset = 0;
    uint64_t length = 0;

    zylist_append_int32(block_info,ns_id);
    zylist_append_str(block_info,file_path);
    zylist_append_int64(block_info,file_offset);
    zylist_append_int64(block_info,length);

    //block_receive的元数据只写入cache，因为ns也还没写入磁盘。等report时写入db。这样为了提高写数据的性能
    int ret = write_block_list_cache_r(rs,name,offset,block_info,protocol_flag);
    /*
    DB* dbp_b = get_proper_db(rs, rs->block_table, name, protocol_flag);
    if(!dbp_b)
        return FL_ERROR;

    int ret = write_block_table_r(rs,dbp_b,name,offset,block_info,protocol_flag);
    if(rs->block_table->dbp[protocol_flag]!=dbp_b)
        dbp_b->close(dbp_b,0);
    */

    zylist_free(block_info);

    return ret;

}

//文件名，offset，NSid，NS文件路径，NS文件offset，长度。
int locale_block_report(RootServer *rs, const char* name, uint64_t offset, ZYList *block_info, uint32_t protocol_flag)
{

    uint32_t ns_id = zylist_get_int32(block_info,0);
    const char* file_path = zylist_get_str(block_info,1);
    uint64_t file_offset = zylist_get_int64(block_info,2);
    uint64_t length = zylist_get_int64(block_info,3);
    fl_debug_log("locale_block_report name=%s ns_id=%d,offset=%lld,file_path=%s,file_offset=%lld,length=%lld,,flag=%d",
                 name,ns_id,offset,file_path,file_offset,length ,protocol_flag);
    /* 这里再写size会错误，已经在block_receive中写过了
    FileInfo file_info;
    FileInfo *file_info_p;
    DB* dbp = get_proper_db(rs, rs->file_table, name, protocol_flag);
    if(!dbp)
        return FL_ERROR;
    file_info_p = read_file_table(rs,dbp, name, protocol_flag,&file_info);
    if(file_info_p){

        fl_debug_log("locale_block_received name=%s create_time=%lld,owner=%s",file_info_p->file_name,file_info_p->create_time,file_info_p->owner);
        file_info_p->size = offset+length;
        write_file_table(rs,dbp, file_info_p, protocol_flag, 1);
        free(file_info_p->owner);

    }
    if(rs->file_table->dbp[protocol_flag]!=dbp)
        dbp->close(dbp,0);
    */

    DB* dbp_b = get_proper_db(rs, rs->block_table, name, protocol_flag);
    if(!dbp_b)
        return FL_ERROR;

    write_block_list_cache_r(rs,name,offset,block_info,protocol_flag);
    int ret = write_block_table_r(rs,dbp_b,name,offset,block_info,protocol_flag);
    if(rs->block_table->dbp[protocol_flag]!=dbp_b)
        dbp_b->close(dbp_b,0);

    zylist_free(block_info);

    return ret;

}

//假设都是第一次启动，分配一个ns_id返回，加锁，存入每个ns的容量（负载均衡用），
int locale_ns_register(RootServer *rs, const char* location, uint64_t max_size, ZYList* block_info)
{
    fl_debug_log("locale_ns_register  location=%s max_size=%lld",
                 location,max_size);
    int ns_id = ns_name_to_id(rs,location);
    if(!ns_id)
    {
        pthread_mutex_lock(&rs->mutex_x);

        zylist_append_str(rs->node_server_list,location);
        zymap_put_int32(rs->ns_name_map, _K(location), rs->ns_num+1);
        rs->ns_num += 1;
        ns_id = rs->ns_num;

        pthread_mutex_unlock(&rs->mutex_x);
    }

    zylist_free(block_info);

    return ns_id;

}

void free_buff(void *data, void *hint)
{
    free(data);
}

//关闭文件，zmq发布消息通知外界文件写完。
int locale_close_file(RootServer *rs, const char* name, uint32_t protocol_flag)
{
    fl_debug_log("locale_close_file  name=%s protocol_flag=%d", name,protocol_flag);

    int rc = 0;

    FileInfo  file_info;
    FileInfo *file_info_p;
    DB* dbp = get_proper_db(rs, rs->file_table, name, protocol_flag);
    if(!dbp)
        return FL_ERROR;
    file_info_p = read_file_table(rs,dbp, name, protocol_flag, &file_info);

    if(file_info_p){
        if(file_info_p->close_time == 0){
            file_info_p->close_time = time(0);
            fl_debug_log("locale_close_file name=%s close_time=%lld,owner=%s",file_info_p->file_name,file_info_p->close_time,file_info_p->owner);
            write_file_table(rs,dbp, file_info_p, protocol_flag, 0);//只写bkdb,不写cache
            free(file_info_p->owner);

            char cache_key[100];
            get_file_key(rs,cache_key,protocol_flag,name);

            pthread_mutex_lock(&rs->mutex_x);
            MetaInfo *meta = (MetaInfo *)tscache_get(rs->cache,cache_key,strlen(cache_key));
            zymap_free(meta->block_info);
            free(meta->file_info.file_name);
            free(meta->file_info.owner);
            tscache_remove(rs->cache, (void*)cache_key, strlen(cache_key));//删除已经关闭的文件对应的缓存元数据
            pthread_mutex_unlock(&rs->mutex_x);

            char *data = malloc(100);//TODO:把file info一起发出去。
            sprintf(data,"close %s",name);
            int dsize=strlen(data);

            zmq_msg_t message;
            zmq_free_fn* ffn=free_buff;

            zmq_msg_init_data(&message, data, dsize, ffn, NULL);
            fl_debug_log("zmq_sendmsg  data=%s ", data);
            rc =  zmq_sendmsg(rs->publisher, &message, 0);
            zmq_msg_close(&message);
            fl_debug_log("zmq_sendmsg  rc=%d ", rc);
        }
        else{
            fl_error_log("locale_close_file ERROR, file %s flag %d has been closed.",name,protocol_flag);
            rc = 0;
        }
    }
    else
    {
        fl_error_log("locale_close_file ERROR, file %s flag %d do not exist.",name,protocol_flag);
        rc = 0;
    }
    if(rs->file_table->dbp[protocol_flag]!=dbp)
        dbp->close(dbp,0);

    return rc;
}

int locale_rename_file(RootServer *rs, const char* old_name, const char* new_name,uint32_t protocol_flag)
{
     fl_debug_log("locale_rename_file  old_name=%s new_name=%s protocol_flag=%d", old_name,new_name,protocol_flag);
     return 0;
}

//删除文件,随机删除文件暂不支持。
int locale_delete_file(RootServer *rs, const char* name, uint32_t protocol_flag)
{
    if(protocol_flag>=FL_PROTOCOL_MAX){
        fl_debug_log("locale_delete_file ERROR protocol_flag=%d",protocol_flag);
        return FL_ERROR;
    }
    //删除file_info
   // pthread_mutex_lock(&rs->mutex_x);
    //unsigned char* file_id = file_name_to_id(name);
    rs_bkdb_delete_data(rs->file_table->dbp[protocol_flag],name);
    //删除block_info

    rs_bkdb_delete_data(rs->block_table->dbp[protocol_flag],name);
   //获得block位置，通知ns删除文件

   //TODO 删除Cache
   // pthread_mutex_unlock(&rs->mutex_x);

}

int save_sys_log(RootServer *rs)
{
      //保存数据。最重要的是ns与nsid对应关系，重启时等待ns来注册
    DB* dbp=NULL;
    char *dbname="syslog.db";
    fl_debug_log("save_sys_log bkdb_open %s\n", dbname);
    int ret;
    if((ret = db_create(&dbp, rs->file_table->db_env, 0)) != 0)
    {
        fl_error_log("Create dbp failed\n",db_strerror(ret));
        return FL_ERROR;
    }

    if((ret = dbp->open(dbp, NULL, dbname, NULL, DB_BTREE, rs->file_table->open_flag, 0)) !=0)
    {
        fl_error_log("Open db %s failed,%s\n",dbname,db_strerror(ret));
        return FL_ERROR;
    }
    int dump_size=0;
    void *dump = zymap_dump_ptr(rs->ns_name_map, &dump_size);
    rs_bkdb_put_data(dbp, "ns_name_map", dump, dump_size, rs->file_table->write_flag);
    dump = zylist_dump_ptr(rs->node_server_list, &dump_size);
    rs_bkdb_put_data(dbp, "node_server_list", dump, dump_size, rs->file_table->write_flag);
    dbp->close(dbp,0);

    return FL_OK;
}

int load_sys_log(RootServer *rs)
{
    //读取数据。最重要的是ns与nsid对应关系，重启时等待ns来注册
    DB* dbp=NULL;
    char *dbname="syslog.db";
    fl_debug_log("load_sys_log bkdb_open %s\n", dbname);
    int ret;
    if((ret = db_create(&dbp, rs->file_table->db_env, 0)) != 0)
    {
        fl_error_log("load_sys_log Create dbp failed\n",db_strerror(ret));
        return FL_ERROR;
    }

    if((ret = dbp->open(dbp, NULL, dbname, NULL, DB_BTREE, rs->file_table->open_flag, 0)) !=0)
    {
        fl_error_log("load_sys_log Open db %s failed,%s\n",dbname,db_strerror(ret));
        return FL_ERROR;
    }
    int dump_size=0;
    void *data = rs_bkdb_get_data(dbp, "ns_name_map", &dump_size);
    if(!data || !dump_size){
        fl_error_log("load_sys_log rs_bkdb_get_data failed");
        return FL_ERROR;
    }
    rs->ns_name_map = zyload_zymap_ptr(data, dump_size);

    data = rs_bkdb_get_data(dbp, "node_server_list", &dump_size);
    if(!data || !dump_size){
        zymap_free(rs->ns_name_map);
        fl_error_log("load_sys_log rs_bkdb_get_data failed");
        return FL_ERROR;
    }
    rs->node_server_list = zyload_zylist_ptr(data, dump_size);

    dbp->close(dbp,0);

    rs->ns_num = _ZLLen(rs->node_server_list);

    fl_debug_log("load_sys_log ns_%d = %s",0,zylist_get_str(rs->node_server_list,0));

    return FL_OK;
}

//关闭RS的请求处理
int locale_close_rs(RootServer *rs, uint32_t flag)
{

    rs->started = 0;

    ZYElem *melement = NULL;
    //让所有NS把内存数据写入磁盘，并等待结果。
    ZYLIST_FOR_EACH(rs->node_server_list,melement)
    {

        char addr[100];
        char* ns_addr = zyelem_get_str(melement,NULL);
        sprintf(addr,"tcp://%s:%d", ns_addr, rs->ns_port);

        fl_debug_log("delete_file get ns locations=%s",addr);
        NodeServerClient ns_client;

        ns_client.conn_manager.addr = addr;
        init_comm(&ns_client.conn_manager);

        close_ns(&ns_client,0);

        disconnect(&ns_client.conn_manager);
        wait_and_destory(&ns_client.conn_manager);

    }

    fl_debug_log("locale_close_rs  flag=%d",flag);

    save_sys_log(rs);

    ac_acio_stop(rs->conn_manager.comm);

    //由于libuv的缺陷，需要等到下次timer唤醒时才能结束loop
    uv_timer_stop(&rs->timer_req);
    uv_stop(rs->timer_req.loop);

    return FL_OK;
}

//删除某个目录文件。调用系统rm命令。
int delete_file(RootServer *rs, time_t time)
{
    ZYElem *melement = NULL;
    ZYLIST_FOR_EACH(rs->node_server_list,melement)
    {

        char addr[100];
        char* ns_addr = zyelem_get_str(melement,NULL);
        sprintf(addr,"tcp://%s:%d", ns_addr, rs->ns_port);

        fl_debug_log("delete_file get ns locations=%s",addr);
        NodeServerClient ns_client;

        ns_client.conn_manager.addr = addr;
        init_comm(&ns_client.conn_manager);

        int index = FL_PROTOCOL_MAX;
        while(--index>=0){

            time_t del_time = time - rs->del_interval[index]*86400;
            char command[100];
            char datastr[9];
            get_date_dir_by_time(datastr, del_time);
            sprintf(command, "rm -rf %s/%s/%s", rs->file_table->top_dir,protocol_flag_to_str(index),datastr);
            fl_debug_log("delete_file command=%s",command);
            system(command);

            delete_ns_file(&ns_client,index,del_time);


        }
        disconnect(&ns_client.conn_manager);
        wait_and_destory(&ns_client.conn_manager);

    }

}

//刷内存
int flush_cache(RootServer *rs)
{
    ZYElem *melement = NULL;
    //让所有NS把内存数据写入磁盘，并等待结果。
    ZYLIST_FOR_EACH(rs->node_server_list,melement)
    {

        char addr[100];
        char* ns_addr = zyelem_get_str(melement,NULL);
        sprintf(addr,"tcp://%s:%d", ns_addr, rs->ns_port);

        fl_debug_log("delete_file get ns locations=%s",addr);
        NodeServerClient ns_client;

        ns_client.conn_manager.addr = addr;
        init_comm(&ns_client.conn_manager);

        flush_ns_cache(&ns_client,1);

        disconnect(&ns_client.conn_manager);
        wait_and_destory(&ns_client.conn_manager);

    }

}

//追加文件，返回NS地址
ZYList* locale_append_file(RootServer *rs, const char* name, uint32_t protocol_flag)
{
    fl_debug_log("locale_append_file  name=%s flag=%d",name,protocol_flag);
    //获得现在文件的大小，新增block，随机ns
    FileInfo  file_info;
    FileInfo *file_info_p;
    DB* dbp = get_proper_db(rs, rs->file_table, name, protocol_flag);
    if(!dbp)
        return NULL;
    file_info_p = read_file_table(rs, dbp, name, protocol_flag, &file_info);

    ZYList* ns_locations =  get_random_ns_locations(rs);//返回多个ns
    if(ns_locations)
        zylist_append_int64(ns_locations,file_info_p->size); //ZYList最后一个元素是size

    free(file_info_p->owner);

    if(rs->file_table->dbp[protocol_flag]!=dbp)
        dbp->close(dbp,0);

    return ns_locations;

}

ZYList* locale_get_block_locations(RootServer *rs, const char* name, uint64_t offset, uint32_t protocol_flag)
{
    fl_debug_log("locale_get_block_locations name=%s,offset=%lld protocol_flag=%d",name,offset,protocol_flag);
    ZYMap *block_map=NULL;
    int should_free;
    DB* dbp = get_proper_db(rs, rs->block_table, name, protocol_flag);
    if(!dbp)
        return NULL;
    ZYList *block_info = read_block_table(rs,dbp, name, offset, &block_map, protocol_flag, &should_free);
    if(!block_info)
        return NULL;
    ZYList *ns_locations = zylist();
    ZYElem *melement=NULL;
    ZYLIST_FOR_EACH(block_info,melement)
    {
         if(melement->type==ZYT_INT32)
         {
              uint32_t ns_id = zyelem_get_int32(melement,NULL);
              fl_debug_log("locale_get_block_locations ns_id=%d",ns_id);
              zylist_append_str(ns_locations,ns_id_to_name(rs,ns_id));
         }
    }
    if(rs->block_table->dbp[protocol_flag]!=dbp)
        dbp->close(dbp,0);
    if(should_free)
        zymap_free(block_map);
    return ns_locations;
}

ZYList* locale_get_block_info(RootServer *rs, const char* name, uint64_t offset, uint32_t protocol_flag)
{
    fl_debug_log("locale_get_block_info name=%s,offset=%lld,protocol_flag=%d",name,offset,protocol_flag);
    ZYMap *block_map=NULL;
    int should_free;
    DB* dbp = get_proper_db(rs, rs->block_table, name, protocol_flag);
    if(!dbp)
        return NULL;
    ZYList *block_info = read_block_table(rs,dbp, name, offset, &block_map, protocol_flag,&should_free);
    if(!block_info){
        if(should_free)
            zymap_free(block_map);
        if(rs->block_table->dbp[protocol_flag]!=dbp)
            dbp->close(dbp,0);
        return NULL;
    }

    ZYList *ns_locations = zylist();
    ZYElem *melement = NULL;
    int idx=0;
    ZYLIST_FOR_EACH(block_info,melement)
    {
         if(melement->type==ZYT_INT32)
         {
              uint32_t ns_id = zylist_get_int32(block_info,idx);
              const char* file_path = zylist_get_str(block_info,idx+1);
              uint64_t file_offset = zylist_get_int64(block_info,idx+2);
              uint64_t length = zylist_get_int64(block_info,idx+3);
              zylist_append_str(ns_locations,ns_id_to_name(rs,ns_id));
              zylist_append_str(ns_locations,file_path);
              zylist_append_int64(ns_locations,file_offset);
              zylist_append_int64(ns_locations,length);
              fl_debug_log("locale_get_block_info ns_addr=%s,file_path=%s,file_offset=%lld,length=%lld",
                 ns_id_to_name(rs,ns_id),file_path,file_offset,length);
         }
         idx++;
    }
    if(should_free){
        zymap_free(block_map);
    }

    if(rs->block_table->dbp[protocol_flag]!=dbp)
        dbp->close(dbp,0);
    return ns_locations;
}

ZYList* locale_get_ns_server_list(RootServer *rs){
    return rs->node_server_list; //不可在发送之后析构
}

DB* get_proper_db(RootServer *rs, BKDBManager *dbconf, const char* name,uint32_t protocol_flag)
{
    //name = 201411091013test_file;
    if(strlen(name)<=8){
         fl_error_log("get_proper_db error,file name %s too short.",name);
         return NULL;
    }
    char date_now_str[9];
    get_date_dir(date_now_str);
    char date_str[9];
    sprintf(date_str,"%c%c/%c%c/%c%c",name[2],name[3],name[4],name[5],name[6],name[7]);
    if(strcmp(date_now_str,date_str)==0 && rs->table_ok){
        fl_debug_log("file date %s is today, and table ok, return today's DB",date_str);
        return dbconf->dbp[protocol_flag];
    }

    fl_debug_log("today is %s, file date is %s, return a temporary DB",date_now_str, date_str);

    DB* dbp=NULL;
    char dbname[50];
    sprintf(dbname, "%s/%s/%s", protocol_flag_to_str(protocol_flag), date_str, dbconf->name);

    char subdir[100];//建目录
    sprintf(subdir, "%s/%s/%s", dbconf->top_dir,protocol_flag_to_str(protocol_flag),date_str);
    fl_mkdir_p(subdir,0755);

    fl_debug_log("bkdb_open %s\n", dbname);

    int ret;
    if((ret = db_create(&dbp, dbconf->db_env, 0)) != 0)
    {
        fl_error_log("Create dbp failed\n",db_strerror(ret));
        return NULL;
    }

    if((ret = dbp->open(dbp, NULL, dbname, NULL, DB_BTREE, dbconf->open_flag, 0)) !=0)
    {
        fl_error_log("Open db %s failed,%s\n",dbname,db_strerror(ret));
        return NULL;
    }
    return dbp;

}

int rs_is_today_file(const char* name){

    if(strlen(name)<=8){
         fl_error_log("get_proper_db error,file name %s too short.",name);
         return 0;
    }
    char date_now_str[9];
    get_date_dir(date_now_str);
    char date_str[9];
    sprintf(date_str,"%c%c/%c%c/%c%c",name[2],name[3],name[4],name[5],name[6],name[7]);
    if(strcmp(date_now_str,date_str)==0)
        return 1;

    return 0;
}


